package com.companion;

import java.util.*;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_746;

import static com.companion.Key.EntityTable.generateIdToKeyList;
import static com.companion.Key.EntityTable.generateTranslationKeyMap;

public class global {
    // ========== 基础类型变量（String/int/float/boolean/long/double 等） ==========
    public static String ModName = "companionai";
    public static String owner = "hghgjk";
    public static String gamer = "lolo";
    public static String state = null;
    public static String FollowPlayer = "hghgjk";
    public static String MidText = "";

    public static int fov;
    public static int wasComePath = -1;
    public static int MapDrawY = 300;

    public static float TraceEntityHeart = 0;

    public static boolean wasPressed = false;   // 上一 tick 左键状态
    public static boolean control = false;

    public static long[] MapDrawPos = new long[2];

    public static double[] xax = new double[]{0, 0, 0};

    // ========== 实体/客户端相关对象 ==========
    public static class_746 player = null;
    public static class_310 all_client = null;
    public static class_1309 TarEntity = null;
    public static int spearPower=10;
    public static class_1309 traceDMGentity = null;

    // ========== 集合类型变量（List/Set/HashMap 等） ==========
    public static Set<String> online = new HashSet<>();
    public static List<class_2338> Path;
    public static List<class_2338> BeFoundPath = new ArrayList<>();
    public static List<class_2338> CheckTarget = new ArrayList<>();
    public static List<List<class_1799>> MapDrawItem = new ArrayList<>();
    public static HashMap<HashMap<class_5321<class_1937>, class_2338>, HashMap<class_1792, Integer>> CheckChestData = new HashMap<>();// {{世界:位置}:{物品:数量}}
    public static HashMap<class_2338, class_2248> MapDrawTar = new HashMap<>();
    public static HashMap<String, class_1799> NameColor = new HashMap<>();

    //============砍树===============
    public static class_2338 CutTreePos=new class_2338(0,0,0); // 砍树起点坐标
    public static long CutTreeR=0; //砍树半径
    public static Set<class_2338> CutTreeWasFinallyTree=new HashSet<>(); //砍树完成进度每圈半径为3，从1开始，以平面直角坐标系为基准顺时针砍树，对应总大小为(2r+1+6)^2-(2r+1)^2，即是24r+48
    public static class_2338 CutTreeGoalPos =new class_2338(0,0,0); //目标位置
    public static List<class_2338> CutTreeGoalPath=new ArrayList<>(); //路线
    public static int CutTreeGoalPathIndex=0;
    public static Set<class_2338> CutTreeWithCheckTree=new HashSet<>();
    public static boolean CutTreePathGoal=false;

    public static double CutTreeLeapMinD=10; //最大跃迁距离
    public static double CutTreeAreaSize=5; //区域大小
    public static double CutTreeBreakMaxD=6; //最大砍树范围
    public static double CutTreeForD=4; //寻树范围
    public static double CutTreeHalf=CutTreeAreaSize/2.0;



    //隧道类
    public static List<class_2338> TunnelPos = new ArrayList<>();
    public static class_1792 TunnelChooseTool = class_1802.field_8288;
    public static boolean TunnelState = false;
    public static class_1792 TunnelTargetBlock = class_1802.field_20412;
    public static Map<class_2338, Integer> TunnelBuildPos=new HashMap<>();
    public static int TunnelBuildPosSize=0;

    public static boolean MiningBotState=false;
    public static Set<class_2338> MiningBotOldPath=new HashSet<>();
    public static Set<class_1792> MiningBotStayItem=new HashSet<>();
    public static class_2338 MiningBotGoalPos =new class_2338(0,0,0); //目标位置
    public static List<class_2338> MiningBotGoalPath=new ArrayList<>(); //路线
    public static int MiningBotGoalPathIndex=0;
    public static Set<class_2338> MiningBotBlockBan=new HashSet<>();
    public static Set<class_2248> MiningBotGoalBlock=new HashSet<>();
    public static Set<class_1792> MiningBotGoalItems=new HashSet<>();
    public static class_2338 MiningBotGoalBox=new class_2338(0,0,0);
    public static int MiningBotMinY=22;
    public static int MiningBotMaxY=6;

    public static Map<String, String> YOUR_DICT=new HashMap<>();
    public static Map<String, class_1792> Item_DICT=new HashMap<>();
    public static Map<String, class_1792> Item_English_DICT=new HashMap<>();

    public static Map<class_2338,class_1792> RaidOut = new HashMap<>();
    public static List<class_2338> RaidIn=new ArrayList<>();
    public static  int RaidStep=-1;

    public static boolean leapState=false;
    public static double leapMaxD=10;
    public static class_2338 leapGladPos=new class_2338(0,0,0);
    public static int leapWait=0; //0上升 1飞行 2坠落 3等待操作 4检查

    public static Set<String> filter=new HashSet<>();
    public static Set<String> filterPlayer=new HashSet<>();
    public static Set<String> AllPlayer=new HashSet<>();
    //public static Map<String,String> EntityTableCode=generateTranslationKeyMap();
    public static List<String> EntityTableCode2;
}