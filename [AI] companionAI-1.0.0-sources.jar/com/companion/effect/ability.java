package com.companion.effect;


import com.companion.draw.mix;
import com.companion.effect.weapon.Elytra;
import com.companion.effect.weapon.crossbow;
import com.companion.effect.weapon.hook;
import com.companion.effect.weapon.raid;
import com.companion.skills.GetNRNBCleanTime;
import com.companion.skills.MiningBot.MiningBot;
import com.companion.skills.bat.AutoRaid;
import com.companion.skills.leap;
import org.lwjgl.glfw.GLFW;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_639;
import net.minecraft.class_642;

import static com.companion.Key.configTool.cfg;
import static com.companion.global.*;
import static com.companion.ParticleManage.*;
import static com.companion.effect.weapon.Spear.spear;
import static com.companion.effect.weapon.base.sendPos;
import static com.companion.effect.weapon.tool.*;


import static com.companion.draw.base.line;

import static com.companion.effect.tool.*;

import static com.companion.effect.weapon.bow.bow;


public class ability {
    private static int planTime=0;
    private static int planTimeMax=100; //5秒一次
    public static void onTick(class_310 client) { //前进
        player = client.field_1724;
        all_client = client;
        if (player == null) return;

        class_1799 main = player.method_6047();
        class_1799 main2 = player.method_6079();
        boolean emptyHand = main.method_7960(); // 1. 空手
        boolean sprinting = player.method_5624(); // 2. 疾跑
        boolean leftPressed = GLFW.glfwGetMouseButton(client.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_1) == GLFW.GLFW_PRESS; // 3. 左键按下
        boolean rightPressed = GLFW.glfwGetMouseButton(client.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_2) == GLFW.GLFW_PRESS;
        planTime++;
        if(planTime>=planTimeMax){
            planTime=0;
        }
        Other(main,leftPressed,sprinting,emptyHand,rightPressed,main2,client,planTime==0);

        //sendPos(0,0,0,false);
        wasPressed = leftPressed;

        //得到遇到过的所有玩家
        AllPlayer.addAll(getAllLoadedPlayerEntities().stream()
                .map(p -> p.method_5477().getString())
                .toList());

    }
    private static void NoFall(){
        if(cfg.enableNoFall.get()) {
            if (getPlayerHeightAboveGround() < Math.max(player.field_6017 / 5, 2) && player.field_6017 > 2) { //规避摔落伤害
                player.field_6017 = 0.0F;
                player.method_24830(false);
                player.method_18800(player.method_18798().method_10216(), 0.05, player.method_18798().method_10215()); //加速度设为零
            }
        }
    }
    private static void PathManage(){
        class_2338 posTemp=null;
        if (!BeFoundPath.isEmpty()){

            for(class_2338 pos: BeFoundPath){
                mix.block(pos.method_46558(),5,GREEN_POINT_PARTICLE);
                if(posTemp!=null) {
                    line(pos.method_46558(), posTemp.method_46558(),3, RED_POINT_PARTICLE);
                }
                posTemp=pos;
            }

        }
        if (wasComePath!=-1){
            class_243 targetPos=BeFoundPath.get(wasComePath).method_46558().method_1031(0,-0.5,0);

            if(miniLeap(targetPos,10)){
                wasComePath++;
                if(wasComePath>=BeFoundPath.size()){
                    wasComePath=-1;
                }
            }
        }
    }
    private static void Other(class_1799 main, boolean leftPressed, boolean sprinting, boolean emptyHand, boolean rightPressed, class_1799 main2, class_310 client, boolean b){
        TraceHP();
        bow(main,main2);
        spear(leftPressed,main);
        NoFall();
        Run(emptyHand,sprinting,leftPressed);
        //tip(getBlockScreenVertices(new BlockPos(0,0,0)));
        com.companion.effect.TunnelBulid.main.reg(main,rightPressed,leftPressed);
        PathShow();
        MiningBot.TickRun();
        AutoRaid.update(client,b);
        raid.update(leftPressed,client,rightPressed);
        Elytra.update(client);
        leap.update(client);
        if (player.field_7513 != null && player.field_7513.method_26957() != null) {
            hook.retractFishingRod();
        }
        if(rightPressed){
            crossbow.power(player.method_6047());
        }
        PathManage();
        if(cfg.enableAutoAfk.get()) {
            var v=GetNRNBCleanTime.get();
            tip( "§a下次清理倒计时："+v+"秒",true);
            if( v<30) {
                afk();
            }
        }
    }

    private static void afk(){
        // 1. 保存当前服务器信息
        class_310 client=class_310.method_1551();
        class_642 currentServer = client.method_1558();
        if (currentServer == null) {
            tipGame("未在服务器中，无法重连");
            return;
        }

        // 2. 主动断开连接
        client.method_1562().method_48296().method_10747(class_2561.method_43470("检测到清理，断开，60秒后重连"));

        // 3. 延迟60秒后重连
        CompletableFuture.runAsync(() -> {
            try {
                Thread.sleep(60*1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // 主线程执行重连
            client.execute(() -> {
                // 回到服务器列表并连接
                client.method_63588(() -> {
                    class_412.method_36877(
                            new class_500(new class_442()),
                            client,
                            class_639.method_2950(currentServer.field_3761),
                            currentServer,
                            false,
                            null
                    );
                });
            });
        });
    }

    public static List<class_1657> getAllLoadedPlayerEntities() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1687 == null) {
            return Collections.emptyList(); // 更安全的空列表
        }

        class_1937 world = client.field_1687;
        List<? extends class_1657> rawPlayers = world.method_18456();

        // 流式转换为List<PlayerEntity>，并过滤null值
        return rawPlayers.stream()
                .filter(Objects::nonNull) // 过滤null玩家，避免空指针
                .map(player -> (class_1657) player)
                .collect(Collectors.toList());
    }



}
