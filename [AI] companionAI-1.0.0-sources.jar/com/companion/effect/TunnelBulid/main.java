package com.companion.effect.TunnelBulid;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_310;

import static com.companion.effect.tool.tipGame;
import static com.companion.global.*;
import static com.companion.render3D.screen.points;

public class main {
    private static boolean rig=false;
    private static boolean l=false;
    public static void reg(class_1799 main,boolean right,boolean left){
        class_1657 player = class_310.method_1551().field_1724;
        if(player==null) return;
        if (main.method_7909()==TunnelChooseTool){ //如果拿起目标物品
            Show.PlayerPos(player);
            Show.PlayerChooseLine(player);

            if(right){
                if (!rig) {
                    if (TunnelPos.contains(player.method_24515())) {
                        TunnelPos.remove(player.method_24515());
                        tipGame("已删除位置[" + player.method_24515() + "]");
                    }else{
                        if (!TunnelPos.isEmpty()) {

                            class_2338 a = new class_2338(player.method_24515().method_10263(), TunnelPos.getLast().method_10264(), TunnelPos.getLast().method_10260());
                            class_2338 b = new class_2338(player.method_24515().method_10263(), player.method_24515().method_10264(), TunnelPos.getLast().method_10260());
                            class_2338 c = new class_2338(player.method_24515().method_10263(), player.method_24515().method_10264(), player.method_24515().method_10260());
                            if ((TunnelPos.getLast().method_10263() - player.method_24515().method_10263()) != 0) {
                                TunnelPos.add(a);
                            }
                            if ((TunnelPos.getLast().method_10264() - player.method_24515().method_10264()) != 0) {
                                TunnelPos.add(b);
                            }
                            if ((TunnelPos.getLast().method_10260() - player.method_24515().method_10260()) != 0) {
                                TunnelPos.add(c);
                            }
                        } else {
                            TunnelPos.add(player.method_24515());
                        }

                        tipGame("已添加位置[" + player.method_24515() + "]");
                    }
                    rig = true;
                }
            }else{
                if (rig) {
                    rig = false;
                }
            }
            if(left){
                if (!l) {
                    if(!TunnelPos.isEmpty()) {
                        tipGame("偏移量[x=" + (TunnelPos.getLast().method_10263() - player.method_24515().method_10263()) + " y=" + (TunnelPos.getLast().method_10264() - player.method_24515().method_10264()) + " z=" + (TunnelPos.getLast().method_10260() - player.method_24515().method_10260()) + "]");
                    }
                    l = true;
                }
            }else{
                if (l) {
                    l = false;
                }
            }
        }
        Show.TunnelPath();
        if(!points.isEmpty()){
            Show.TunnelCheck();
        }
        Show.TunnelCreate();
        // 过滤保留不符合条件的方块，直接赋值
        //防止未放置延迟干扰
        for(class_2338 p:TunnelBuildPos.keySet()){
            if(player.method_73189().method_1022(p.method_46558()) < 100 && !player.method_73183().method_8320(p).method_26215()){
                TunnelBuildPos.put(p,TunnelBuildPos.get(p)+1);
            }else{
                TunnelBuildPos.put(p,0);
            }
        }
        TunnelBuildPos.entrySet().removeIf(pos -> pos.getValue() > 10); //删除判断了十次的
        if(TunnelState && !TunnelBuildPos.isEmpty()){
            if(main.method_7909()==TunnelTargetBlock){
                class_2338 MinBlock=TunnelBuildPos.keySet().stream().toList().getFirst();
                for(class_2338 pos:TunnelBuildPos.keySet()) {
                    if (TunnelBuildPos.get(pos)==0) {
                        if (player.method_73189().method_1022(pos.method_46558()) < player.method_73189().method_1022(MinBlock.method_46558())) {
                            MinBlock = pos;
                        }
                    }
                }
                if (player.method_73189().method_1022(MinBlock.method_46558())<5.5) {
                    //tipGame("隧道","建造进度："+((((double) TunnelBuildPos.size()/(double) TunnelBuildPosSize)*100))+"%");

                    com.companion.effect.TunnelBulid.Bulid.placeAt(MinBlock);
                    TunnelBuildPos.put(MinBlock,1); //避免多放
                }
            }
        }
        if(TunnelBuildPos.isEmpty() && TunnelBuildPosSize>0){
            TunnelBuildPosSize=0;
            //TunnelPos.clear();
            points.clear();
            tipGame("隧道","建造完成");
        }
    }
}
