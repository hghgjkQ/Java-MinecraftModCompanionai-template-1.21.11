package com.companion.effect.TunnelBulid;

import static com.companion.global.*;

import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;

public class Bulid {
    /**
     * 移动指定物品到主手
     * @param inventory 玩家背包
     * @param targetItem 目标物品
     */
    private static void sup(class_1661 inventory, class_1792 targetItem) {
        // 1. 已经在主手就不用动了
        if (player.method_6047().method_7909() == targetItem) return;

        // 2. 遍历 0-35（背包 + 快捷栏）
        for (int slot = 0; slot < 36; slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7909() == targetItem) {
                if (all_client.field_1761 != null) {
                    int hotbarSlot = player.method_31548().method_67532(); // 0-8
                    all_client.field_1761.method_2906(
                            0,
                            slot,
                            0,
                            class_1713.field_7790,
                            player
                    );
                    all_client.field_1761.method_2906(
                            0,
                            hotbarSlot,
                            0,
                            class_1713.field_7790,
                            player
                    );
                    return;   // 只搬第一组
                }
            }
        }
    }

    /**
     * 把背包里第一块与主手同类的方块放到任意世界坐标（空气也行）
     *
     * @param target 目标世界坐标
     */
    public static void placeAt(class_2338 target) {
        class_310.method_1551().execute(() -> {
            class_636 im = all_client.field_1761;
            if (player == null || im == null) return;
            /* 3. 伪造 BlockHitResult：假装玩家右键了“目标方块”本身 */
            class_3965 hit = new class_3965(
                    class_243.method_24953(target), // 命中点设在 target 上方一格的中心
                    class_2350.field_11033,              // 表示点击的是 target.up() 的底面
                    target,                 // 被点击的方块坐标
                    false
            );
            /* 4. 发原版交互包 */
            im.method_2896(player, class_1268.field_5808, hit);
        });
    }
}
