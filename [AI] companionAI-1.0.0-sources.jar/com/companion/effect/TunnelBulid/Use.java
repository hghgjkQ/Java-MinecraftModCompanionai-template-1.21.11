package com.companion.effect.TunnelBulid;

import com.companion.effect.book.ReadWrite;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;

import static com.companion.effect.tool.tipGame;
import static com.companion.global.*;

public class Use {



    public static void read(class_1799 main){
        if(main.method_7909()== class_1802.field_8674){
            try {
                TunnelPos = parse(ReadWrite.readBook());
                tipGame("读取成功！");
            }catch (Exception e){
                tipGame("读取失败："+e);
            }
        }
    }
    public static void write(class_1799 main){
        if(main.method_7909()== class_1802.field_8674){
            ReadWrite.write(String.valueOf(TunnelPos));
            tipGame("蓝图写入完成");
        }
    }

    private static final List<class_2338> xyzv=new ArrayList<>();
    static {
        xyzv.add(new class_2338(1,0,0));
        xyzv.add(new class_2338(-1,0,0));
        xyzv.add(new class_2338(0,0,1));
        xyzv.add(new class_2338(0,0,-1));

        xyzv.add(new class_2338(0,1,0));
        xyzv.add(new class_2338(0,-1,0));
    }

    /**
     * 生成待建造位置
     */
    public static void create(){
        if(TunnelPos.isEmpty()){
            tipGame("隧道","无法加载，原因：无蓝图");
            return;
        }
        TunnelBuildPos.clear();
        var temp1=generateLinePositions(TunnelPos);
        List<class_2338> temp=new ArrayList<>();
        for(class_2338 pos:temp1){
            temp.add(pos);
            temp.add(pos.method_10069(0,1,0));
        }
        for(class_2338 pos:temp){
            for (class_2338 v: xyzv){
                var c=pos.method_10081(v);
                if ((!TunnelBuildPos.containsKey(c)) && (!temp.contains(c))){
                    TunnelBuildPos.put(c,0);
                }
            }
        }
        TunnelBuildPosSize=TunnelBuildPos.size();
        tipGame("隧道","加载完成");
    }
    // 正则：匹配所有 [x,y,z] 格式的坐标（支持负数、多坐标）

    // 仅匹配你的 class_2338 坐标格式
    private static final Pattern REGEX = Pattern.compile("class_2338\\{x=(-?\\d+),\\s*y=(-?\\d+),\\s*z=(-?\\d+)\\}");

    /**
     * 输入：List<String> 破碎字符串
     * 输出：仅解析后的原始 List<BlockPos>（无任何额外操作）
     */
    public static List<class_2338> parse(List<String> fragments) {
        // 1. 仅拼接所有碎片
        String fullStr = String.join("", fragments);

        // 2. 仅解析坐标，返回原始List
        List<class_2338> result = new ArrayList<>();
        REGEX.matcher(fullStr).results().forEach(match -> {
            int x = Integer.parseInt(match.group(1));
            int y = Integer.parseInt(match.group(2));
            int z = Integer.parseInt(match.group(3));
            result.add(new class_2338(x, y, z));
        });
        return result;
    }
    /**
     * 传入一串按顺序排列的 BlockPos（都是横平竖直直线）
     * 返回包含所有中间点的完整 Set<BlockPos>
     */
    public static Set<class_2338> generateLinePositions(List<class_2338> posList) {
        Set<class_2338> result = new HashSet<>();
        if (posList == null || posList.size() <= 1) {
            posList.forEach(result::add);
            return result;
        }

        // 遍历每两个连续的点
        for (int i = 0; i < posList.size() - 1; i++) {
            class_2338 start = posList.get(i);
            class_2338 end = posList.get(i + 1);
            // 填充两点之间的所有坐标
            fillLineBetween(start, end, result);
        }

        return result;
    }

    /**
     * 核心：填充 横平竖直 两点之间的所有 BlockPos（你保证两点只有一维变化，无需判断）
     */
    private static void fillLineBetween(class_2338 start, class_2338 end, Set<class_2338> set) {
        int x1 = start.method_10263(), y1 = start.method_10264(), z1 = start.method_10260();
        int x2 = end.method_10263(),   y2 = end.method_10264(),   z2 = end.method_10260();

        // X 轴方向直线
        if (x1 != x2) {
            int min = Math.min(x1, x2);
            int max = Math.max(x1, x2);
            for (int x = min; x <= max; x++) {
                set.add(new class_2338(x, y1, z1));
            }
        }
        // Y 轴方向直线
        else if (y1 != y2) {
            int min = Math.min(y1, y2);
            int max = Math.max(y1, y2);
            for (int y = min; y <= max; y++) {
                set.add(new class_2338(x1, y, z1));
            }
        }
        // Z 轴方向直线
        else if (z1 != z2) {
            int min = Math.min(z1, z2);
            int max = Math.max(z1, z2);
            for (int z = min; z <= max; z++) {
                set.add(new class_2338(x1, y1, z));
            }
        }
        // 同一个点
        else {
            set.add(start);
        }
    }
}
