package com.companion.effect.TunnelBulid;

import com.companion.ParticleManage;
import com.companion.draw.base;
import com.companion.draw.mix;
import com.companion.render3D.Color;
import com.companion.render3D.screen;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_243;

import static com.companion.draw.base.line;
import static com.companion.global.*;
import static com.companion.render3D.screen.points;
import static com.companion.render3D.show.worldToScreen;

public class Show {
    public static void PlayerPos(class_1657 player){ //绘制当前玩家位置
        if (TunnelPos.contains(player.method_24515())) {
            base.point(ParticleManage.RED_POINT_PARTICLE,player.method_24515().method_46558());
        }else{
            base.point(ParticleManage.ORANGE_POINT_PARTICLE,player.method_24515().method_46558());
        }
    }
    public static void PlayerChooseLine(class_1657 player){
        if (!TunnelPos.isEmpty()){

            class_243 a=new class_243(player.method_24515().method_46558().method_10216(),TunnelPos.getLast().method_46558().method_10214(),TunnelPos.getLast().method_46558().method_10215());
            class_243 b=new class_243(player.method_24515().method_46558().method_10216(),player.method_24515().method_46558().method_10214(),TunnelPos.getLast().method_46558().method_10215());
            class_243 c=new class_243(player.method_24515().method_46558().method_10216(),player.method_24515().method_46558().method_10214(),player.method_24515().method_46558().method_10215());


            base.line(TunnelPos.getLast().method_46558(),a,1,ParticleManage.PURPLE_POINT_PARTICLE);
            base.line(a,b,1,ParticleManage.PURPLE_POINT_PARTICLE);
            base.line(b,c,1,ParticleManage.PURPLE_POINT_PARTICLE);
        }
    }
    public static void TunnelPath(){
        class_2338 posTemp=null;
        if (!TunnelPos.isEmpty()){

            for(class_2338 pos: TunnelPos){
                mix.block(pos.method_46558(),2,ParticleManage.PINK_POINT_PARTICLE);
                if(posTemp!=null) {
                    line(pos.method_46558(), posTemp.method_46558(),1, ParticleManage.BROWN_POINT_PARTICLE);
                }
                posTemp=pos;
            }

        }
    }
    public static void TunnelCreate(){
        if (!TunnelBuildPos.isEmpty()) {
            for (class_2338 pos : TunnelBuildPos.keySet()) {
                if(TunnelBuildPos.get(pos)<10) {
                    base.point(ParticleManage.WHITE_POINT_PARTICLE, pos.method_46558());
                }
            }
        }
    }
    public static void TunnelCheck() {
        points.clear();
        if (!TunnelBuildPos.isEmpty()) {
            for (class_2338 pos : TunnelBuildPos.keySet()) {
                if(TunnelBuildPos.get(pos)<10) {
                    points.add(new screen.PointWithColor(pos.method_46558(), "浅紫"));
                }
            }
        }

    }
}
