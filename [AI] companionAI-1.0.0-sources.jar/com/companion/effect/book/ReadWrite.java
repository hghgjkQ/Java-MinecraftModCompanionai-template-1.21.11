package com.companion.effect.book;

import java.util.*;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2873;
import net.minecraft.class_310;
import net.minecraft.class_9262;
import net.minecraft.class_9301;
import net.minecraft.class_9334;

public class ReadWrite {


    /* ========= 覆写：每页≤1024，超100页拒绝 ========= */
    public static boolean write(String a) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return false;
        class_1799 stack = null;
        class_1268 hand = null;
        for (class_1268 h : class_1268.values()) {
            class_1799 s = mc.field_1724.method_5998(h);
            if (s.method_31574(class_1802.field_8674)) {
                stack = s;
                hand = h;
                break;
            }
        }
        if (stack == null) return false;

        /* 分页：每页≤1024 */
        final int PAGE_MAX = 1024;
        List<class_9262<String>> pages = new ArrayList<>();
        for (int i = 0; i < a.length(); i += PAGE_MAX) {
            if (pages.size() >= 100) {
                mc.field_1724.method_7353(class_2561.method_43470("§c内容超过100页，已截断！"), false);
                break;
            }
            pages.add(class_9262.method_57137(a.substring(i, Math.min(i + PAGE_MAX, a.length()))));
        }

        /* 覆写整本书 */
        stack.method_57379(class_9334.field_49653,
                new class_9301(pages));
        Objects.requireNonNull(mc.method_1562()).method_52787(
                new class_2873(36 + hand.ordinal(), stack));
        return true;
    }

    /* ========= 读取：返回每页原文 List<String> ========= */
    public static List<String> readBook() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return Collections.emptyList();

        class_1799 stack = null;
        for (class_1268 h : class_1268.values()) {
            class_1799 s = mc.field_1724.method_5998(h);
            if (s.method_31574(class_1802.field_8674) || s.method_31574(class_1802.field_8360)) {
                stack = s;
                break;
            }
        }
        if (stack == null) return Collections.emptyList();

        class_9301 content =
                stack.method_58694(class_9334.field_49653);
        if (content == null) return Collections.emptyList();

        List<String> list = new ArrayList<>();
        for (class_9262<String> page : content.comp_2422()) {
            list.add(page.comp_2369());   // 取未过滤原文
        }
        return list;
    }
}




