package com.companion.effect;


import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

import static com.companion.CompanionAIClient.*;
import static com.companion.global.*;

public class tool {
    public static boolean isPlayerOpenAir() { //检测玩家释放处于露天高度
        if (player == null) return false;

        class_1937 world = player.method_73183();
        class_2338 eye = new class_2338((int) player.method_23317(), (int) player.method_23320(), (int) player.method_23321());
        int topY = world.method_31605();      // 世界建筑上限
        for (int y = eye.method_10264(); y <= topY; y++) {
            if (!world.method_8320(new class_2338(eye.method_10263(), y, eye.method_10260())).method_26215()) {
                return false;                    // 找到固体方块 → 不露天
            }
        }
        return true;                             // 一路都是空气 → 露天
    }

    public static void center() { //校准玩家位置
        class_243 pos = player.method_73189();
        player.method_23327(
                ((int) pos.method_10216()) + 0.5,
                (int) pos.method_10214(),
                ((int) pos.method_10215()) + 0.5
        );
    }

    public static void tp(double x, double y, double z) {
        class_243 pos = player.method_73189();
        player.method_23327(pos.method_10216() + x, pos.method_10214() + y, pos.method_10215() + z);
        //防止摔伤代码
        player.method_18800(0, 0, 0); //加速度设为零
        player.method_24830(true); //告诉服务端“我已落地”
        player.field_6017 = 0.0F;   // 清除摔落高度
    }

    public static void teleport(double distance) {
        //MinecraftClient client = MinecraftClient.getInstance();
        //ClientPlayerEntity player = client.player;
        if (player == null) return;

        class_243 look = player.method_5828(1F);          // 面朝方向单位向量
        class_243 target = player.method_73189().method_1019(look.method_1021(distance));
        player.method_23327(target.field_1352, target.field_1351, target.field_1350);     // 本地瞬移
        //防止摔伤代码
        player.method_18800(0, 0, 0); //加速度设为零
        player.method_24830(true); //告诉服务端“我已落地”
        player.field_6017 = 0.0F;   // 清除摔落高度
    }
    public static void rush(double distance) {
        //MinecraftClient client = MinecraftClient.getInstance();
        //ClientPlayerEntity player = client.player;
        if (player == null) return;

        class_243 look = player.method_5828(1F).method_1021(distance);          // 面朝方向单位向量
        player.method_60491(look);     // 本地瞬移
        //防止摔伤代码
        player.field_6017 = 0.0F;   // 清除摔落高度
        player.method_24830(false); //告诉服务端“我没落地”
    }

    public static void tick(long x) { //等待x tick
        try {
            Thread.sleep(50 * x); // 50 ms = 1 tick
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static void tick() { //等待1 tick
        try {
            Thread.sleep(50); // 50 ms = 1 tick
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static void sleep(long x) {
        try {
            Thread.sleep(x); // 50 ms = 1 tick
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static void say(Object x) { //广播信息

        class_310.method_1551().execute(() -> {
            player.field_3944.method_45729(String.valueOf(x));
        });
    }

    public static void tip(Object x) { //提示玩家
        class_310.method_1551().execute(() -> {
            player.method_7353(class_2561.method_43470(String.valueOf(x)), false);
        });
    }
    public static void tipGame(Object x) { //提示玩家
        class_310.method_1551().execute(() -> {
            player.method_7353(class_2561.method_43470("§a["+ModName+"]"+ x), false);
        });
    }
    public static void tipGame(Object a,Object x) { //提示玩家
        class_310.method_1551().execute(() -> {
            player.method_7353(class_2561.method_43470("§a["+ModName+"]§b["+a+"]§a"+ x), false);
        });
    }
    public static void tipGame(Object a,class_2561 x) { //提示玩家
        class_310.method_1551().execute(() -> {
            player.method_7353(class_2561.method_43470("§a["+ModName+"]§b["+a+"]§a").method_10852(x), false);
        });
    }

    public static void tip(Object x,boolean o) { //提示玩家
        class_310.method_1551().execute(() -> {
            player.method_7353(class_2561.method_43470(String.valueOf(x)), o);
        });
    }

    public static void error(Object x) { //报错玩家
        // 0: getStackTrace, 1: logCaller, 2: 真正的调用者
        StackTraceElement caller = Thread.currentThread().getStackTrace()[2];
        class_310.method_1551().execute(() -> {
            player.method_7353(class_2561.method_43470("§4["+ModName+"]出现错误：\n"+String.format("调用位置 -> %s.%s(%s:%d)%n", caller.getClassName(), caller.getMethodName(), caller.getFileName(), caller.getLineNumber())+"\n"+x), false);
        });
    }

    public static double sub_sym(double a, double b) {
        double c = a - b;
        if (c == 0) {
            return 0;
        } else {
            return c / Math.abs(c);
        }
    }

    public static int playerMaxOpenY() {
        if (player == null || player.method_73183() == null) { //玩家位置最高露天方块
            return 320; // 确保玩家和世界不为空
        }

        class_2338 playerPos = new class_2338((int) player.method_23317(), (int) player.method_23320(), (int) player.method_23321());
        int highestBlockY = Integer.MIN_VALUE; // 初始化为可能的最低高度

        // 从玩家位置向下遍历，直到找到第一个非空气方块
        for (int y = playerPos.method_10264(); y >= player.method_73183().method_31607(); y--) {
            class_2338 checkPos = new class_2338(playerPos.method_10263(), y, playerPos.method_10260());
            if (!player.method_73183().method_22347(checkPos)) {
                highestBlockY = y; // 找到非空气方块，记录Y坐标
                break; // 找到非空气方块后停止遍历
            }
        }

        return highestBlockY;
    }
    public static double getPlayerHeightAboveGround() {
        if (player == null || player.method_73183() == null) {
            return 0.0;
        }

        class_1937 world = player.method_73183();
        class_238 playerBoundingBox = player.method_5829();
        double minHeight = Double.MAX_VALUE;
        boolean foundGround = false;

        // 检查玩家碰撞箱四个角以及中心点
        class_243[] checkPoints = {
                new class_243(playerBoundingBox.field_1323, playerBoundingBox.field_1322, playerBoundingBox.field_1321),
                new class_243(playerBoundingBox.field_1320, playerBoundingBox.field_1322, playerBoundingBox.field_1321),
                new class_243(playerBoundingBox.field_1323, playerBoundingBox.field_1322, playerBoundingBox.field_1324),
                new class_243(playerBoundingBox.field_1320, playerBoundingBox.field_1322, playerBoundingBox.field_1324),
                new class_243(player.method_23317(), playerBoundingBox.field_1322, player.method_23321()) // 中心点
        };

        for (class_243 point : checkPoints) {
            class_3959 context = new class_3959(
                    point,
                    new class_243(point.field_1352, world.method_31607(), point.field_1350),
                    class_3959.class_3960.field_17558,
                    class_3959.class_242.field_1348,
                    player
            );

            class_3965 hit = world.method_17742(context);
            if (hit.method_17783() == class_239.class_240.field_1332) {
                double height = point.field_1351 - hit.method_17784().field_1351;
                minHeight = Math.min(minHeight, height);
                foundGround = true;
            }
        }

        if (foundGround) {
            return minHeight;
        }

        // 如果没有击中任何方块，返回玩家到世界底部的最小距离
        return playerBoundingBox.field_1322 - world.method_31607();
    }

    /**
     * 为了便于进行跃迁的方法
     * @param leap_x 目标x
     * @param leap_y 目标y
     * @param leap_z 目标z
     * @param leap_distance 最大跃迁距离
     */
    public static boolean miniLeap(double leap_x,double leap_y,double leap_z,double leap_distance){

        double subX = leap_x - player.method_73189().method_10216();
        double subY = leap_y - player.method_73189().method_10214();
        double subZ =  leap_z - player.method_73189().method_10215();
        double d =Math.sqrt(subX * subX + subZ * subZ+subY*subY); //距离
        if(d>leap_distance) {
            double scale = leap_distance / d; // 计算水平距离后归一化放大 10 倍
            tp(
                    subX * scale,
                    subY * scale,
                    subZ * scale
            );
            return false;
        }else {
            tp(
                    subX,
                    subY,
                    subZ
            );
            return true;
        }
    }
    /**
     * 为了便于进行跃迁的方法，最大跃迁距离为10
     * @param leap_x 目标x
     * @param leap_y 目标y
     * @param leap_z 目标z
     */
    public static boolean miniLeap(double leap_x,double leap_y,double leap_z){

        double subX = leap_x - player.method_73189().method_10216();
        double subY = leap_y - player.method_73189().method_10214();
        double subZ =  leap_z - player.method_73189().method_10215();
        double d =Math.sqrt(subX * subX + subZ * subZ+subY*subY); //距离
        double leap_distance=10;
        if(d>leap_distance) {
            double scale = leap_distance / d; // 计算水平距离后归一化放大 10 倍
            tp(
                    subX * scale,
                    subY * scale,
                    subZ * scale

            );
            return false;
        }else {
            tp(
                    subX,
                    subY,
                    subZ
            );
            return true;
        }
    }
    /**
     * @param pos 目标
     * @param leap_distance 最大跃迁距离
     */
    public static boolean miniLeap(class_243 pos,double leap_distance){

        double subX = pos.method_10216() - player.method_73189().method_10216();
        double subY = pos.method_10214() - player.method_73189().method_10214();
        double subZ =  pos.method_10215() - player.method_73189().method_10215();
        double d =Math.sqrt(subX * subX + subZ * subZ+subY*subY); //距离
        if(d>leap_distance) {
            double scale = leap_distance / d; // 计算水平距离后归一化放大 10 倍
            tp(
                    subX * scale,
                    subY * scale,
                    subZ * scale

            );
            return false;
        }else {
            tp(
                    subX,
                    subY,
                    subZ
            );
            return true;
        }
    }
    public static List<class_1657> getAllLoadedPlayerEntities() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1687 == null) {
            return List.of(); // 返回空列表，避免null
        }

        class_1937 world = client.field_1687;
        // 核心修复：将List<? extends PlayerEntity>转换为List<PlayerEntity>
        List<? extends class_1657> rawPlayers = world.method_18456();
        // 流式处理重新收集，显式指定类型为PlayerEntity
        List<class_1657> allPlayers = rawPlayers.stream()
                .map(player -> (class_1657) player) // 强制转换（类型安全，因为都是PlayerEntity子类）
                .collect(Collectors.toList());

        return allPlayers;
    }
    public static class_243 randomR(double R){
        double angle = ThreadLocalRandom.current().nextDouble(Math.PI * 2);
        return new class_243(Math.cos(angle)*R,0,Math.sin(angle)*R);
    }

}
