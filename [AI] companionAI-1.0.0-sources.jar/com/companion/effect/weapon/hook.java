package com.companion.effect.weapon;

import static com.companion.effect.weapon.base.sendPos;
import static com.companion.global.player;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class hook {
    public static final class_310 mc = class_310.method_1551();
    /**
     * 获取玩家视线正前方指定距离坐标
     * @param distance 距离，需求填30
     * @return 空间三维坐标Vec3d；无玩家返回null
     */
    public static class_243 getLookForwardPos(double distance) {
        class_1657 player = mc.field_1724;
        if (player == null) return null;

        // 获取玩家朝向向量（原版原生API，不用手写三角函数，更稳定）
        class_243 lookDir = player.method_5720();
        // 起点：玩家眼睛坐标（视线起点是眼睛，不是脚底）
        class_243 eyePos = player.method_33571();
        // 眼睛坐标 + 方向*距离
        return eyePos.method_1019(lookDir.method_1021(distance));
    }

    // 封装直接拿前方30格
    public static class_243 getForward30Block() {
        return getLookForwardPos(30);
    }

    // 拆分四舍五入为方块整数坐标
    public static int[] getForward30BlockInt() {
        class_243 pos = getForward30Block();
        if(pos == null) return new int[]{0,0,0};
        return new int[]{
                (int) Math.round(pos.field_1352),
                (int) Math.round(pos.field_1351),
                (int) Math.round(pos.field_1350)
        };
    }
    /**
     * 发包收回鱼竿
     * @return true 成功发包；false 没拿钓竿/无玩家
     */
    public static boolean retractFishingRod() {
        class_746 player = mc.field_1724;
        if (player == null) return false;

        // 判断主手是否拿着钓鱼竿
        class_1799 mainHand = player.method_6047();
        if (!(mainHand.method_7909() instanceof class_1787)) {
            return false;
        }

        if (player.field_7513 != null) {
            class_1297 k =player.field_7513.method_26957();
            for (int i = 0; i < 4; ++i) sendPos(k.method_23317(),k.method_23318()+30,k.method_23321(),false);

            player.field_6017=0;
            player.method_24830(false);
            player.method_5762(0,1,0);
            //player.setPos(player.getX(),player.getY()+30,player.getZ());
            // 发送玩家右键物品数据包，服务器判定收竿
            class_2886 packet = new class_2886(class_1268.field_5808, 30,player.method_36455(), player.method_36454());
            player.field_3944.method_52787(packet);
            return true;
        }

        return false;
    }


}
