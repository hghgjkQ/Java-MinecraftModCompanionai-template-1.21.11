package com.companion.effect.weapon;

import java.util.*;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_746;

import static com.companion.Key.configTool.cfg;
import static com.companion.effect.tool.randomR;
import static com.companion.effect.tool.tipGame;
import static com.companion.effect.weapon.base.sendPos;
import static com.companion.effect.weapon.tool.ClickChat;
import static com.companion.global.*;
import static com.companion.skills.Tkill.getEyeEntity;

public class raid {





    private static boolean c=false;
    private static boolean d=false;

    private static void into(class_310 client,class_2394 a){
        for (int i=0;i<10;i++) {
            class_243 offset=randomR(Math.random()*5+1);

            if (client.field_1687 != null) {
                client.field_1687.method_8466(
                        a,
                        true,
                        true,
                        player.method_23317() +offset.method_10216(),
                        player.method_23318()+Math.random()*5,
                        player.method_23321() + offset.method_10215(),
                        -offset.method_10216(),0,-offset.method_10215()
                );
            }
        }
    }

    public static void update(boolean a,class_310 client,boolean b){
        if(player.method_6047().method_7909()== class_1802.field_49814 && cfg.enableMace.get()) {
            if (client==null || client.field_1687 == null || client.field_1724==null) return;

            for (int i=0;i<cfg.MacePower/10;i++) {
                class_243 offset=randomR(1);

                    client.field_1687.method_8466(
                            class_2398.field_11215,
                            true,
                            true,
                            player.method_23317() +offset.method_10216(),
                            player.method_23318()+0.1,
                            player.method_23321() + offset.method_10215(),
                            -offset.method_10216()*cfg.RaidR/10,0,-offset.method_10215()*cfg.RaidR/10
                    );
                }


            double radius = cfg.RaidR;

            // 获取范围内所有活体实体，并过滤掉自己
            List<class_1309> entities = client.field_1687.method_8390(class_1309.class,
                    client.field_1724.method_5829().method_1014(radius),
                    ee -> !filterE(client, ee)
            );


            class_243 random = new class_243(Math.random() * 1 - 0.5, Math.random() * 1 - 0.5, Math.random() * 1 - 0.5);
            for (class_1309 entity : entities) {
                if(Math.random()>0.3)continue;
                client.field_1687.method_8466(
                        class_2398.field_11209,
                        true,
                        true,
                        entity.method_23317() + random.field_1352,
                        entity.method_23318() + random.field_1351,
                        entity.method_23321() + random.field_1350,
                        random.field_1352,random.field_1351, random.field_1350
                );
                client.field_1687.method_8466(
                        class_2398.field_11215,
                        true,
                        true,
                        entity.method_23317() + random.field_1352,
                        entity.method_23318() + random.field_1351,
                        entity.method_23321() + random.field_1350,
                        0,0,0
                );
            }
            if(player.method_5715()) {
                if (b) {
                    if (d) {
                        class_1309 tarE = getEyeEntity(128);
                        if (tarE != null) {
                            String name;
                            if (tarE instanceof class_1657) {
                                name=tarE.method_5477().getString();
                                if (filterPlayer.contains(name)) {
                                    filterPlayer.remove(name);
                                    into(client, class_2398.field_11231);
                                    tipGame("MaceFilter", class_2561.method_43470("§4玩家§5"+name+"§4不会被过滤了§2").method_10852(ClickChat("[","再次过滤","/companionai macefilter player add "+name,"]")));
                                } else {
                                    filterPlayer.add(name);
                                    into(client, class_2398.field_11201);
                                    tipGame("MaceFilter",class_2561.method_43470("§a玩家§5"+name+"§a将被过滤§2").method_10852(ClickChat("[","取消过滤","/companionai macefilter player remove "+name,"]")));
                                }
                            } else {
                                name=tarE.method_5864().method_5882();
                                if (filter.contains(name)) {
                                    filter.remove(name);
                                    into(client, class_2398.field_11231);
                                    tipGame("MaceFilter",class_2561.method_43470("§4实体§5"+name+"§4不会被过滤§2").method_10852(ClickChat("[","再次过滤","/companionai macefilter entity add "+name,"]")));
                                } else {
                                    filter.add(name);
                                    into(client, class_2398.field_11201);
                                    tipGame("MaceFilter",class_2561.method_43470("§a实体§5"+name+"§a将被过滤§2").method_10852(ClickChat("[","再次取消过滤","/companionai macefilter entity remove "+name,"]")));
                                }
                            }
                        }

                        d = false;
                    }
                } else if (!d) {
                    d = true;
                }
            }
        }
        if(a && player.method_6047().method_7909()== class_1802.field_49814 && cfg.enableMace.get()){
            draw();
            if(c) {
                c = false;
                raid.m();
            }
        }else{
            if(!c) {
                c=true;
        }

        }
    }

    private static boolean filterE(class_310 client,class_1309 ee){
        return ee == client.field_1724 || !ee.method_5805() || filter.contains(ee.method_5864().method_5882())  || client.method_1560()==ee || (ee instanceof net.minecraft.class_1657 && filterPlayer.contains(ee.method_74861()));
    }

    public static void m(){

        class_746 player = class_310.method_1551().field_1724;
        class_310 client = class_310.method_1551();
        if (player == null || client.field_1687 == null) return;


        class_1309 e = getNearestEntity(cfg.RaidR);

        if (e != null && e.method_5805() && e.method_6032() > 0) {
            class_2824 attackPacket = class_2824.method_34206(e, client.field_1724.method_5715());
            double x = player.method_23317();
            double y = player.method_23318();
            double z = player.method_23321();
            for (int i = 0; i < 4; ++i)
                sendPos(x, y, z, false);
            sendPos(x, y + cfg.MacePower/2, z, false);
            sendPos(x, y, z, false);
            client.field_1724.field_3944.method_52787(attackPacket);
            for (int i = 0; i < 4; ++i)
                sendPos(x, y, z, false);
            sendPos(x, y + cfg.MacePower/2, z, false);
            sendPos(x, y, z, false);
            client.field_1724.field_3944.method_52787(attackPacket);
            attack(client,e,player);


            //player.setVelocity(0, 0.1, 0);


            /*=========================*/
            double radius = cfg.RaidR;

            class_243 playerPos = client.field_1724.method_73189();
            double minDistSq = radius * radius;

            // 获取范围内所有活体实体，并过滤掉自己
            List<class_1309> entities = client.field_1687.method_8390(class_1309.class,
                    client.field_1724.method_5829().method_1014(radius),
                    ee -> !filterE(client,ee)
            );

            // 找最近
            for (class_1309 entity : entities) {
                double distSq = playerPos.method_1025(entity.method_73189());
                if (distSq < minDistSq) {
                    e=entity;
                    attack(client,e,player);
                }
            }

            client.field_1724.method_6104(class_1268.field_5808);



        }

    }
    private static void attack(class_310 client, class_1297 e, class_746 player){
        class_2824 attackPacket = class_2824.method_34206(e, client.field_1724.method_5715());
        double x = player.method_23317();
        double y = player.method_23318();
        double z = player.method_23321();
        drawKill(e.method_73189(), (int) ((class_1309) e).method_6032());

        for (int i = 0; i < 4; ++i)
            sendPos(x, y, z, false);
        sendPos(x, y + cfg.MacePower, z, false);
        sendPos(x, y, z, false);
        client.field_1724.field_3944.method_52787(attackPacket);

        player.method_24830(false);
        player.field_6017 = 100;

        for (int i = 0; i < 4; ++i) Objects.requireNonNull(client.method_1562()).method_52787(

                new class_2828.class_2830(
                        e.method_23317(), e.method_23318(), e.method_23321(),
                        player.method_36454(), 90,
                        false, false
                )
        );
        client.field_1724.field_3944.method_52787(attackPacket);
    }
    public static class_1309 getNearestEntity(double radius) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return null;

        class_243 playerPos = mc.field_1724.method_73189();
        double minDistSq = radius * radius;
        class_1309 nearest = null;

        // 获取范围内所有活体实体，并过滤掉自己
        List<class_1309> entities = mc.field_1687.method_8390(class_1309.class,
                mc.field_1724.method_5829().method_1014(radius),
                e -> !filterE(mc,e)
        );

        // 找最近
        for (class_1309 entity : entities) {
            double distSq = playerPos.method_1025(entity.method_73189());
            if (distSq < minDistSq) {
                minDistSq = distSq;
                nearest = entity;
            }
        }

        return nearest;
    }

    private static void draw(){
        class_310 client=all_client;

        double radius = cfg.RaidR;

        class_243 playerPos = client.field_1724.method_73189();
        double minDistSq = radius * radius;

        // 获取范围内所有活体实体，并过滤掉自己
        List<class_1309> entities = client.field_1687.method_8390(class_1309.class,
                client.field_1724.method_5829().method_1014(radius),
                ee -> !filterE(client,ee)
        );

        // 找最近
        for (class_1309 entity : entities) {
            double distSq = playerPos.method_1025(entity.method_73189());
            if (distSq < minDistSq) {
                var pos=entity.method_73189();
                class_243 random = new class_243(Math.random() * 10 - 5, Math.random() * 10 - 5, Math.random() * 10 - 5);
                all_client.field_1687.method_8466(
                        class_2398.field_38908,
                        true,
                        true,
                        pos.field_1352 + random.field_1352,
                        pos.field_1351 + random.field_1351,
                        pos.field_1350 + random.field_1350,
               1,1,1
                );
            }
        }
    }

    private static void drawKill(class_243 pos,int l) {
        if (all_client.field_1687 != null) {
            for (int i = 0; i <l ;++i) {
                class_243 random = new class_243(Math.random() * 1 - 0.5, Math.random() * 1 - 0.5, Math.random() * 1 - 0.5);
                all_client.field_1687.method_8466(
                        class_2398.field_23114,
                        true,
                        true,
                        pos.field_1352 + random.field_1352,
                        pos.field_1351 + random.field_1351,
                        pos.field_1350 + random.field_1350,
                        0 - random.field_1352,
                        0 - random.field_1351,
                        0 - random.field_1350
                );
                 random = new class_243(Math.random() * 1 - 0.5, Math.random() * 1 - 0.5, Math.random() * 1 - 0.5);
                all_client.field_1687.method_8466(
                        class_2398.field_22246,
                        true,
                        true,
                        pos.field_1352 + random.field_1352,
                        pos.field_1351 + random.field_1351,
                        pos.field_1350 + random.field_1350,
                        0 - random.field_1352,
                        0 - random.field_1351,
                        0 - random.field_1350
                );
            }
        }
    }
}
