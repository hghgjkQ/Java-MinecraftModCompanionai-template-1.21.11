package com.companion.effect.weapon;

import static com.companion.global.*;

import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;

import static com.companion.effect.tool.tip;
import static com.companion.effect.weapon.base.sendPos;

public class tp {
    public static void throw_END(class_1799 main){
        tip(111);
        if(true || main.method_7909() == class_1802.field_8634 ){

            double x = player.method_23317();
            double y = player.method_23318();
            double z = player.method_23321();

            // 计算调整后的发射威力：配置值归一化后乘以√500（原版威力计算公式适配）
            double power = 50;
            // 获取玩家视线方向向量，并按调整后的威力缩放
            class_243 lookVec = player.method_5828(1.0F).method_1021(power);

            // 发送4次原位置、地面状态为true的移动包（欺骗服务端的核心步骤）
            for (int i = 0; i < 4; ++i)
                sendPos(x, y, z, false);

            // 发送视线反方向偏移的位置包，强化欺骗效果
            sendPos(x - lookVec.field_1352, y - lookVec.field_1351, z - lookVec.field_1350, false);
            // 发送原位置、地面状态为false的移动包，还原玩家位置状态
            sendPos(x, y, z, false);

            class_310.method_1551().field_1761.method_2919(player, class_1268.field_5808);

        }
    }
}
