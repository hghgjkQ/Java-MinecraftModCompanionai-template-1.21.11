package com.companion.effect.weapon;

import static com.companion.effect.weapon.tool.*;
import static com.companion.global.*;

import net.minecraft.class_1268;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2886;

public class base {
    public static void sendPos(double x, double y, double z, boolean onGround, float ya, float p)
    {
        // 获取网络处理器并发送仅位置的移动包，携带玩家当前旋转角度
        if (all_client.field_1724 != null) {
            all_client.field_1724.field_3944.method_52787(
                    new class_2828.class_2830(
                            new class_243(x,y,z),ya,p, onGround,player.field_5976));
        }
    }
    public static void sendPos(double x, double y, double z, boolean onGround)
    {
        // 获取网络处理器并发送仅位置的移动包，携带玩家当前旋转角度
        if (all_client.field_1724 != null) {
            all_client.field_1724.field_3944.method_52787(
                    new class_2828.class_2829(
                            x,y,z, onGround,player.field_5976));
        }
    }

    public static void startCharging() {
        class_2886 startPacket = new class_2886(class_1268.field_5808, 0,player.method_36454(),player.method_36455());
        player.field_3944.method_52787(startPacket);
    }
    // 停止拉弓/发射（发送停止包）
    public static void releaseBow() {
        class_2846 releasePacket = new class_2846(
                class_2846.class_2847.field_12974,
                player.method_24515(),
                player.method_5735()
        );
        player.field_3944.method_52787(releasePacket);
    }

}
