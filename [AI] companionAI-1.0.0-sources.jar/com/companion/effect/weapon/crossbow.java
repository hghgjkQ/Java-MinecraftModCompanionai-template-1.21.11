package com.companion.effect.weapon;


import static com.companion.global.*;
import static com.companion.effect.tool.tip;
import static com.companion.effect.weapon.base.sendPos;
import static com.companion.skills.Tkill.faceEntity;

import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class crossbow {

    public static void power(class_1799 main){
        if(control && main.method_7909() == class_1802.field_8399 ){
            player.method_6075();
            player.method_36457((float) Math.random()*-80-10);
            player.method_36456((float) Math.random()*360-180);
        }
    }
    public static void setControl(){
        control= !control;
        tip("§econtrol："+control);
    }
}
