package com.companion.effect.weapon;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3532;
import net.minecraft.class_746;

import static com.companion.Key.configTool.cfg;
import static com.companion.effect.tool.tipGame;

public class Elytra {
    // ==============================================
    // ✅ 新增：记录上一帧各方向键的状态（最小侵入，仅加变量）
    // ==============================================
    private static boolean forwardWasPressed = false;
    private static boolean backWasPressed = false;
    private static boolean leftWasPressed = false;
    private static boolean rightWasPressed = false;
    private static boolean jumpWasPressed = false;
    private static boolean sneakWasPressed = false;

    public static void update(class_310 client){
        class_746 player= client.field_1724;
        if (player == null) return;
        if(!cfg.EasyElytraState.get()) return;

        class_243 tarPos=player.method_73189(); // ✅ 修正：用官方推荐的 getPos()
        float yaw = player.method_36454();
        var options = client.field_1690;

        if(player.method_6128()){
            player.method_18800(0,0.1,0);
            player.method_24830(false);
            player.field_6017=0;

            // ==============================================
            // ✅ 新增：疾跑键模式切换（最小侵入，仅加判断分支）
            // ==============================================
            if (options.field_1867.method_1434()) {
                // 【疾跑模式】：按一次动一格，长按不算
                tarPos = handleStepMove(player, yaw, options);
            } else {
                // 【原模式】：保留原有逻辑，最小侵入
                tarPos = handleOriginalMove(player, yaw, options, tarPos);
            }

            // ==============================================
            // ✅ 保留原有摄像机判断和位置设置
            // ==============================================
            forwardWasPressed = options.field_1894.method_1434();
            backWasPressed = options.field_1881.method_1434();
            leftWasPressed = options.field_1913.method_1434();
            rightWasPressed = options.field_1849.method_1434();
            jumpWasPressed = options.field_1903.method_1434();
            sneakWasPressed = options.field_1832.method_1434();
            if (player.method_73189().equals(tarPos) || client.method_1560() != player) {
                player.method_23327(player.method_31477()+0.5, player.method_31478()+0.5, player.method_31479()+0.5);
                return;
            }

            class_243 realPos = getRealWalkBlock(player, tarPos).method_46558();
            player.method_23327(realPos.field_1352, realPos.field_1351, realPos.field_1350);


        }
    }

    // ==============================================
    // ✅ 新增：疾跑模式的「一格移动」逻辑（独立方法，最小侵入）
    // ==============================================
    private static class_243 handleStepMove(class_746 player, float yaw, class_315 options) {
        class_243 tarPos = player.method_73189();
        double step =1.1; // 固定移动1格

        // 检测「按下瞬间」（上升沿：上一帧没按，这一帧按了）
        if (options.field_1894.method_1434() && !forwardWasPressed) {
            float radians = (float) Math.toRadians(yaw);
            double x = -class_3532.method_15374(radians);
            double z = class_3532.method_15362(radians);
            tarPos = tarPos.method_1019(new class_243(x, 0, z).method_1021(step));
        }
        if (options.field_1913.method_1434() && !leftWasPressed) {
            float radians = (float) Math.toRadians(yaw - 90);
            double x = -class_3532.method_15374(radians);
            double z = class_3532.method_15362(radians);
            tarPos = tarPos.method_1019(new class_243(x, 0, z).method_1021(step));
        }
        if (options.field_1849.method_1434() && !rightWasPressed) {
            float radians = (float) Math.toRadians(yaw + 90);
            double x = -class_3532.method_15374(radians);
            double z = class_3532.method_15362(radians);
            tarPos = tarPos.method_1019(new class_243(x, 0, z).method_1021(step));
        }
        if (options.field_1881.method_1434() && !backWasPressed) {
            float radians = (float) Math.toRadians(yaw + 180);
            double x = -class_3532.method_15374(radians);
            double z = class_3532.method_15362(radians);
            tarPos = tarPos.method_1019(new class_243(x, 0, z).method_1021(step));
        }
        if (options.field_1903.method_1434() && !jumpWasPressed) {
            tarPos = tarPos.method_1031(0, step, 0);
        }
        if (options.field_1832.method_1434() && !sneakWasPressed) {
            tarPos = tarPos.method_1031(0, -step, 0);
        }

        return tarPos;
    }

    // ==============================================
    // ✅ 提取原有移动逻辑为独立方法（最小侵入，不破坏原代码）
    // ==============================================
    private static class_243 handleOriginalMove(class_746 player, float yaw, class_315 options, class_243 tarPos) {
        if (options.field_1894.method_1434()) {
            float radians = (float) Math.toRadians(yaw);
            double x = -class_3532.method_15374(radians);
            double z = class_3532.method_15362(radians);
            tarPos = tarPos.method_1019(new class_243(x, 0, z).method_1021(cfg.ElytraSpeed));
        }
        if (options.field_1913.method_1434()) {
            float radians = (float) Math.toRadians(yaw - 90);
            double x = -class_3532.method_15374(radians);
            double z = class_3532.method_15362(radians);
            tarPos = tarPos.method_1019(new class_243(x, 0, z).method_1021(cfg.ElytraSpeed));
        }
        if (options.field_1849.method_1434()) {
            float radians = (float) Math.toRadians(yaw + 90);
            double x = -class_3532.method_15374(radians);
            double z = class_3532.method_15362(radians);
            tarPos = tarPos.method_1019(new class_243(x, 0, z).method_1021(cfg.ElytraSpeed));
        }
        if (options.field_1881.method_1434()) {
            float radians = (float) Math.toRadians(yaw + 180);
            double x = -class_3532.method_15374(radians);
            double z = class_3532.method_15362(radians);
            tarPos = tarPos.method_1019(new class_243(x, 0, z).method_1021(cfg.ElytraSpeed));
        }
        if (options.field_1903.method_1434()) {
            tarPos = tarPos.method_1031(0, cfg.ElytraSpeed, 0);
        }
        if (options.field_1832.method_1434()) {
            tarPos = tarPos.method_1031(0, -cfg.ElytraSpeed, 0);
        }
        return tarPos;
    }

    // ==============================================
    // ✅ 保留原有碰撞检测方法（完全不变）
    // ==============================================
    public static class_243 getRealWalkPosition(class_746 player, class_243 targetPos) {
        class_1937 world = player.method_73183();
        class_243 playerPos = player.method_73189();

        class_243 desiredMove = new class_243(
                targetPos.field_1352 - playerPos.field_1352,
                targetPos.field_1351 - playerPos.field_1351,
                targetPos.field_1350 - playerPos.field_1350
        );

        class_238 playerBox = player.method_18377(player.method_18376()).method_30757(playerPos);
        double maxExpand = Math.max(Math.abs(desiredMove.field_1352), Math.abs(desiredMove.field_1350));
        class_238 collisionArea = playerBox.method_1014(maxExpand);

        Iterable<class_265> shapeIterable = world.method_20812(player, collisionArea);
        List<class_265> collisions = new ArrayList<>();
        for (class_265 shape : shapeIterable) {
            collisions.add(shape);
        }

        class_243 validMove = class_1297.method_20736(
                player,
                desiredMove,
                playerBox,
                world,
                collisions
        );

        return playerPos.method_1019(validMove);
    }

    public static class_2338 getRealWalkBlock(class_746 player, class_243 targetPos) {
        return class_2338.method_49638(getRealWalkPosition(player, targetPos));
    }
}