package com.companion.effect.weapon;

import static com.companion.Key.configTool.cfg;
import static com.companion.effect.ability.*;
import static com.companion.effect.weapon.base.*;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;

import static com.companion.effect.tool.*;
import static com.companion.effect.tool.tp;
import static com.companion.global.*;
public class tool {
    public static void TraceHP(){
        if (traceDMGentity!=null){
            if (TraceEntityHeart!=traceDMGentity.method_6032()){
                tip("§4["+traceDMGentity.method_74861()+"]受到伤害："+(traceDMGentity.method_6032() -TraceEntityHeart));
                TraceEntityHeart=traceDMGentity.method_6032();
            }
        }
    }
    public static void PathShow(){
        if (Path!=null) {
            com.companion.python.show.path();
            if (!Path.isEmpty()) {
                if (miniLeap(Path.get(0).method_10263(), Path.get(0).method_10264(), Path.get(0).method_10260(), 10)) {
                    Path.remove(0);
                }
            }else {
                Path=null;
            }
        }
    }
    public static void Run(boolean emptyHand,boolean sprinting,boolean leftPressed){
        // 4. 首次按下（防止连发）
        if (emptyHand && sprinting && cfg.TpState.get()) {
            if (!wasPressed && leftPressed) {
                // 在这里写你要执行的逻辑

                teleport(5);
            }
        }
    }


    private static final float PRECISION = 1e-6f;

    /**
     * 将浮点型总数值按指定浮点型单值拆分为列表
     * @param num 待拆分的总数值（浮点型，需大于0）
     * @param part 拆分的单值（浮点型，需大于0）
     * @return 拆分后的Float类型列表
     * @throws IllegalArgumentException 入参为非正数时抛出
     */
    public static List<Float> splitFloatNumberToList(float num, float part) {
        // 边界校验：浮点型非正数判断（小于精度阈值即视为0或负数）
        if (num < PRECISION || part < PRECISION) {
            throw new IllegalArgumentException("待拆分数值和拆分单值必须为大于0的浮点型数值");
        }

        List<Float> resultList = new ArrayList<>();
        // 计算完整拆分份数（浮点转整型，自动取整，如5.6→5、6.99→6）
        int quotient = (int) (num / part);
        // 计算余数：替代%取余，浮点运算更精准，避免直接取余的精度误差
        float remainder = num - quotient * part;

        // 添加quotient个拆分单值part（浮点型）
        for (int i = 0; i < quotient; i++) {
            resultList.add(part);
        }

        // 余数大于精度阈值时才添加（排除微小运算误差，如0.0000001视为0）
        if (remainder > PRECISION) {
            resultList.add(remainder);
        }

        return resultList;
    }
    /**
     * 两个Vec3d的核心向量运算
     * @param a 起点Vec3d
     * @param b 终点Vec3d
     */
    public static class_243 vec3dVectorOperation(class_243 a, class_243 b) {
        // 1. 获取从A到B的「差值向量」（原始向量，未归一化，长度=A到B的直线距离）
        class_243 diffVec = b.method_1020(a); // 等价于：new Vec3d(b.x-a.x, b.y-a.y, b.z-a.z)

        return diffVec.method_1029();
    }
    /**
     * 为了便于进行跃迁的方法
     * @param leap_x 目标x
     * @param leap_y 目标y
     * @param leap_z 目标z
     * @param leap_distance 最大跃迁距离
     */
    public static boolean miniLeap(double leap_x,double leap_y,double leap_z,double leap_distance){

        double subX = leap_x - player.method_73189().method_10216();
        double subY = leap_y - player.method_73189().method_10214();
        double subZ =  leap_z - player.method_73189().method_10215();

        double d =Math.sqrt(subX * subX + subZ * subZ+subY*subY); //距离
        if(d>leap_distance) {
            double scale = leap_distance / d; // 计算水平距离后归一化放大 10 倍
            tp(
                    subX * scale,
                    subY * scale,
                    subZ * scale
            );

            return false;
        }else {
            tp(
                    subX,
                    subY,
                    subZ
            );

            return true;
        }
    }

    public static class_2561 ClickChat(String prefix, String clickText, String cmd, String suffix) {
        class_2561 clickPart = class_2561.method_43470(clickText)
                .method_27694(s -> s
                        .method_10958(new class_2558.class_10609(cmd))
                        .method_10949(new class_2568.class_10613(class_2561.method_43470("执行指令：" + cmd)))
                );
        return class_2561.method_43470(prefix).method_10852(clickPart).method_10852(class_2561.method_43470(suffix));
    }

}


