package com.companion.effect.weapon;

import com.companion.ParticleManage;
import com.companion.effect.show;

import static com.companion.Key.configTool.cfg;
import static com.companion.effect.tool.tip;
import static com.companion.effect.weapon.base.*;
import static com.companion.effect.ability.*;
import static com.companion.effect.weapon.tool.*;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

import static com.companion.CompanionAIClient.*;
import static com.companion.draw.base.line;
import static com.companion.draw.high.MagicArray;
import static com.companion.skills.Tkill.*;
import static com.companion.global.*;

public class Spear {
    private static boolean killState = false;
    private static boolean spearState=false;
    private static class_243 pos=new class_243(0,0,0);
    public static void spear(boolean leftPressed, class_1799 main){

        if (cfg.SpearState.get()) {
            if (TarEntity == null || !isSpearItemByEnumeration(main)) {
                MidText = "";
            } else {
                show.s();
                MidText = "[" + ModName + "] 长矛已瞄准[" + TarEntity.method_74861() + "]！";
            }

            int SPEAR_count = player.method_6048();
            if (SPEAR_count <= 0) {
                pos = player.method_73189();
            }
            class_243 lookVec;


            if (TarEntity != null && isSpearItemByEnumeration(main)) {
                /*
                if (leftPressed) {
                    MinecraftClient.getInstance().options.getFov().setValue(Math.max(30, fov - SPEAR_count * SPEAR_count));
                } else {
                    MinecraftClient.getInstance().options.getFov().setValue(fov);
                }

                */
                pos = player.method_73189();
                double x = pos.method_10216();
                double y = pos.method_10214();
                double z = pos.method_10215();
                if (TarEntity.method_5805() && SPEAR_count > 0) {
                    var c = faceEntity(player, TarEntity, leftPressed);
                    midEffect(SPEAR_count);


                    lookVec = player.method_5828(1.0F).method_1021(cfg.SpearPower);
                    for (int i = 0; i < 4; ++i)
                        sendPos(x, y, z, false, c.get(0), c.get(1));
                    sendPos(x - lookVec.field_1352, y - lookVec.field_1351, z - lookVec.field_1350, false, c.get(0), c.get(1));
                    sendPos(x, y, z, false, c.get(0), c.get(1));

                    /*
                    if(killState){

                        if(miniLeap(TarEntity.getX(),TarEntity.getEyeY()+1,TarEntity.getZ(),10)) {
                            killState = false;
                        }


                    }else{
                        if(miniLeap(TarEntity.getX(),TarEntity.getEyeY()+10,TarEntity.getZ(),10)) {
                            killState = true;
                        }
                    }

                     */




                } else if (TarEntity.method_6032() <= 0) {
                    class_310.method_1551().field_1690.method_41808().method_41748(fov);
                    killEffect();
                    releaseBow();
                }
            }
            if ((leftPressed && isSpearItemByEnumeration(main)) || (TarEntity == null && SPEAR_count <= 0 && isSpearItemByEnumeration(main))) {
                run();
            }
        }else{
            MidText = "";
            if (isSpearItemByEnumeration(main)) {
                pos = player.method_73189();

                double x = pos.method_10216();
                double y = pos.method_10214();
                double z = pos.method_10215();
                class_243 lookVec = player.method_5828(1.0F).method_1021(1);
                com.companion.draw.base.line(pos,new class_243(x + lookVec.field_1352, y + lookVec.field_1351, z + lookVec.field_1350),1, ParticleManage.YELLOW_POINT_PARTICLE);
                if (leftPressed && spearState) {


                    lookVec = player.method_5828(1.0F).method_1021(1);
                    for (int i = 0; i < 4; ++i)
                        sendPos(x, y, z, false);
                    sendPos(x - lookVec.field_1352, y - lookVec.field_1351, z - lookVec.field_1350, false);
                    sendPos(x, y, z, false);

                    lookVec = player.method_5828(1.0F).method_1021(5);
                    for (int i = 0; i < 4; ++i)
                        sendPos(x, y, z, false);
                    sendPos(x - lookVec.field_1352, y - lookVec.field_1351, z - lookVec.field_1350, false);
                    sendPos(x, y, z, false);

                    spearState=false;
                    }else{
                    if(!spearState) {
                        spearState = true;
                    }
                }
            }
        }

    }

    public static void midEffect(int SPEAR_count){
        // F3显示角度的归一化逻辑：无界原生值 → 0~360°正范围
        List<Float> c= faceEntity(player.method_73189(),TarEntity.method_73189());
        float rawYaw = c.get(0);
        float showYaw = (rawYaw + 180.0F) % 360.0F; // 先补偿基准，再取模
        if (showYaw < 0.0F) {
            showYaw += 360.0F; // 修正负数，保证0~360°
        }
        float xx=180 - (c.get(1)+ 90);
        float yy= 360 - showYaw;

        class_243 lookVec = vec3dVectorOperation(player.method_73189(),TarEntity.method_73189()).method_1021(Math.min(player.method_33571().method_1022(TarEntity.method_33571()), SPEAR_count));

        MagicArray(player.method_33571().method_1019(lookVec), (double) 5 / 20 * Math.min(20, SPEAR_count), SPEAR_count * SPEAR_count, class_2398.field_29644, 3, xx,yy);

    }

    public static void killEffect(){
        int y = 0;
        for (float i : splitFloatNumberToList(TarEntity.method_6063() / 20, 20)) {
            MagicArray(TarEntity.method_73189().method_1031(0, y, 0), i, 0, class_2398.field_11240, 3, 0, 0);
            for (int ii = 0; ii < 10; ++ii) {
                line(TarEntity.method_33571(), TarEntity.method_33571().method_1031(Math.random() * 10 - 5, 100, Math.random() * 10 - 5), 3, class_2398.field_11207);
            }
            if (all_client.field_1687 != null) {
                all_client.field_1687.method_67392(
                        class_3417.field_14865,
                        class_3419.field_15252,
                        10.0F, player.method_36455()
                );
            }
            y += 1;
        }
        TarEntity = null;
    }
    /**
     * 枚举方式判断物品栈是否属于矛类（所有材质）
     * @param stack 待判断的物品栈
     * @return true=属于矛类，false=不属于矛类
     */
    public static boolean isSpearItemByEnumeration(class_1799 stack) {
        // 1. 防御性校验：空指针/空物品栈直接返回false
        if (stack == null || stack.method_7960()) {
            return false;
        }

        // 2. 所有矛类物品集合（集中管理，易扩展）
        Set<class_1792> SPEAR_ITEMS = Set.of(
                class_1802.field_63389,
                class_1802.field_63385,
                class_1802.field_63388,
                class_1802.field_63386,
                class_1802.field_63387,
                class_1802.field_63384,
                class_1802.field_63390
        );

        // 3. 单次判断替代多个if
        return SPEAR_ITEMS.contains(stack.method_7909());
    }


}
