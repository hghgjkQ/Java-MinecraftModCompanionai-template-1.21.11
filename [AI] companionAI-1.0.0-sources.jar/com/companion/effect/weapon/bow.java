package com.companion.effect.weapon;

import java.util.Objects;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_310;

import static com.companion.Key.configTool.cfg;
import static com.companion.effect.ability.*;
import static com.companion.effect.weapon.base.*;
import static com.companion.effect.weapon.tool.*;

import static com.companion.global.*;
import static com.companion.global.player;
import static com.companion.skills.Tkill.getEyeEntity;

public class bow {
    public static void bow( class_1799 main,class_1799 main2){
        var player = class_310.method_1551().field_1724;
        if (cfg.RaidState.get()) {
            if (cfg.BowState.get() && main2.method_7909() == class_1802.field_8102) {
                if (player.method_6048() >4) {
                    // 获取玩家当前三维坐标
                    double x = player.method_23317();
                    double y = player.method_23318();
                    double z = player.method_23321();

                    // 计算调整后的发射威力：配置值归一化后乘以√500（原版威力计算公式适配）
                    double power = 10;
                    double adjustedStrength = power / 10.0 * Math.sqrt(500.0);
                    // 获取玩家视线方向向量，并按调整后的威力缩放
                    class_243 lookVec = player.method_5828(1.0F).method_1021(adjustedStrength);


                    // 发送4次原位置、地面状态为true的移动包（欺骗服务端的核心步骤）
                    for (int i = 0; i < 4; ++i)
                        sendPos(x, y, z, false);

                    // 发送视线反方向偏移的位置包，强化欺骗效果
                    sendPos(x - lookVec.field_1352, y - lookVec.field_1351, z - lookVec.field_1350, false);
                    // 发送原位置、地面状态为false的移动包，还原玩家位置状态
                    sendPos(x, y, z, false);
                    releaseBow();

                    class_1309 e = getEyeEntity(1000);
                    var client = class_310.method_1551();
                    if (e != null && e.method_5805() && e.method_6032() > 0) {
                        Objects.requireNonNull(client.method_1562()).method_52787(
                                new class_2828.class_2830(
                                        e.method_23317(), e.method_23318(), e.method_23321(),
                                        client.field_1724.method_36454(), client.field_1724.method_36455(),
                                        false, false
                                )
                        );
                        // 自动切换到该槽位
                        for (int i = 0; i < 4; ++i)
                            sendPos(x, y, z, false);

                        // 发送视线反方向偏移的位置包，强化欺骗效果
                        sendPos(x, y + 20, z, false);
                        // 发送原位置、地面状态为false的移动包，还原玩家位置状态
                        sendPos(x, y, z, false);
                        class_2824 attackPacket = class_2824.method_34206(e, client.field_1724.method_5715());
                        client.field_1724.field_3944.method_52787(attackPacket);
                        // 6. (可选) 播放客户端动画和挥臂效果，提升体验
                        client.field_1724.method_6104(class_1268.field_5808);
                        player.method_18800(0,0,0);
                    }
                }
            }
        }else{
            if (cfg.BowState.get() && main.method_7909() == class_1802.field_8102) {
                if (player.method_6048() >10) {
                    // 获取玩家当前三维坐标
                    double x = player.method_23317();
                    double y = player.method_23318();
                    double z = player.method_23321();

                    // 计算调整后的发射威力：配置值归一化后乘以√500（原版威力计算公式适配）
                    double power = 10;
                    double adjustedStrength = power / 10.0 * Math.sqrt(500.0);
                    // 获取玩家视线方向向量，并按调整后的威力缩放
                    class_243 lookVec = player.method_5828(1.0F).method_1021(adjustedStrength);


                    // 发送4次原位置、地面状态为true的移动包（欺骗服务端的核心步骤）
                    for (int i = 0; i < 4; ++i)
                        sendPos(x, y, z, false);

                    // 发送视线反方向偏移的位置包，强化欺骗效果
                    sendPos(x - lookVec.field_1352, y - lookVec.field_1351, z - lookVec.field_1350, false);
                    // 发送原位置、地面状态为false的移动包，还原玩家位置状态
                    sendPos(x, y, z, false);
                    releaseBow();
                }
            }

        }
    }

}
