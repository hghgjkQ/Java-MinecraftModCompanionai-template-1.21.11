package com.companion.Items;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_7923;

public class TianYuanDiFangItem extends class_1792 {
    // 构造方法完全原版，无自定义逻辑
    public TianYuanDiFangItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (!(world instanceof class_3218 serverWorld)) {
            return class_1269.field_5812;
        }

        // 【遍历方块法】获取最高Y坐标
        int targetX = (int) user.method_23317();
        int targetZ = (int) user.method_23321();
        int topY = getTopBlockY(world, targetX, targetZ);
        double spawnY = topY + 1.0D;
        double offsetX = 0.0D;

        for (class_1299<?> entityType : class_7923.field_41177) {
            try {
                class_1297 entity = entityType.method_5883(world, class_3730.field_16465);
                if (!(entity instanceof class_1309)) continue;

                entity.method_5814(user.method_23317() + offsetX, spawnY, user.method_23321());

                if (entity instanceof class_1308 mob) {
                    mob.method_5977(true);
                    mob.method_5875(true);
                    mob.method_5971();
                }
                entity.method_18799(class_243.field_1353);

                serverWorld.method_8649(entity);

                class_238 bb = entity.method_5829();
                offsetX += 3.0D + bb.method_17939();

            } catch (Exception ignored) {}
        }

        user.method_5998(hand).method_7934(1);
        user.method_7353(class_2561.method_43470("§6[天圆地方] §a生成完成！"), true);
        return class_1269.field_5812;
    }

    // 【你要的：遍历方块获取最高Y】纯客户端+服务端兼容
    private int getTopBlockY(class_1937 world, int x, int z) {
        int bottomY = world.method_31607();

        for (int y = 320 - 1; y >= bottomY; y--) {
            class_2338 pos = new class_2338(x, y, z);
            if (!world.method_8320(pos).method_26215()) {
                return y;
            }
        }
        return bottomY;
    }
}