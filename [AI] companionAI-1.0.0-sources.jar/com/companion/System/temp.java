package com.companion.System;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_7923;

import static com.companion.effect.tool.error;
import static com.companion.global.*;

public class temp {
    // 兼容所有Java版本，无需Stream API
    public static List<class_1792> getAllItemsLegacy() {
        List<class_1792> items = new ArrayList<>();
        // 遍历注册表的所有条目
        for (class_1792 item : class_7923.field_41178) {
            if (item != null && item != class_1802.field_8162) {
                items.add(item);
            }
        }
        return items;
    }
    public static Map<String,String> mainly() {
        Item_DICT.clear();
        Item_English_DICT.clear();
        Map<String, String> content = new HashMap<>();
        var s = getAllItemsLegacy();

        for (class_1792 c : s) {
            content.put(c.method_7854().method_63693().getString(), getLastPartAfterDot(c.method_7876()));
            Item_DICT.put(c.method_7854().method_63693().getString(), c);
            Item_English_DICT.put(getLastPartAfterDot(c.method_7876()),c);
        }

        return content;

    }
    /**
     * 截取字符串最后一个 . 后面的内容
     * 例：minecraft.diamond → diamond
     *     a.b.c → c
     *     test → test（无点则返回原文）
     */
    private static String getLastPartAfterDot(String str) {
        if (str == null || str.isEmpty()) return str;
        int lastDotIndex = str.lastIndexOf('.');
        // 无点 或 点在最后一位，返回原字符串
        if (lastDotIndex == -1 || lastDotIndex == str.length() - 1) {
            return str;
        }
        // 截取最后一个点之后的内容
        return str.substring(lastDotIndex + 1);
    }
}
