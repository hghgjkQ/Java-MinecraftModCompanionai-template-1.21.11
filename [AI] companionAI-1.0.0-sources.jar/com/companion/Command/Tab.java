package com.companion.Command;

import com.companion.draw.base;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.companion.effect.tool.tipGame;
import static com.companion.global.*;
import static com.companion.render3D.screen.Text;
import static com.companion.render3D.screen.blocks;


public class Tab {

    // 建议提供者：自动从字典 KEY 生成提示词
    private static final SuggestionProvider<FabricClientCommandSource> DICT_KEY_SUGGESTIONS = (context, builder) -> {
        // 把你字典的所有 key 变成命令提示词
        for (String key : YOUR_DICT.keySet()) {
            builder.suggest(key); // 每个 key 都会显示在命令补全里
        }
        return builder.buildFuture();
    };
    private static final SuggestionProvider<FabricClientCommandSource> DICT_KEY_SUGGESTIONS2 = (context, builder) -> {
        // 把你字典的所有 key 变成命令提示词
        for (String key : Item_English_DICT.keySet()) {
            builder.suggest(key); // 每个 key 都会显示在命令补全里
        }
        return builder.buildFuture();
    };

    public static LiteralArgumentBuilder<FabricClientCommandSource> reg(LiteralArgumentBuilder<FabricClientCommandSource> tab){
        tab.then(ClientCommandManager.literal("find")
                .then(ClientCommandManager.argument("key", StringArgumentType.string())
                        .suggests(DICT_KEY_SUGGESTIONS) // 绑定提示词
                        .executes(ctx -> {
                            // 获取输入的 key
                            String inputKey = StringArgumentType.getString(ctx, "key");
                            String value = YOUR_DICT.get(inputKey);

                            tipGame("提示词",inputKey+"对应："+value);
                            all_client.field_1774.method_1455(value);
                            return 1;
                        })
                )
        );

        tab.then(ClientCommandManager.literal("check")
                .then(ClientCommandManager.argument("key", StringArgumentType.string())
                        .suggests(DICT_KEY_SUGGESTIONS) // 绑定提示词
                        .executes(ctx -> {
                            // 获取输入的 key
                            String inputKey = StringArgumentType.getString(ctx, "key");
                            class_1792 value =Item_DICT.get(inputKey);

                            return FindChest.find(value);
                        })
                )
        );
        tab.then(ClientCommandManager.literal("lookfor")
                .executes(ctx -> {
                    // 获取输入的 key
                    return FindChest.find(player.method_6047().method_7909());
                })

        );
        tab.then(ClientCommandManager.literal("discover")
                .then(ClientCommandManager.argument("key", StringArgumentType.string())
                        .suggests(DICT_KEY_SUGGESTIONS2) // 绑定提示词
                        .executes(ctx -> {
                            // 获取输入的 key
                            String inputKey = StringArgumentType.getString(ctx, "key");
                            class_1792 value =Item_DICT.get(inputKey);

                            return FindChest.find(value);
                        })
                )
        );
        tab.then(ClientCommandManager.literal("clear")

                        .executes(ctx -> {
                            blocks.clear();
                            Text.clear();
                            return 1;
                        })

        );
        tab.then(ClientCommandManager.literal("time")
                .executes(ctx -> {
                    tipGame("美国时间：",t());
                    return 1;
                })
        );

        tab.then(ClientCommandManager.literal("bedrock")
                .executes(ctx -> {
                    class_310 client = class_310.method_1551();
                    class_746 player = client.field_1724;
                    class_1937 world = client.field_1687;

                    if (player == null || world == null) return 0;

                    int px = (int) player.method_23317();
                    int pz = (int) player.method_23321();
                    int y = 127; // 固定高度

                    // 遍历 X: -20 ~ +20
                    for (int x = px - 30; x <= px + 30; x++) {
                        // 遍历 Z: -20 ~ +20
                        for (int z = pz - 30; z <= pz + 30; z++) {
                            class_2338 pos = new class_2338(x, y, z);
                            // 判断是不是基岩
                                if (world.method_8320(pos.method_10074()).method_27852(class_2246.field_9987) ||world.method_8320(pos.method_10087(2)).method_27852(class_2246.field_9987)||world.method_8320(pos.method_10087(3)).method_27852(class_2246.field_9987)||world.method_8320(pos.method_10087(4)).method_27852(class_2246.field_9987)||world.method_8320(pos.method_10087(5)).method_27852(class_2246.field_9987)||world.method_8320(pos.method_10087(6)).method_27852(class_2246.field_9987)) {
                                    continue;
                                }

                            base.line(pos.method_46558(),pos.method_10086(10).method_46558(),5,class_2398.field_11211);

                        }
                    }
                    return 1;
                })
        );
        return tab;
    }
    public static String t() {
        // 对应 Python: p='零一二三四五六七'
        char[] weekChars = "零一二三四五六七".toCharArray();
        // 获取当前本地时间（等价 time.localtime()）
        LocalDateTime now = LocalDateTime.now();

        int hour = now.getHour();
        int minute = now.getMinute();
        int second = now.getSecond();
        // Python: tm_wday 0=周一,6=周日
        int weekDay = now.getDayOfWeek().getValue() - 1;

        int weekNum;
        String timePeriod;
        String timeStr;

        // 严格复刻你的判断逻辑
        if (hour > 12) {
            weekNum = weekDay + 1;
            timePeriod = "早上";
            timeStr = String.format("%d:%d:%d", hour - 12, minute, second);
        } else {
            if (weekDay == 0) {
                weekNum = 7;
            } else {
                weekNum = weekDay;
            }
            timePeriod = "晚上";
            timeStr = String.format("%d:%d:%d", hour, minute, second);
        }

        // 输出结果（和Python打印完全一致）
        return   String.format("星期%c的%s %s%n",weekChars[weekNum], timePeriod,timeStr);
    }

}
