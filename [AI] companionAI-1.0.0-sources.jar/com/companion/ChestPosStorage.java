package com.companion;

import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_638;

public class ChestPosStorage {
    private static class_2338 currentChestPos=null;

    public static void setCurrentChestPos(class_2338 pos) {
        currentChestPos = pos;
    }

    public static class_2338 getCurrentChestPos() {
        return currentChestPos;
    }

    public static void clear() {
        currentChestPos = null;
    }
    /**
     * 获取双箱的最小坐标（xyz和最小）
     * @param clickedPos 玩家点击的箱子坐标
     * @param world 客户端世界
     * @return 最小坐标（如果是单箱则返回原坐标）
     */
    public static class_2338 getMinChestPos(class_2338 clickedPos, class_638 world) {
        class_2680 state = world.method_8320(clickedPos);

        // 检查是不是箱子
        if (!(state.method_26204() instanceof class_2281)) {
            return clickedPos;
        }

        // 获取箱子朝向
        class_2350 facing = state.method_11654(class_2281.field_10768);

        // 获取箱子类型（单箱、左半、右半）
        class_2745 chestType = state.method_11654(class_2281.field_10770);

        if (chestType == class_2745.field_12569) {
            // 单箱，直接返回
            return clickedPos;
        }

        // 计算另一半的坐标
        // 注意：CHEST_TYPE 的 LEFT/RIGHT 是相对于玩家视角的
        // LEFT = 玩家在左半边，RIGHT = 玩家在右半边
        // 但实际上，从方块朝向看：
        // 如果 facing 是北（Z-），左半在西（X-），右半在东（X+）
        // 需要找到与 facing 垂直的方向

        class_2350 otherHalfDir;
        if (chestType == class_2745.field_12574) {
            // 当前是左半，另一半在右边（顺时针90度）
            otherHalfDir = facing.method_10170();
        } else {
            // 当前是右半，另一半在左边（逆时针90度）
            otherHalfDir = facing.method_10160();
        }

        class_2338 otherPos = clickedPos.method_10093(otherHalfDir);

        // 验证另一半确实是箱子
        class_2680 otherState = world.method_8320(otherPos);
        if (!(otherState.method_26204() instanceof class_2281)) {
            // 不是双箱，返回原坐标
            return clickedPos;
        }

        // 比较两个坐标，返回 xyz 和最小的
        return comparePos(clickedPos, otherPos) <= 0 ? clickedPos : otherPos;
    }

    private static int comparePos(class_2338 a, class_2338 b) {
        if (a.method_10263() != b.method_10263()) return Integer.compare(a.method_10263(), b.method_10263());
        if (a.method_10264() != b.method_10264()) return Integer.compare(a.method_10264(), b.method_10264());
        return Integer.compare(a.method_10260(), b.method_10260());
    }
}