package com.companion.Key;

import com.companion.System.findEndCity;
import com.companion.effect.ability;
import com.companion.effect.weapon.crossbow;
import com.companion.effect.weapon.hook;
import com.companion.effect.weapon.raid;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;

import static com.companion.Key.configTool.cfg;
import static com.companion.global.*;
import static com.companion.effect.tool.*;

import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.util.List;

import static com.companion.effect.weapon.tp.throw_END;
import static com.companion.skills.Tkill.*;

import static com.companion.global.*;
@Environment(EnvType.CLIENT)
public class main {

    // 3. 响应
    public static void start() {
        com.companion.Key.tool.reg();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if(com.companion.Key.tool.keyBox[0].method_1436()) {
                if (client.field_1724 != null) client.execute(main::throwA);
            }
            if(com.companion.Key.tool.keyBox[1].method_1436()) {
                if (client.field_1724 != null) client.execute(main::trace);
            }
            if(com.companion.Key.tool.keyBox[2].method_1436()) {
                if (client.field_1724 != null) client.execute(crossbow::setControl);
            }
            if(com.companion.Key.tool.keyBox[3].method_1436()) {
                if (client.field_1724 != null) client.execute(()-> {

                    raid.m();

                });
            }
            if(com.companion.Key.tool.keyBox[4].method_1436()) {
                if (client.field_1724 != null) client.execute(() -> {
                    throw_END(player.method_6047());

                });
            }
            if(com.companion.Key.tool.keyBox[5].method_1436()) {
                if (client.field_1724 != null) client.execute(() -> {
                    client.method_1507(new configTool(client.field_1755));

                });
            }
            if(com.companion.Key.tool.keyBox[6].method_1436()) {
                if (client.field_1724 != null) client.execute(hook::retractFishingRod);
            }

        });
    }
    private static class_243 playerPos = new class_243(0,0,0); //速度显示
    public static void speed(){
        ClientTickEvents.END_CLIENT_TICK.register(client -> updateSpeedometer());
    }



    private static void updateSpeedometer() {
        if (cfg.enableSpeedShow.get())
            if ((player != null)) {
                double v = playerPos.method_1022(player.method_73189());
                playerPos = player.method_73189();
                tip(String.format("当前速度：§6%.2f§fB/T（§6%.2f§fkm/h）", v, v * 72), true);
                if (traceDMGentity != null && !traceDMGentity.method_5805()) {
                    traceDMGentity = null;
                }
            }

    }
    public static void trace(){
        traceDMGentity=getEyeEntity(100);
        if (traceDMGentity != null) {
            TraceEntityHeart=traceDMGentity.method_6032();
        }
    }

    public static void throwA(){
        TarEntity = getNearestPlayer(player);

    }
    // 以指定玩家为原点，获取世界中最近的其他有效玩家（无最大搜索半径，1.21.11专属最简版）
    public static class_1309 getNearestPlayer(class_1657 source) {
        // 仅做核心非空校验，最简判空
        if (source == null) return null;
        class_1937 level= source.method_73183();
        List<class_1657> players = List.copyOf(level.method_18456());
        // 无玩家/仅自身，直接返回null
        if (players.size() <= 1) return null;

        class_1657 nearest = null;
        double minDistSq = Double.MAX_VALUE;
        // 遍历+核心有效玩家筛选，无冗余逻辑
        for (class_1657 p : players) {
            // 有效玩家：非自身 + 存活 + 已加载（1.21.11有效状态核心判定）
            if (p != source && p.method_5805()) {
                double distSq = source.method_5739(p); // 原生距离平方，无需手动计算
                if (distSq < minDistSq) {
                    minDistSq = distSq;
                    nearest = p;
                }
            }
        }
        return nearest;
    }

}
