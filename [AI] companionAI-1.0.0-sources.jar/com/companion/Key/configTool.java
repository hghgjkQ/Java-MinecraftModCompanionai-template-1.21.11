package com.companion.Key;

import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

import static com.companion.global.ModName;


public class configTool extends class_437 {
    // 在你的 configTool 类中添加：
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // 【必须放在最前面】先绘制背景、按钮、输入框等所有已有组件
        super.method_25394(context, mouseX, mouseY, delta);

        // ========== 下面自定义绘制文字 ==========

        // 1. 顶部大标题（居中、加粗、金色）
        String title = ModName+"设置";
        int titleWidth = field_22793.method_1727(title);
        context.method_51439(
                field_22793,
                class_2561.method_43470("§l§6" + title),
                (this.field_22789 - titleWidth) / 2,  // 水平居中
                6,                               // 顶部Y坐标
                0xFFFFFFFF,                      // 文字颜色（ARGB，不透明白）
                true                             // 是否带阴影
        );


        // 3. 输入框旁的提示标签
        context.method_51439(field_22793, class_2561.method_43470("§7威力(模拟高度)"), 220, 245, 0xFFFFFFFF, true);
        context.method_51439(field_22793, class_2561.method_43470("§7半径"), 340, 245, 0xFFFFFFFF, true);
    }

    private final class_437 parent;
    public static config cfg = null;


    public configTool(class_437 parent) {
        super(class_2561.method_43470(ModName+"设置"));
        this.parent = parent;
        cfg = config.load();
    }

    public void create_Button(AtomicBoolean target, int x, int y, int width, int height, String name){
        method_37063(
                class_4185.method_46430(
                        class_2561.method_43470((target.get() ? "§6" : "")+name+ onOff(target.get())),
                        b -> {
                            target.set(!target.get());
                            b.method_25355(class_2561.method_43470((target.get() ? "§6" : "")+name+ onOff(target.get())));
                        }).method_46434(x,y,width,height).method_46431()
        );
    }

    private class_342 cmdField; //声明文本框
    private class_342 t1; //声明文本框
    private class_342 t2; //声明文本框
    private class_342 t3; //声明文本框
    private class_342 t4; //声明文本框



    @Override
    protected void method_25426() {
        int center = this.field_22789 / 2;
        create_Button(cfg.TpState,20, 20, 200, 20,"空手疾跑左键瞬移: ");
        create_Button(cfg.enableAutoLogin,20, 40, 200, 20,"自动登入（下面是指令内容）: ");
        create_Button(cfg.enableNoFall,20, 80, 200, 20,"免疫摔落: ");
        // 登入指令文本框
        cmdField = new class_342(field_22793, 20, 60, 200, 20, class_2561.method_43470("登入指令"));
        cmdField.method_1852(cfg.loginCommand);
        method_37063(cmdField);
        create_Button(cfg.enableSpeedShow,20, 100, 200, 20,"速度显示：");
        create_Button(cfg.RaidState,20, 120, 200, 20,"神杀：");
        create_Button(cfg.BowState,20, 140, 200, 20,"强弓：");

        create_Button(cfg.SpearState,20, 160, 200, 20,"狙击枪：");
        t1 = new class_342(field_22793, 220, 160, 50, 20, class_2561.method_43470("狙击枪威力"));
        t1.method_1852(String.valueOf(cfg.SpearPower));
        method_37063(t1);

        create_Button(cfg.enableAutoRaid,20, 200, 200, 20,"自动袭击：");
        create_Button(cfg.enableAutoAfk,20, 220, 200, 20,"nrnb挂机：");

        create_Button(cfg.enableMace,20, 240, 200, 20,"湮灭：");
        t2 = new class_342(field_22793, 285, 240, 50, 20, class_2561.method_43470("威力"));
        t2.method_1852(String.valueOf(cfg.MacePower));
        method_37063(t2);

        create_Button(cfg.EasyElytraState,20, 260, 200, 20,"简单鞘翅：");
        t3 = new class_342(field_22793, 220, 260, 50, 20, class_2561.method_43470("速度"));
        t3.method_1852(String.valueOf(cfg.ElytraSpeed));
        method_37063(t3);

        method_37063(
                class_4185.method_46430(
                        class_2561.method_43470("重锤过滤设置(mace filter)"),
                        b -> {

                            cfg.loginCommand = cmdField.method_1882();

                            cfg.SpearPower = Double.parseDouble(t1.method_1882());
                            cfg.MacePower = Double.parseDouble(t2.method_1882());
                            cfg.ElytraSpeed = Double.parseDouble(t3.method_1882());
                            cfg.RaidR = Double.parseDouble(t4.method_1882());
                            config.save(cfg);
                            var data=config.load();


                            field_22787.method_1507(new maceConfig(field_22787.field_1755));
                        }).method_46434(410,240,120,20).method_46431()
        );
        t4 = new class_342(field_22793, 360, 240, 50, 20, class_2561.method_43470("半径r"));
        t4.method_1852(String.valueOf(cfg.RaidR));
        method_37063(t4);




        // 保存并退出
        method_37063(class_4185.method_46430(
                class_2561.method_43470("保存并关闭"),
                b -> {
                    cfg.loginCommand = cmdField.method_1882();

                    cfg.SpearPower = Double.parseDouble(t1.method_1882());
                    cfg.MacePower = Double.parseDouble(t2.method_1882());
                    cfg.ElytraSpeed = Double.parseDouble(t3.method_1882());
                    cfg.RaidR = Double.parseDouble(t4.method_1882());
                    config.save(cfg);
                    var data=config.load();
                    if (field_22787 != null) field_22787.method_1507(parent);
                }).method_46434(20, 300, 200, 20).method_46431());
    }

    private static String onOff(boolean b) {
        return b ? "开" : "关";
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);

    }
}