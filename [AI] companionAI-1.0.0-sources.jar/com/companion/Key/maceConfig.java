package com.companion.Key;

import com.companion.effect.weapon.ModFilterConfig;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWScrollCallback;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

import static com.companion.effect.tool.tip;
import static com.companion.effect.tool.tipGame;
import static com.companion.global.*;


public class maceConfig extends class_437 {
    private final class_437 parent;
    private static double move=0;
    private static double moveV=0;
    private static double move2=0;
    private static double move2V=0;
    private static boolean leftPressed;
    private static int leftPressed2;
    private static GLFWScrollCallback originalScrollCallback;

    private class_342 EntityChoose; //声明文本框
    private class_342 PlayerChoose; //声明文本框

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // 【必须放在最前面】先绘制背景、按钮、输入框等所有已有组件
        super.method_25394(context, mouseX, mouseY, delta);

        // ========== 下面自定义绘制文字 ==========

        // 1. 顶部大标题（居中、加粗、金色）
        String title = ModName+" - 重锤过滤设置";
        int titleWidth = field_22793.method_1727(title);
        context.method_51439(
                field_22793,
                class_2561.method_43470("§l§6" + title),
                (this.field_22789 - titleWidth) / 2,  // 水平居中
                6,                               // 顶部Y坐标
                0xFFFFFFFF,                      // 文字颜色（ARGB，不透明白）
                true                             // 是否带阴影
        );


        // 3. 输入框旁的提示标签
        context.method_51439(field_22793, class_2561.method_43470("§l§6生物过滤选择"), (this.field_22789 - titleWidth) / 2-200, 50, 0xFFFFFFFF, true);
        context.method_51439(field_22793, class_2561.method_43470("§6§l玩家过滤选择"), (this.field_22789 - titleWidth) / 2+200, 50, 0xFFFFFFFF, true);

        //手搓滑动条方法
        leftPressed = GLFW.glfwGetMouseButton(field_22787.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_1) == GLFW.GLFW_PRESS; // 3. 左键按下
        if(leftPressed ){
            if(leftPressed2==0) {
                leftPressed2 = 1;
            }
        }else{
            leftPressed2=0;
        }


        int mx= mouseX;
        int my= mouseY;
        long windowHandle = field_22787.method_22683().method_4490(); // 1. 获取游戏窗口的 GLFW 句柄
        GLFW.glfwSetScrollCallback(windowHandle, (window, scrollX, scrollY) -> { // 3. 设置我们自己的回调
            if (mx<this.field_22789/2 && my>90 && my <300){
                moveV+= (scrollY*10);
            }
            else if (mx>this.field_22789/2 && my>90 && my <300){
                move2V+= (scrollY*10);
            }
        });

        List<String> TE=new ArrayList<>(EntityTableCode2);
        Set<String> TP=new HashSet<>(AllPlayer);

        if(!Objects.equals(EntityChoose.method_1882(), "")){
            TE = TE.stream()
                    .filter(s -> s.contains(EntityChoose.method_1882()) || class_2561.method_43471(s).getString().contains(EntityChoose.method_1882()))
                    .toList();
        }
        if(!Objects.equals(PlayerChoose.method_1882(), "")){
            TP = new HashSet<>(TP.stream()
                    .filter(s -> s.contains(PlayerChoose.method_1882()))
                    .toList());
        }


        moveV*=0.9;
        move+=moveV;
        int size=TE.size();


        if (move>0)move=0;
        if (move<-size*20+200)move=-size*20+200;
        context.method_51439(field_22793, class_2561.method_43470("§l------------------------------------------"), 3, 90, 0xFFC0C0C0, true);
        context.method_51439(field_22793, class_2561.method_43470("§l------------------------------------------"), 3, 300, 0xFFC0C0C0, true);
        for(int i=0;i<11;i++){
            int index =size>10 ? (i + Math.abs((int) move) / 20) : i;
            if (index>size-1)break;
            String raw=TE.get(index);
            String target=class_2561.method_43471(raw).getString()+"("+raw.replaceFirst("entity.minecraft.","")+")";

            int posY=100+20*i+ ((int)move)%20;
            if (mx<this.field_22789/2 && my>posY-6 && my <posY+14){
                context.method_51439(field_22793,class_2561.method_43470("§l§a"+target) , 6,posY , 0xFFFFFFFF, true);
                if(leftPressed2==1){
                    if(filter.contains(raw)) {
                        filter.remove(raw);
                    }
                    else{
                        filter.add(raw);
                    }
                    ModFilterConfig.save();
                    leftPressed2=2;
                }
            }else{
                context.method_51439(field_22793,class_2561.method_43470(target) , 6,posY , 0xFFFFFFFF, true);
            }

            if(filter.contains(raw)) {
                context.method_51439(field_22793, class_2561.method_43470("§4§l■"), this.field_22789 / 2, posY - 2, 0xFFFFFFFF, true);
            }else{
                context.method_51439(field_22793, class_2561.method_43470("■"), this.field_22789 / 2, posY - 2, 0xFFFFFFFF, true);
            }



        }

        //玩家处


        move2V*=0.9;
        move2+=move2V;

        size= TP.size();

        int start=this.field_22789 / 2+10;
        if (move2>0)move2=0;
        if (move2<-size*20+200)move2=-size*20+200;
        context.method_51439(field_22793, class_2561.method_43470("§l------------------------------------------"), start, 90, 0xFFC0C0C0, true);
        context.method_51439(field_22793, class_2561.method_43470("§l------------------------------------------"), start, 300, 0xFFC0C0C0, true);

        for(int i=0;i<11;i++) {

            int index =size>10 ? (i + Math.abs((int) move2) / 20) : i;
            if (index > size - 1) break;

            String raw = TP.stream().toList().get(index);

            int posY = 100 + 20 * i + ((int) move2) % 20;
            if (mx > this.field_22789 / 2 && my > posY - 6 && my < posY + 14) {
                context.method_51439(field_22793, class_2561.method_43470("§l§a" + raw), start+6, posY, 0xFFFFFFFF, true);
                if (leftPressed2 == 1) {
                    if (filterPlayer.contains(raw)) {
                        filterPlayer.remove(raw);
                    } else {
                        filterPlayer.add(raw);
                    }
                    ModFilterConfig.save();
                    leftPressed2 = 2;
                }
            } else {
                context.method_51439(field_22793, class_2561.method_43470(raw), start+6, posY, 0xFFFFFFFF, true);
            }

            if (filterPlayer.contains(raw)) {
                context.method_51439(field_22793, class_2561.method_43470("§4§l■"), this.field_22789-10, posY - 2, 0xFFFFFFFF, true);
            } else {
                context.method_51439(field_22793, class_2561.method_43470("■"), this.field_22789-10, posY - 2, 0xFFFFFFFF, true);
            }
        }
    }


    public maceConfig(class_437 parent) {
        super(class_2561.method_43470(ModName+"重锤过滤设置"));
        this.parent = parent;
        ModFilterConfig.load();
    }
    public void create_Button(AtomicBoolean target, int x, int y, int width, int height, String name){
        method_37063(
                class_4185.method_46430(
                        class_2561.method_43470((target.get() ? "§6" : "")+name+ onOff(target.get())),
                        b -> {
                            target.set(!target.get());
                            b.method_25355(class_2561.method_43470((target.get() ? "§6" : "")+name+ onOff(target.get())));
                        }).method_46434(x,y,width,height).method_46431()
        );
    }


    @Override
    protected void method_25426() {

        long windowHandle = field_22787.method_22683().method_4490(); // 1. 获取游戏窗口的 GLFW 句柄
        originalScrollCallback = GLFW.glfwSetScrollCallback(windowHandle, null);

        EntityChoose = new class_342(field_22793, 6, 70, this.field_22789/2-16, 20, class_2561.method_43470("实体筛选"));
        method_37063(EntityChoose);

        PlayerChoose = new class_342(field_22793, this.field_22789/2+6, 70, this.field_22789/2-16, 20, class_2561.method_43470("玩家筛选"));
        method_37063(PlayerChoose);

        // 保存并退出
        method_37063(class_4185.method_46430(
                class_2561.method_43470("<-返回"),
                b -> {
                    if (field_22787 != null) field_22787.method_1507(parent);
                }).method_46434(20, 20, 100, 20).method_46431());
    }

    private static String onOff(boolean b) {
        return b ? "开" : "关";
    }


    // 界面关闭时触发
    @Override
    public void method_25419() {
        restoreOldScrollCallback();
        if(field_22787 != null) field_22787.method_1507(parent);
    }

    // 界面被移除时兜底执行
    @Override
    public void method_25432() {
        restoreOldScrollCallback();
    }

    // 还原窗口原始回调
    private void restoreOldScrollCallback() {
        if (originalScrollCallback == null) return;
        long window = field_22787.method_22683().method_4490();
        // 把之前保存的原版回调重新绑回窗口
        GLFW.glfwSetScrollCallback(window, originalScrollCallback);
        originalScrollCallback = null;
    }
}