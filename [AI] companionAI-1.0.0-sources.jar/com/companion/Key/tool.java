package com.companion.Key;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import static com.companion.global.*;


public class tool {
    public static class_304[] keyBox =new class_304[7];

    public static void reg(){
        class_304.class_11900 name=new class_304.class_11900(class_2960.method_60655(ModName, "main"));
        class_3675.class_307 key= class_3675.class_307.field_1668;

        keyBox[0] = KeyBindingHelper.registerKeyBinding(new class_304(
                "斩杀",          // 翻译键
                key,       // 键盘
                GLFW.GLFW_KEY_F4,             // 默认键
                name  // 分类翻译键
        ));
        keyBox[1] = KeyBindingHelper.registerKeyBinding(new class_304(
                "刻秒",          // 翻译键
                key,       // 键盘
                GLFW.GLFW_KEY_F7,             // 默认键
                name     // 分类翻译键
        ));
        keyBox[2] = KeyBindingHelper.registerKeyBinding(new class_304(
                "神明降世",          // 翻译键
                key,       // 键盘
                GLFW.GLFW_KEY_K,             // 默认键
                name     // 分类翻译键
        ));
        keyBox[3] = KeyBindingHelper.registerKeyBinding(new class_304(
                "temp",          // 翻译键
                key,       // 键盘
                GLFW.GLFW_KEY_V,             // 默认键
                name     // 分类翻译键
        ));
        keyBox[4] = KeyBindingHelper.registerKeyBinding(new class_304(
                "珍珠",          // 翻译键
                key,       // 键盘
                GLFW.GLFW_ANGLE_PLATFORM_TYPE_NONE,             // 默认键
                name     // 分类翻译键
        ));
        keyBox[5] = KeyBindingHelper.registerKeyBinding(new class_304(
                "打开菜单",          // 翻译键
                key,       // 键盘
                GLFW.GLFW_KEY_I,             // 默认键
                name     // 分类翻译键
        ));
        keyBox[6] = KeyBindingHelper.registerKeyBinding(new class_304(
                "上钩",          // 翻译键
                key,       // 键盘
                GLFW.GLFW_KEY_END,             // 默认键
                name     // 分类翻译键
        ));


    }

}
