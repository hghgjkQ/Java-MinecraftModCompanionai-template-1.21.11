package com.companion.skills.MapDraw;

import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_746;

import static com.companion.global.*;
import java.util.HashMap;

import static com.companion.skills.MapDraw.Workpiece.*;

public class build {

    public static void buildUnit(){

    }

    // 【最简函数】从起点MapDrawPos填充圆石到MapDrawTar
    public static void fillStone() {
        MapDrawTar.clear();
        // 1. 提取起点坐标（X/Z从MapDrawPos取，Y默认填64（海平面），可按需修改）
        int x = (int) MapDrawPos[0];
        int z = (int) MapDrawPos[1];
        int y = MapDrawY;

        // 2. 创建MC原生BlockPos对象（Fabric标准用法）
        class_2338 startPos = new class_2338(x, y, z);

        // 3. 填充圆石到目标Map（使用MC原生的圆石方块常量）
        MapDrawTar.put(startPos, class_2246.field_10445);
    }



    public static void throwNonCobble(class_746 player) {
        class_310 mc = class_310.method_1551();
        class_636 im = mc.field_1761;
        if (im == null) return;

        class_1661 inv = player.method_31548();

        // 遍历所有槽位，直接THROW
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960() || stack.method_31574(class_1802.field_20412)) continue;

            int slotId = i < 9 ? i + 36 : (i == 40 ? 45 : i);
            im.method_2906(0, slotId, 1, class_1713.field_7795, player);
        }
    }
}
