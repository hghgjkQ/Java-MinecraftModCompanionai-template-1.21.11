package com.companion.skills.MapDraw;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2398;
import net.minecraft.class_243;

import static com.companion.global.*;

public class main {
    public static void reg(){
        ClientTickEvents.END_CLIENT_TICK.register(client -> showSide());

    }
    public static void showSide(){
        if (player!=null) {
            double[] pos = new double[2];
            pos[0] = player.method_23317()+64;
            pos[1] = player.method_23321()+64;
            long[][] top = Workpiece.getMapVertices((long) pos[0], (long) pos[1]);
            draw.line(
                    new class_243((double) top[0][0], player.method_23318(), (double) top[0][1]),
                    new class_243((double) top[0][0], player.method_23318(), (double) top[1][1]),
                    1,
                    class_2398.field_29644
            );
            draw.line(
                    new class_243((double) top[0][0], player.method_23318(), (double) top[0][1]),
                    new class_243((double) top[1][0], player.method_23318(), (double) top[0][1]),
                    1,
                    class_2398.field_29644
            );
            draw.line(
                    new class_243((double) top[1][0], player.method_23318(), (double) top[0][1]),
                    new class_243((double) top[1][0], player.method_23318(), (double) top[1][1]),
                    1,
                    class_2398.field_29644
            );
            draw.line(
                    new class_243((double) top[0][0], player.method_23318(), (double) top[1][1]),
                    new class_243((double) top[1][0], player.method_23318(), (double) top[1][1]),
                    1,
                    class_2398.field_29644
            );
        }
    }
}
