package com.companion.skills.MapDraw;



import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_2394;
import net.minecraft.class_243;

import static com.companion.global.*;


public class draw { // 类名首字母大写，符合Java规范
    /**
     * 修复版：在起点SP和终点EP之间绘制粒子线
     * @param SP 起点坐标
     * @param EP 终点坐标
     * @param particleDensity 每格距离的粒子数（建议20，值越大线条越平滑）
     */
    public static void line(class_243 SP, class_243 EP, int particleDensity,class_2394 c) {
        // 1. 基础校验：客户端环境 + 非零距离
        if (all_client == null) return;
        double distance = SP.method_1022(EP);
        if (distance < 1e-6) { // 距离几乎为0时，只画一个粒子
            point(c, SP);
            return;
        }


        // 2. 计算方向向量并归一化（长度=1，保证每次移动固定距离）
        class_243 direction = EP.method_1020(SP).method_1029();
        // 3. 计算步长（每步移动的距离 = 总距离 / 总粒子数）
        int totalParticles = (int) (distance * particleDensity);
        double stepDistance = distance / totalParticles;

        // 4. 循环绘制粒子（包含起点和终点）
        for (int i = 0; i <= totalParticles; i++) {
            // 计算当前粒子位置：起点 + 方向向量 × 步长 × 次数
            class_243 pos = SP.method_1019(direction.method_1021(stepDistance * i));
            point(c, pos);
        }
    }


    public static void point(class_2394 s, class_243 P){
        if (all_client.field_1687 != null) {
            all_client.field_1687.method_8466(
                    s,    // 用原版火焰粒子（无需自定义）
                    true,
                    true,
                    P.field_1352,
                    P.field_1351,
                    P.field_1350,
                    0,
                    0,
                    0  );
        }
    }
    /**
     * 绘制圆形粒子轨迹
     * @param s 粒子类型（如 ParticleTypes.REDSTONE）
     * @param center 圆心坐标（Vec3d）
     * @param radius 圆圈半径（double，如 2.0 表示2格）
     */
    public static void drawCircle(class_2394 s, class_243 center, double radius) {
        // 角度步长（越小圆圈越平滑，0.1 是兼顾性能和效果的取值）
        double step = 0.1;
        // 遍历 0 到 2π（完整圆周）
        for (double theta = 0; theta < 2 * Math.PI; theta += step) {
            // 三角函数计算圆周上的点（XZ平面，Y坐标和圆心一致）
            double x = center.field_1352 + radius * Math.cos(theta); // 余弦算X轴偏移
            double z = center.field_1350 + radius * Math.sin(theta); // 正弦算Z轴偏移
            double y = center.field_1351;                            // Y轴和圆心相同

            // 调用单个粒子方法，绘制圆周上的点
            point(s, new class_243(x, y, z));
        }
    }
}

