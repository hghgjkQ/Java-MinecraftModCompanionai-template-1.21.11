package com.companion.skills;

import static com.companion.draw.base.line;

import static com.companion.effect.tool.miniLeap;

import static com.companion.global.*;
import static com.companion.python.find.findPath;


import com.companion.ParticleManage;
import com.companion.draw.mix;
import com.companion.effect.tool;
import com.companion.skills.findpathcut;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_638;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class cutTree {

    private static Set<class_2680> Tree = new HashSet<>();

    static {
        // 经典原木
        Tree.add(class_2246.field_10431.method_9564());          // 橡木原木
        Tree.add(class_2246.field_10037.method_9564());      // 云杉原木
        Tree.add(class_2246.field_10511.method_9564());       // 桦木原木
        Tree.add(class_2246.field_10306.method_9564());      // 丛林原木
        Tree.add(class_2246.field_10533.method_9564());     // 金合欢原木
        Tree.add(class_2246.field_10010.method_9564());    // 深色橡木原木
        // 下界原木（茎）
        Tree.add(class_2246.field_22118.method_9564());    // 绯红原木
        Tree.add(class_2246.field_22111.method_9564());     // 诡异原木
        // 新增原木
        Tree.add(class_2246.field_37545.method_9564());    // 红树林原木
        Tree.add(class_2246.field_42729.method_9564());      // 樱花原木（1.20+核心新增）
        Tree.add(class_2246.field_41072.method_9564());    // 竹子原木（1.20+）

    }

    private static boolean isLog(class_310 client, class_2338 pos) {
        // 1. 基础判空：客户端/世界为空直接返回false
        if (client == null || client.field_1687 == null) {
            return false;
        }

        // 2. 原有判断：当前方块是否是原木
        class_2680 currentState = client.field_1687.method_8320(pos);
        if (!Tree.contains(currentState)) {
            return false;
        }

        // 3. 新增判断：上下左右（六向）相邻至少有一个是空气
        // 定义6个相邻方向（上、下、东、西、南、北）
        class_2350[] directions = {
                class_2350.field_11036,    // 上
                class_2350.field_11033,  // 下
                class_2350.field_11034,  // 东（右）
                class_2350.field_11039,  // 西（左）
                class_2350.field_11035, // 南（前）
                class_2350.field_11043  // 北（后）
        };

        // 遍历所有方向，检查是否有至少一个空气方块
        for (class_2350 dir : directions) {
            class_2338 neighborPos = pos.method_10093(dir); // 获取相邻方块坐标
            class_2680 neighborState = client.field_1687.method_8320(neighborPos);
            // 判断相邻方块是否是空气（isAir() 是Minecraft内置的空气判断方法，更通用）
            if (neighborState.method_26215()) {
                return true; // 只要有一个是空气，立即返回true
            }
        }

        // 4. 若所有相邻都不是空气，返回false
        return false;
    }

    public static void reg(){
        ClientTickEvents.END_CLIENT_TICK.register((client)->{
            draw(client);
            update(client);

        }); // 每帧执行代码
    }



    private static class_2338 GetArea(class_310 client){ //得到最近区域
        if (client==null ||client.field_1687==null ||client.field_1724==null)return null;
        double minD=Double.MAX_VALUE;
        class_2338 l=new class_2338(0,0,0);
        for(class_2338 pos:CutTreeWasFinallyTree){
            double D=player.method_73189().method_1022(pos.method_46558());
            if (D<minD){
                minD=D;
                l=pos;
            }

        }
        if(minD!=Double.MAX_VALUE) {
            return l;
        }else {
            return null;
        }
    }

    private static class_2338 GetLog(class_310 client){ //得到最近木头
        if (client==null ||client.field_1687==null ||client.field_1724==null)return null;
        double minD=Double.MAX_VALUE;
        class_2338 l=new class_2338(0,0,0);
        for(class_2338 pos:CutTreeWithCheckTree){
            double D=player.method_73189().method_1022(pos.method_46558());
            if (D<minD){
                minD=D;
                l=pos;
            }

        }
        if(minD!=Double.MAX_VALUE) {
            return l;
        }else {
            return null;
        }
    }

    private static boolean InArea(class_310 client) {
        // 1. 基础判空：客户端/世界/玩家不能为空
        if (client == null || client.field_1687 == null || client.field_1724 == null) {
            return false;
        }
        // 2. 集合判空：避免遍历空集合抛出异常
        if (CutTreeWasFinallyTree == null || CutTreeWasFinallyTree.isEmpty()) {
            return false;
        }

        // 3. 获取玩家坐标（使用判空后的 client.player，避免空指针）
        class_243 posW = client.field_1724.method_24515().method_46558();

        // 4. 遍历区域并判断（包含边界的严谨判断）
        for (class_2338 pos : CutTreeWasFinallyTree) {
            class_243 pos1 = pos.method_46558().method_1031(-CutTreeHalf, 0, -CutTreeHalf);
            class_243 pos2 = pos.method_46558().method_1031(CutTreeHalf, 0, CutTreeHalf);

            // 修正：使用 >=/<= 包含边界，避免边界坐标判断错误
            boolean inXRange = pos1.method_10216() <= posW.method_10216() && posW.method_10216() <= pos2.method_10216();
            boolean inZRange = pos1.method_10215() <= posW.method_10215() && posW.method_10215() <= pos2.method_10215();

            if (inXRange && inZRange) {
                return true;
            }
        }
        return false;
    }
    private static Set<class_2338>CheckArea(class_310 client,class_2338 pos){
        Set<class_2338>Check=new HashSet<>();
        for(int x=-(int) CutTreeHalf;x<(int) CutTreeHalf+1;x++){
            for(int y=-10;y<30;y++){
                for(int z=-(int) CutTreeHalf;z<(int) CutTreeHalf+1;z++){
                    var t=pos.method_10069(x,y,z);
                    if(isLog(client,t)){
                        Check.add(t);
                    }
                }
            }
        }
        return Check;
    }
    public static void CutTreeUpdate(class_310 client){
        update(client);
    }


    private static void draw(class_310 client){

        if(CutTreeR!=0) {
            CutTreeHalf=CutTreeAreaSize/2.0;
            player.method_18800(0,0,0);
            player.field_6017 = 0.0F;
            player.method_24830(false);

            mix.block(CutTreePos.method_46558(),2, ParticleManage.GREEN_POINT_PARTICLE); //起点
            //绘制小单元
            for(class_2338 pos:CutTreeWasFinallyTree){
                mix.drawRect(pos.method_46558().method_1031(-CutTreeHalf,0,-CutTreeHalf),pos.method_46558().method_1031(CutTreeHalf,0,CutTreeHalf),2, ParticleManage.YELLOW_POINT_PARTICLE);
            }
            for(class_2338 pos:CutTreeWithCheckTree){
                mix.block(pos.method_46558(),2,ParticleManage.BLUE_POINT_PARTICLE);
            }
            breakUnderPlayer(client);
            class_2338 posTemp=null;
            if (!CutTreeGoalPath.isEmpty()){

                for(class_2338 pos: CutTreeGoalPath){
                    mix.block(pos.method_46558(),5,ParticleManage.GREEN_POINT_PARTICLE);
                    if(posTemp!=null) {
                        line(pos.method_46558(), posTemp.method_46558(),3, ParticleManage.RED_POINT_PARTICLE);
                    }
                    posTemp=pos;
                }

            }
        }
    }
    private static  void update(class_310 client){
        if(CutTreeR!=0){

            tipGame("CutTreePathGoal："+CutTreePathGoal);

            //决策
            if(CutTreeWasFinallyTree.isEmpty()) { //如果全部完成
                CutTreeR++;
                tipGame("开始处理半径："+CutTreeR*CutTreeAreaSize);
                cleanCutTreeWasFinallyTree();
            }
            if(!CutTreeWasFinallyTree.isEmpty()){ //如果未完成
                boolean a=InArea(client);
                tipGame("如果在区域中："+a);
                if (a) { //如果在区域中
                    CutTreeWithCheckTree=CheckArea(client,CutTreeGoalPos);
                    //判断距离


                    if(!CutTreeWithCheckTree.isEmpty()){
                        class_2338 L= GetLog(client);
                        tipGame("L："+L);
                        if (player.method_73189().method_1022(L.method_46558())>CutTreeForD){ //如果到木头的距离超过了挖掘范围
                            tipGame(1111);
                            if(!CutTreePathGoal) {//如果状态正确
                                CutTreeGoalPath.clear();
                                CutTreeGoalPath = FindPath(client.field_1687, player.method_24515(), L);
                                CutTreeGoalPathIndex = 0;
                                CutTreePathGoal=true;
                                if(CutTreeGoalPath.isEmpty()){ //完全无路可走情况
                                    CutTreePathGoal=false;
                                    cleanCutTreeWasFinallyTree();
                                    CutTreeGoalPath.clear();
                                    tipGame("砍树出现问题，无法寻路，被迫终止：砍树");
                                    CutTreeGoalPathIndex = 0;
                                    tipGame(CutTreeWasFinallyTree);
                                    if (CutTreeWasFinallyTree.contains(CutTreeGoalPos)) {
                                        CutTreeWasFinallyTree.remove(CutTreeGoalPos)   ;
                                    }else {
                                        CutTreeWasFinallyTree.remove(GetArea(client));
                                    }

                                }
                            }if(CutTreePathGoal){
                                if(miniLeap(CutTreeGoalPath.get(CutTreeGoalPathIndex).method_46558().method_1031(0,-0.5,0),CutTreeLeapMinD)){
                                    CutTreeGoalPathIndex++;
                                    if(CutTreeGoalPathIndex>=CutTreeGoalPath.size()){
                                        CutTreeGoalPath.clear();
                                        CutTreePathGoal=false;
                                    }
                                }
                            }
                        }
                    }
                    if(CutTreeWithCheckTree.isEmpty()) { //如果此区域完成
                        CutTreeGoalPathIndex = 0;
                        CutTreeGoalPath.clear();
                        tipGame(CutTreeWasFinallyTree);
                        if (CutTreeWasFinallyTree.contains(CutTreeGoalPos)) {
                            CutTreeWasFinallyTree.remove(CutTreeGoalPos)   ;
                        }else {
                            CutTreeWasFinallyTree.remove(GetArea(client));
                        }
                    }

                }
                if(!a) {
                    if(CutTreeGoalPath.isEmpty()) { //如果不在区域中且无路可走
                        CutTreeGoalPos = GetArea(client);
                        CutTreeGoalPathIndex=0;
                        CutTreeGoalPath=FindPath(client.field_1687, player.method_24515() ,AvoidNotAir(client,CutTreeGoalPos));
                        CutTreePathGoal=false;
                        if(CutTreeGoalPath.isEmpty()){ //完全无路可走情况
                            cleanCutTreeWasFinallyTree();
                            CutTreeGoalPath.clear();
                            tipGame("砍树出现问题，无法寻路，被迫终止");
                            CutTreeGoalPathIndex = 0;
                            tipGame(CutTreeWasFinallyTree);
                            if (CutTreeWasFinallyTree.contains(CutTreeGoalPos)) {
                                CutTreeWasFinallyTree.remove(CutTreeGoalPos)   ;
                            }else {
                                CutTreeWasFinallyTree.remove(GetArea(client));
                            }
                        }
                    }
                    if(!CutTreeGoalPath.isEmpty()){ //按照寻路走
                        if(miniLeap(CutTreeGoalPath.get(CutTreeGoalPathIndex).method_46558().method_1031(0,-0.5,0),10)){
                            CutTreeGoalPathIndex++;
                            if(CutTreeGoalPathIndex>=CutTreeGoalPath.size()){
                                CutTreeGoalPath.clear();
                                CutTreePathGoal=false;
                            }
                        }
                    }
                }

            }

        }
    }

    private static class_2338 AvoidNotAir(class_310 client,class_2338 pos){
        if (client==null ||client.field_1687==null ||client.field_1724==null)return pos;
        class_638 world= client.field_1687;
        short y=1;
        if (!world.method_8320(pos).method_26215()){//如果不是可穿方块
            while (!world.method_8320(pos.method_10069(0,y,0)).method_26215()){
                y++;
                if (y>321){
                    break;
                }
            }
            return pos.method_10069(0,y,0);
        }else {
            return pos;
        }
    }

    public static void cleanCutTreeWasFinallyTree(){
        CutTreeWasFinallyTree.clear();
        for (int c = 0; c < 4; c++) {
            long fixedX = 0, fixedZ = 0; // 固定轴的值
            long varX = 0, varZ = 0;     // 变化轴的系数（1表示变化，0表示不变）

            // 根据c确定当前边：0-上边，1-下边，2-右边，3-左边
            if (c == 0) { // 上边：z固定为 +R*5，x变化
                varX = 1;
                fixedZ = (long) (CutTreeR * CutTreeAreaSize);
            } else if (c == 1) { // 下边：z固定为 -R*5，x变化
                varX = 1;
                fixedZ = (long) (-CutTreeR * CutTreeAreaSize);
            } else if (c == 2) { // 右边：x固定为 +R*5，z变化
                varZ = 1;
                fixedX = (long) (CutTreeR * CutTreeAreaSize);
            } else { // 左边：x固定为 -R*5，z变化
                varZ = 1;
                fixedX = (long) (-CutTreeR * CutTreeAreaSize);
            }

            // 生成当前边上的点，包括两端（up从0到2R）
            for (long up = 0; up <= CutTreeR * 2; up++) {
                long offset = (long) ((up - CutTreeR) * CutTreeAreaSize); // 从 -R*5 到 R*5 步长5
                int x = (int) (offset * varX + fixedX);
                int z = (int) (offset * varZ + fixedZ);
                CutTreeWasFinallyTree.add(CutTreePos.method_10069(x, 0, z));
            }
        }
    }

    private static void breakUnderPlayer(class_310 client) {
        class_636 manager = client.field_1761;

        if (client.field_1724 == null || manager == null) return;


        double radius = CutTreeBreakMaxD; // 可自行修改半径
        class_2338 centerPos = client.field_1724.method_24515(); // pos是你的圆心BlockPos对象


        for (double xOffset = -radius; xOffset <= radius; xOffset++) { // 遍历X/Z轴偏移（-radius到+radius），Y仅偏移0和1
            for (double zOffset = -radius; zOffset <= radius; zOffset++) {
                for (double yOffset = 1-radius; yOffset <= radius; yOffset++) { //眼睛高度补偿
                    double distanceSq = xOffset * xOffset + yOffset * yOffset + zOffset * zOffset; // 计算偏移量的距离平方（球形判断核心，避免开根号）
                    if (distanceSq <= radius * radius) {
                        class_2338 pos = centerPos.method_10069((int) xOffset, (int) yOffset, (int) zOffset);  // 生成实际的方块坐标（圆心+偏移量）
                        if (isLog(client,pos)) { //验证是不是原木
                            manager.method_2910(pos, class_2350.field_11036);
                        }
                    }
                }
            }
        }
    }




    private static List<class_2338> FindPath(     class_638 world,class_2338 start,class_2338 target )
    {
        var a=findPath(world,start,target);
        if(a.isEmpty()){
            a=findpathcut.findPath(world,start,target);
            if(a.isEmpty()) {
                a=findPath(world,start,AvoidNotAir(class_310.method_1551(),target));
                if(a.isEmpty()) {
                    a=findpathcut.findPath(world,start,AvoidNotAir(class_310.method_1551(),target));
                }
            }
        }
        return new ArrayList<>(a) ;
    }
    private static void tipGame(Object x){
        //tool.tipGame( x);
    }

}

/*
    private static boolean isCanUse(MinecraftClient client,BlockPos pos){
        return client.world != null && client.world.getBlockState(pos).getBlock()!=Blocks.VOID_AIR;
    }

 private static boolean YinCutTreeWasFinallyTree(BlockPos pos) {
        // 空指针防护：pos或CutTreePos为空直接返回false
        if (pos == null || CutTreePos == null) {
            return false;
        }

        // 计算中心坐标和边界值
        int centerX = (int) CutTreePos.getX();
        int centerZ = (int) CutTreePos.getZ();
        int innerRadius = (int) CutTreeR;       // 内层边界（边框内侧）
        int outerRadius = (int) (CutTreeR + 3);   // 外层边界（边框外侧）

        // 计算pos相对于中心的偏移量（仅X/Z轴，边框是平面环形）
        int offsetX = Math.abs(pos.getX() - centerX);
        int offsetZ = Math.abs(pos.getZ() - centerZ);

        // 判断是否在「边框区域」：偏移量 ≥ 内层半径 且 ≤ 外层半径
        // 即：不在内部（<内层半径），也不在外部（>外层半径），仅在边框上
        return (offsetX >= innerRadius && offsetX <= outerRadius)
                || (offsetZ >= innerRadius && offsetZ <= outerRadius);
    }



 // 扫描获取玩家附近最近的空气方块（客户端专用）
    private static BlockPos getLog(MinecraftClient client) {
        // 1. 校验客户端玩家和世界是否有效（客户端必须判空）
        if (client.player == null || client.world == null) {
            return null;
        }

        BlockPos playerPos = BlockPos.ofFloored(client.player.getEntityPos()); // 获取玩家当前方块坐标
        // 2. 从近到远逐层扫描（立方体范围，半径从小到大，找到即返回）
        // 无需限定最大范围，客户端只会扫描已加载区块内的方块
        for (int radius = 0;radius<128 ; radius++) {
            // 遍历当前半径下的所有方块（立方体遍历）
            for (int x = -radius; x <= radius; x++) {
                for (int y = -radius; y <= radius; y++) {
                    for (int z = -radius; z <= radius; z++) {
                        // 跳过半径层外的方块（优化：只扫描当前半径的外层，更快找到最近的）
                        if (Math.abs(x) != radius && Math.abs(y) != radius && Math.abs(z) != radius) {
                            continue;
                        }

                        BlockPos checkPos = playerPos.add(x,y,z);
                        // 3. 客户端关键：只检查已加载区块内的方块，避免访问未加载地图报错
                        if (!isCanUse(client,checkPos)) {
                            continue;
                        }

                        if (YinCutTreeWasFinallyTree(checkPos) && isLog(client,checkPos)) {
                            return checkPos; // 找到最近的空气方块，直接返回
                        }
                    }
                }
            }
        }
        return null;
    }
//树木判断并进入下一轮循环
            CutTreeWasFinallyTree.removeIf(pos -> simply(isFinally(client,pos)));
            for(BlockPos pos:CutTreeWasFinallyTree){
                point(GREEN_POINT_PARTICLE,pos.toCenterPos());
            }

            if(CutTreeWasFinallyTree.isEmpty()){
                cleanCutTreeWasFinallyTree();
                CutTreeR+=3;
            }



            //决策
            if(CutTreeGoalPath.isEmpty()){
                CutTreeGoalPathIndex=0;
                CutTreeGoalPos=getLog(client);
                if(CutTreeGoalPos==null){
                    cleanCutTreeWasFinallyTree();
                    CutTreeR+=3;
                    return;
                }
                CutTreeGoalPath=findPath(client.world, player.getBlockPos() ,CutTreeGoalPos);
                if(CutTreeGoalPath.isEmpty()){
                    CutTreeR=0;
                    cleanCutTreeWasFinallyTree();
                    CutTreeGoalPath.clear();
                    tipGame("砍树出现问题，无法寻路，被迫终止");
                }
            }else{
                if(miniLeap(CutTreeGoalPath.get(CutTreeGoalPathIndex).toCenterPos().add(0,-0.5,0),10)){
                    CutTreeGoalPathIndex++;
                    if(CutTreeGoalPathIndex>=CutTreeGoalPath.size()){
                        CutTreeGoalPath.clear();
                    }
                }
            }

                private static int isFinally(MinecraftClient client,BlockPos pos){
        for(int y=0;y<30;y++){ //即最高树木判断为高差30格
            if(isCanUse(client,pos.add(0,y,0))){ //如果被加载同时不是树木
                if(isLog(client,pos.add(0,y,0)))return 1;

                }else{
                    return 0;
                }
        }
        return 2;
    }
    private static boolean simply(int x){
        return x != 1;
    }

 */