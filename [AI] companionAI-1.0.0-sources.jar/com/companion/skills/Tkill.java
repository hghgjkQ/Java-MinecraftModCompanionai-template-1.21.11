package com.companion.skills;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_746;

import static com.companion.global.*;


public class Tkill {

    public static void run() {
        class_1309 e=getEyeEntity(1000);
        if (TarEntity!=e && e!=null && e.method_5805() && e.method_6032()>0) {
            TarEntity = e;
        }
    }
    public static class_1309 getEyeEntity(double maxDistance) {
        // 判空逻辑保持不变
        if (player == null || player.method_73183() == null) return null;

        class_243 eye  = player.method_33571();
        class_243 look = player.method_5828(1.0F);
        class_243 end  = eye.method_1019(look.method_1021(maxDistance));

        // 获取视线穿过的所有实体
        class_238 box = player.method_5829().method_18804(look.method_1021(maxDistance)).method_1014(1.0);
        var entities = player.method_73183().method_8335(player, box);

        // 关键修改1：将closest声明为LivingEntity类型，而非通用的Entity
        class_1309 closest = null;
        double minDist = maxDistance;

        for (class_1297 e : entities) {
            // 关键修改2：增加类型判断，只处理LivingEntity类型的实体
            if (!(e instanceof class_1309)) {
                continue; // 非生物实体直接跳过
            }

            var hitResult = e.method_5829().method_992(eye, end);
            if (hitResult.isPresent()) {
                double dist = eye.method_1022(hitResult.get());
                if (dist < minDist) {
                    minDist = dist;
                    // 关键修改3：直接赋值（已通过instanceof校验，类型安全）
                    closest = (class_1309) e;
                }
            }
        }
        // 返回值类型匹配，无需额外处理
        return closest;
    }

    public static List<Float> faceEntity(class_746 player, class_1309 target,boolean ac) {
        class_243 playerEyePos = player.method_33571();
        class_243 targetCenterPos = target.method_5829().method_1005();
        double dx = targetCenterPos.field_1352 - playerEyePos.field_1352;
        double dy = targetCenterPos.field_1351 - playerEyePos.field_1351;
        double dz = targetCenterPos.field_1350 - playerEyePos.field_1350;
        double horizontalDistance = class_3532.method_15355((float) (dx * dx + dz * dz));
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F;
        float pitch = (float) (-Math.atan2(dy, horizontalDistance) * 180.0 / Math.PI);
        if (ac) {
            player.method_36456(class_3532.method_15393(yaw));
            player.method_36457(class_3532.method_15363(pitch, -90.0F, 90.0F));
        }
        List<Float> c=new ArrayList<>();
        c.add(yaw);
        c.add(pitch);
        return c;
    }
    public static List<Float> faceEntity(class_243 playerEyePos, class_243 targetCenterPos) {
        double dx = targetCenterPos.field_1352 - playerEyePos.field_1352;
        double dy = targetCenterPos.field_1351 - playerEyePos.field_1351;
        double dz = targetCenterPos.field_1350 - playerEyePos.field_1350;
        double horizontalDistance = class_3532.method_15355((float) (dx * dx + dz * dz));
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F;
        float pitch = (float) (-Math.atan2(dy, horizontalDistance) * 180.0 / Math.PI);
        List<Float> c=new ArrayList<>();
        c.add(yaw);
        c.add(pitch);
        return c;

    }
}