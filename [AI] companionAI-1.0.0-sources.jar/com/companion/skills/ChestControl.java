package com.companion.skills;

import static com.companion.global.all_client;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;

public class ChestControl {
    /**
     * 打开指定坐标箱子的核心函数（1.21.11 版本适配）
     * @param chestPos 目标箱子坐标
     */
    public static void openChest(class_2338 chestPos) {
        class_310 client = class_310.method_1551();

        // 基础空值校验（公开字段/方法）
        if (client.field_1724 == null || client.field_1761 == null || client.field_1687 == null) {
            return;
        }

        // 构造方块碰撞结果（和游戏右键逻辑完全相同）
        class_3965 hitResult = new class_3965(
                class_243.method_24953(chestPos),  // 碰撞位置
                class_2350.field_11036,              // 碰撞方向
                chestPos,                  // 方块坐标
                false                      // 偏移量
        );

        // ==============================================
        // ✅ 核心：调用【公开PUBLIC方法】，自动发送数据包、自动处理sequence
        // ==============================================
        class_636 manager = client.field_1761;
        class_1269 result = manager.method_2896(client.field_1724, class_1268.field_5808, hitResult);
    }
    public static void close(){
        if (class_310.method_1551().field_1724 != null) {
            class_310.method_1551().field_1724.method_7346();// 直接调用玩家的「关闭容器界面」核心API
        }
    }



    private static final int CHEST_SLOT_MIN = 0;
    private static final int CHEST_SLOT_MAX = 26;
    private static final int PLAYER_INV_MIN = 27;
    private static final int PLAYER_INV_MAX = 62;

    // ==============================================
    // 【放入箱子】玩家背包 → 箱子
    // @param targetItem 要放入的物品(Item类型)
    // @param amount     数量(-1=全部放入)
    // ==============================================
    public static void putItemIntoChest(class_1792 targetItem, int amount) {
        class_310 client = all_client;
        if (!isChestOpen()) return;

        int remaining = amount == -1 ? Integer.MAX_VALUE : amount;
        class_1707 handler = (class_1707) client.field_1724.field_7512;

        // 遍历玩家背包
        for (int slot = PLAYER_INV_MIN; slot <= PLAYER_INV_MAX && remaining > 0; slot++) {
            class_1735 invSlot = handler.method_7611(slot);
            class_1799 stack = invSlot.method_7677();

            // 【核心修改】仅匹配物品类型，无视NBT/组件
            if (!stack.method_7960() && stack.method_31574(targetItem)) {
                int moveCount = Math.min(stack.method_7947(), remaining);
                // SHIFT+点击 快速移动物品
                client.field_1761.method_2906(handler.field_7763, slot, 0, class_1713.field_7794, client.field_1724);
                remaining -= moveCount;
            }
        }
    }

    // ==============================================
    // 【取出物品】箱子 → 玩家背包
    // @param targetItem 要取出的物品(Item类型)
    // @param amount     数量(-1=全部取出)
    // ==============================================
    public static void takeItemFromChest(class_1792 targetItem, int amount) {
        class_310 client = all_client;
        if (!isChestOpen()) return;

        int remaining = amount == -1 ? Integer.MAX_VALUE : amount;
        class_1707 handler = (class_1707) client.field_1724.field_7512;

        // 遍历箱子内部
        for (int slot = CHEST_SLOT_MIN; slot <= CHEST_SLOT_MAX && remaining > 0; slot++) {
            class_1735 chestSlot = handler.method_7611(slot);
            class_1799 stack = chestSlot.method_7677();

            // 【核心修改】仅匹配物品类型，无视NBT/组件
            if (!stack.method_7960() && stack.method_31574(targetItem)) {
                int moveCount = Math.min(stack.method_7947(), remaining);
                // SHIFT+点击 快速移动物品
                client.field_1761.method_2906(handler.field_7763, slot, 0, class_1713.field_7794, client.field_1724);
                remaining -= moveCount;
            }
        }
    }

    // ==============================================
    // 检查箱子是否已打开
    // ==============================================
    private static boolean isChestOpen() {
        class_310 client = all_client;
        return client.field_1724 != null
                && client.field_1761 != null
                && client.field_1724.field_7512 instanceof class_1707;
    }
}
