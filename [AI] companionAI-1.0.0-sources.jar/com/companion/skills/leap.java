package com.companion.skills;

import static com.companion.effect.tool.miniLeap;
import static com.companion.effect.tool.tipGame;
import static com.companion.global.*;

import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;

public class leap {
    public static void update(class_310 client){
        class_746 player =client.field_1724;
        if(player==null || client.field_1687==null)return;

        class_243 blockPos=player.method_24515().method_46558();

        if(leapState){
            if (leapWait==4){
                if(player.method_24515().method_10264()<330){
                    if (getTopYByScan(player.method_31477(), player.method_31479())>player.method_31478()){
                        leapState=false;
                        leapWait=-1;
                        tipGame("跃迁","上方有方块取消跃迁");
                    }else{ //可以起飞
                        player.method_23327(blockPos.field_1352,blockPos.field_1351-0.5,blockPos.field_1350);
                        leapWait=0;
                    }
                }
            }else if(leapWait==0){
                if(player.method_24515().method_10264()<330) {
                    miniLeap(blockPos.field_1352,blockPos.field_1351-0.5+leapMaxD,blockPos.field_1350,leapMaxD);
                }else{
                    leapWait=1;
                }
            }else if(leapWait==1){
                if (miniLeap(leapGladPos.method_10263(),blockPos.field_1351-0.5,leapGladPos.method_10260(),leapMaxD)){
                    leapWait=2;
                    leapGladPos= class_2338.method_49638(new class_243(player.method_31477(),getTopYByScan(leapGladPos.method_10263(), leapGladPos.method_10260())+3,player.method_31479()));
                }
            }else if(leapWait==2){
                if (miniLeap(leapGladPos.method_10263(),blockPos.field_1351-0.5,leapGladPos.method_10260(),leapMaxD)){
                    leapWait=3;
                }
            }else if(leapWait==3){
                tipGame("跃迁","完成，取消跃迁");
                leapState=false;
            }
        }
    }



    /**
     * 【客户端 - 遍历方块法】获取指定 XZ 的最高非空气方块 Y
     * @param targetX 目标 X 坐标
     * @param targetZ 目标 Z 坐标
     * @return 最高方块 Y，未找到返回 -1
     */
    public static int getTopYByScan(int targetX, int targetZ) {
        class_310 mc = class_310.method_1551();
        class_638 world = mc.field_1687;

        // 客户端空安全（必须加）
        if (world == null) return -1;

        // 获取世界的 最高Y / 最低Y（自动适配 主世界/下界/末地）
        int topY = 322;
        int bottomY = world.method_31607();

        // 从最高往下遍历，找第一个非空气方块
        for (int y = topY - 1; y >= bottomY; y--) {
            class_2338 pos = new class_2338(targetX, y, targetZ);

            class_2680 state = world.method_8320(pos);
            // 找到非空气方块 = 最高方块
            if (!state.method_26215()) {
                return y;
            }
        }

        return -1;
    }
}
