package com.companion.skills.MiningBot;

import static com.companion.global.*;
import static com.companion.skills.MiningBot.FindPath.AvoidBlock;

import net.minecraft.class_1542;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class FindPos {
    private static final class_2338[] offsets = {
            class_2338.field_10980,          // 自身
            new class_2338(0,1,0),      // 上
            new class_2338(1,0,0),      // 上上
            new class_2338(0,-1,0),     // 下
            new class_2338(0,0,1),      // 东
            new class_2338(-1,0,0),     // 西
            new class_2338(0,0,-1),      // 南

    };
    /**
     * 搜索最近的下界残骸（方块 + 地上掉落物）
     * @param radius 搜索半径
     * @return 最近的目标坐标
     */
    public static class_2338 findNearestAncientDebris(int radius) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return null;

        class_1937 world = mc.field_1687;
        class_243 playerPos = mc.field_1724.method_73189();
        class_2338 playerBlockPos = mc.field_1724.method_24515();

        class_2338 nearest = null;
        double minDistSq = Double.MAX_VALUE;

        // ========== 1. 搜索 远古残骸 方块 (1.21.11 标准写法) ==========
        boolean yes;
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                for (int y = MiningBotMinY; y <= MiningBotMaxY; y++) {
                    class_2338 pos = playerBlockPos.method_10069(x, 0, z);
                    pos=new class_2338(pos.method_10263(),y,pos.method_10260());

                    yes=true;
                    // 判断方块 + 黑名单过滤
                    if (MiningBotGoalBlock .contains(world.method_8320(pos).method_26204()) && !MiningBotBlockBan.contains(pos)) {
                        for (class_2338 offset : offsets) { //判断这个能不能挖
                            class_2338 checkPos = pos.method_10081(offset);
                            if(AvoidBlock.contains(world.method_8320(checkPos).method_26204()) && !MiningBotOldPath.contains(checkPos)){ //检测可挖性
                                yes=false;
                                break;
                            }
                        }
                        if (!yes){
                            continue;
                        }
                        double distSq = playerPos.method_1025(class_243.method_24953(pos));
                        if (distSq < minDistSq) {
                            minDistSq = distSq;
                            nearest = pos;
                        }
                    }
                }
            }
        }

        // ========== 2. 搜索 地上的远古残骸掉落物 (1.21.11 官方API) ==========
        // 搜索范围盒子
        class_238 searchBox = new class_238(
                playerPos.field_1352 - radius, playerPos.field_1351 - 20, playerPos.field_1350 - radius,
                playerPos.field_1352 + radius, playerPos.field_1351 + 20, playerPos.field_1350 + radius
        );

        // 1.21.11 正确获取物品实体的方式
        for (class_1542 itemEntity : world.method_8390(class_1542.class, searchBox, entity -> {
            // 过滤：只留远古残骸掉落物
            return entity != null && MiningBotGoalItems.contains(entity.method_6983().method_7909());
        })) {
            class_2338 itemPos = itemEntity.method_24515();
            double distSq = playerPos.method_1025(itemEntity.method_73189());

            // 更新最近目标
            if (distSq < minDistSq) {
                minDistSq = distSq;
                nearest = itemPos;
            }
        }

        return nearest;
    }
}