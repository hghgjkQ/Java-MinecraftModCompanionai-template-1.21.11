package com.companion.skills.MiningBot;

import com.companion.ParticleManage;
import com.companion.draw.base;
import com.companion.draw.mix;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2480;
import net.minecraft.class_2627;
import net.minecraft.class_310;
import net.minecraft.class_636;

import static com.companion.effect.tool.miniLeap;
import static com.companion.effect.tool.tipGame;
import static com.companion.global.*;
import static com.companion.skills.MiningBot.FindPos.findNearestAncientDebris;

public class MiningBot {

    public static class ShulkerBoxResult {
        public int rawSlot = -1;
        public int emptySlots = -1;
        public class_1799 boxStack = class_1799.field_8037;
        public boolean found() { return rawSlot != -1; }
    }

    private static int countShulkerEmptySlots(class_1799 stack) {
        if (!(stack.method_7909() instanceof class_1747 bi) || !(bi.method_7711() instanceof class_2480 block)) {
            return -1;
        }
        // 创建临时潜影盒方块实体
        class_2627 be = new class_2627(
                block.method_10528(),
                class_2338.field_10980,
                class_2246.field_10603.method_9564()
        );
        // 把物品组件数据读取到方块实体中
        //be.readComponents(stack.getComponents());

        // 统计空格（潜影盒固定27格）
        int empty = 0;
        for (int i = 0; i < be.method_5439(); i++) {
            if (be.method_5438(i).method_7960()) empty++;
        }
        return empty;
    }



    private static void draw(){
        if(MiningBotGoalPos!=null) {
            mix.block(MiningBotGoalPos.method_46558(),3, ParticleManage.RED_POINT_PARTICLE);
        }
        if(!MiningBotGoalPath.isEmpty()){
            for(class_2338 a:MiningBotGoalPath) {
                base.point(ParticleManage.YELLOW_POINT_PARTICLE,a.method_46558());
            }
        }
    }



    public static void TickRun(){
        if(all_client.field_1687==null) return;
        if(MiningBotState){
            ThrowStuff(MiningBotStayItem); //清理背包

            if(!hasEmptyInventorySlot()){
                for (class_2338 p : MiningBotOldPath){
                    if(p.method_46558().method_1025(player.method_73189())<5*5 && all_client.field_1687.method_8320(p.method_10084()).method_26215()){

                    }
                }
            }

            if(MiningBotGoalPos==null){
                MiningBotState=false;
                tipGame("挖矿机器人","未找到任何矿物，被迫终止");
            }else{
                if(MiningBotGoalPath.isEmpty()){
                    MiningBotGoalPath = FindPath.findPath(all_client.field_1687,player.method_24515(),MiningBotGoalPos);
                    if(MiningBotGoalPath.isEmpty()){
                        MiningBotBlockBan.add(MiningBotGoalPos);
                    }else{
                        MiningBotGoalPathIndex=0;
                    }
                }else {
                    if (MiningBotGoalPath.size() > MiningBotGoalPathIndex) {
                        if (all_client.field_1687.method_8320(MiningBotGoalPath.get(MiningBotGoalPathIndex)).method_26215()) {
                            if (all_client.field_1687.method_8320(MiningBotGoalPath.get(MiningBotGoalPathIndex).method_10084()).method_26215()) {
                                if (miniLeap(MiningBotGoalPath.get(MiningBotGoalPathIndex).method_46558().method_1031(0,-0.5,0), 1)) {
                                    MiningBotOldPath.add(MiningBotGoalPath.get(MiningBotGoalPathIndex).method_10084());
                                    MiningBotOldPath.add(MiningBotGoalPath.get(MiningBotGoalPathIndex));
                                    MiningBotGoalPathIndex++;
                                }
                            } else {
                                dig(MiningBotGoalPath.get(MiningBotGoalPathIndex).method_10084());
                            }
                        } else {
                            dig(MiningBotGoalPath.get(MiningBotGoalPathIndex));
                        }
                    }else{ //走完了
                        if (all_client.field_1687.method_8320(MiningBotGoalPos).method_26215()){
                            MiningBotGoalPath.clear();
                            MiningBotGoalPathIndex=0;
                            MiningBotGoalPos=findNearestAncientDebris(100);
                            MiningBotOldPath.add(MiningBotGoalPos);
                        }else{
                            dig(MiningBotGoalPos);
                        }
                    }
                }
            }
        }
        draw();
    }
    private static void dig(class_2338 pos){
        if (all_client.field_1761 != null) {
            if(!all_client.field_1761.method_2923()) {
                all_client.field_1761.method_2910(pos, class_2350.field_11033);
            }else{
                all_client.field_1761.method_2902(pos, class_2350.field_11033);
            }
        }
    }

    private static boolean hasEmptyInventorySlot() {
        class_310 mc = class_310.method_1551();
        class_636 im = mc.field_1761;
        class_1657 player = mc.field_1724;

        // 空值防护
        if (im == null || player == null) {
            return false;
        }

        class_1661 inv = player.method_31548();
        // 遍历主背包+快捷栏 0~35，盔甲副手不计算
        for (int rawSlot = 0; rawSlot < 36; rawSlot++) {
            class_1799 stack = inv.method_5438(rawSlot);
            if (stack.method_7960()) {
                return true; // 找到空格直接返回true
            }
        }
        return false; // 36格全部填满
    }

    private static void ThrowStuff(Set<class_1792> filter) {
        class_310 mc = class_310.method_1551();
        class_636 im = mc.field_1761;
        player = mc.field_1724;

        // 空值防护
        if (im == null || player == null || filter == null) {
            return;
        }

        class_1661 inv = player.method_31548();

        // 遍历范围：0-35（快捷栏+主背包）
        // 跳过：36-39（盔甲）、40（副手） → 穿盔甲完全不影响
        for (int rawSlot = 0; rawSlot < 36; rawSlot++) {
            class_1799 stack = inv.method_5438(rawSlot);
            // 空物品 / 在白名单内 → 跳过
            if (stack.method_7960() || filter.contains(stack.method_7909())) {
                continue;
            }

            // ============== 1.21 标准槽位映射（唯一正确写法） ==============
            int containerSlot;
            if (rawSlot < 9) {
                // 快捷栏 0-8 → 容器槽 36-44
                containerSlot = rawSlot + 36;
            } else {
                // 主背包 9-35 → 容器槽 9-35
                containerSlot = rawSlot;
            }

            // 扔出物品（同步客户端标准逻辑）
            im.method_2906(0, containerSlot, 1, class_1713.field_7795, player);
        }
    }
    public static Set<class_1792> getPlayerInventoryItems() {
        class_310 mc = class_310.method_1551();
        Set<class_1792> items = new HashSet<>();
        if (mc.field_1724 == null) return items;

        class_1661 inv = mc.field_1724.method_31548();

        // 背包+快捷栏
        for (class_1799 stack : inv.method_67533())
            if (!stack.method_7960()) items.add(stack.method_7909());
        return items;
    }
}

