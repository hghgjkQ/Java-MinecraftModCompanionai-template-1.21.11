package com.companion.skills.MiningBot;

import java.util.*;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_638;

import static com.companion.global.MiningBotOldPath;

public class FindPath {
    public static final Set<class_2248> AvoidBlock =new HashSet<>();
    static {
        AvoidBlock.add(class_2246.field_10164);
        AvoidBlock.add(class_2246.field_10382);
        AvoidBlock.add(class_2246.field_10124);
        AvoidBlock.add(class_2246.field_10243);
        AvoidBlock.add(class_2246.field_10036);
        AvoidBlock.add(class_2246.field_10255);
        AvoidBlock.add(class_2246.field_10092);
        AvoidBlock.add(class_2246.field_10102);
        AvoidBlock.add(class_2246.field_9987);
    };



    private static final class_2338[] offsets = {
            class_2338.field_10980,          // 自身
            new class_2338(0,1,0),      // 上
            new class_2338(0,2,0),      // 上上
            new class_2338(0,-1,0),     // 下
            new class_2338(1,0,0),      // 东
            new class_2338(-1,0,0),     // 西
            new class_2338(0,0,1),      // 南
            new class_2338(0,0,-1),     // 北
            new class_2338(1,1,0),      // 东上
            new class_2338(-1,1,0),     // 西上
            new class_2338(0,1,1),      // 南上
            new class_2338(0,1,-1)      // 北上
    };

    // 修改1：恢复UP方向，允许向上1格
    private static final class_2350[] DIRECTIONS = {
            class_2350.field_11036, class_2350.field_11033,
            class_2350.field_11043, class_2350.field_11035,
            class_2350.field_11034, class_2350.field_11039
    };
    private static final int MAX_SEARCH_RADIUS = 200;
    private static final int ADJUSTMENT_RADIUS = 5;

    public static List<class_2338> findPath(class_638 world, class_2338 start, class_2338 target) {
        if (start.equals(target)) {
            List<class_2338> list = new ArrayList<>();
            list.add(start);
            return list;
        }
        if (world == null || start == null || target == null) return new ArrayList<>();

        class_2338 adjustedStart = adjustBlockPosition(world, start);
        class_2338 adjustedTarget = adjustBlockPosition(world, target);
        if (adjustedStart == null || adjustedTarget == null) return new ArrayList<>();

        if (!isPassable(world, adjustedStart) || !isPassable(world, adjustedTarget))
            return new ArrayList<>();

        return aStarSearch(world, adjustedStart, adjustedTarget);
    }

    private static class_2338 adjustBlockPosition(class_638 world, class_2338 original) {
        if (isPassable(world, original)) return original;

        class_2338 best = null;
        int bestDist = Integer.MAX_VALUE;
        for (int dx = -ADJUSTMENT_RADIUS; dx <= ADJUSTMENT_RADIUS; dx++) {
            for (int dy = -ADJUSTMENT_RADIUS; dy <= ADJUSTMENT_RADIUS; dy++) {
                for (int dz = -ADJUSTMENT_RADIUS; dz <= ADJUSTMENT_RADIUS; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    class_2338 candidate = original.method_10069(dx, dy, dz);
                    if (isPassable(world, candidate)) {
                        int dist = Math.abs(dx) + Math.abs(dy) + Math.abs(dz);
                        if (dist < bestDist) {
                            bestDist = dist;
                            best = candidate;
                        }
                    }
                }
            }
        }
        return best;
    }

    private static boolean isPassable(class_638 world, class_2338 pos) {
        if (world == null || pos == null) return false;

        for (class_2338 offset : offsets) {
            class_2338 checkPos = pos.method_10081(offset);
            if(MiningBotOldPath.contains(checkPos) && world.method_8320(checkPos).method_26215()){
                continue;
            }
            if (AvoidBlock.contains(world.method_8320(checkPos).method_26204())) {
                return false;
            }
        }

        return true;
    }

    private static List<class_2338> aStarSearch(class_638 world, class_2338 start, class_2338 target) {
        PriorityQueue<Node> openSet = new PriorityQueue<>(Comparator.comparingInt(n -> n.f));
        Map<class_2338, Node> allNodes = new HashMap<>();

        Node startNode = new Node(start, null, 0, heuristic(start, target));
        openSet.add(startNode);
        allNodes.put(start, startNode);

        int targetX = target.method_10263(), targetY = target.method_10264(), targetZ = target.method_10260();
        int processed = 0, maxNodes = 50000;

        while (!openSet.isEmpty() && processed++ < maxNodes) {
            Node current = openSet.poll();

            if (current.pos.method_10263() == targetX && current.pos.method_10264() == targetY && current.pos.method_10260() == targetZ) {
                return reconstructPath(current);
            }

            if (manhattanDistance(current.pos, target) > MAX_SEARCH_RADIUS) continue;

            for (class_2350 dir : DIRECTIONS) {
                class_2338 neighborPos = current.pos.method_10093(dir);
                if (!isPassable(world, neighborPos)) continue;

                // 修改2：添加高度差检查，禁止向上≥2格
                int yDiff = neighborPos.method_10264() - current.pos.method_10264();
                if (yDiff > 1) continue;  // 只允许向上1格或更少

                int tentativeG = current.g + 1;
                Node neighbor = allNodes.get(neighborPos);
                if (neighbor == null) {
                    neighbor = new Node(neighborPos, current, tentativeG, heuristic(neighborPos, target));
                    allNodes.put(neighborPos, neighbor);
                    openSet.add(neighbor);
                } else if (tentativeG < neighbor.g) {
                    neighbor.parent = current;
                    neighbor.g = tentativeG;
                    neighbor.f = neighbor.g + neighbor.h;
                    openSet.remove(neighbor);
                    openSet.add(neighbor);
                }
            }
        }
        return new ArrayList<>();
    }

    private static int manhattanDistance(class_2338 a, class_2338 b) {
        return Math.abs(a.method_10263() - b.method_10263()) + Math.abs(a.method_10264() - b.method_10264()) + Math.abs(a.method_10260() - b.method_10260());
    }

    private static int heuristic(class_2338 a, class_2338 b) {
        return manhattanDistance(a, b);
    }

    private static List<class_2338> reconstructPath(Node end) {
        LinkedList<class_2338> path = new LinkedList<>();
        for (Node n = end; n != null; n = n.parent) path.addFirst(n.pos);
        return path;
    }

    private static class Node {
        class_2338 pos;
        Node parent;
        int g, h, f;

        Node(class_2338 pos, Node parent, int g, int h) {
            this.pos = pos;
            this.parent = parent;
            this.g = g;
            this.h = h;
            this.f = g + h;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Node)) return false;
            return pos.equals(((Node) o).pos);
        }

        @Override
        public int hashCode() {
            return pos.hashCode();
        }
    }
}