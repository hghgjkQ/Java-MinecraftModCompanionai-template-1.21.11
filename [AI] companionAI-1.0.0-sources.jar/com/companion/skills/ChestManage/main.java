package com.companion.skills.ChestManage;


import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import static com.companion.global.*;
import static com.companion.ChestPosStorage.*;
import static com.companion.ChestPosStorage.getCurrentChestPos;
import static com.companion.effect.tool.*;
import static com.companion.skills.ChestManage.FileSave.saveData;
import static com.companion.skills.ChestManage.cheak.*;

public class main {
    private static class_2338 TarPos;
    private static HashMap<class_1792, Integer> TarItem=new HashMap<>();
    public static void reg(){
        ClientTickEvents.END_CLIENT_TICK.register(main::update); // 每帧执行代码
    }

    private static void update(class_310 client)   {
        if (client==null || client.field_1687==null ||client.field_1724==null)return;
        List<HashMap<class_5321<class_1937>, class_2338>> tempR=new ArrayList<>();
        if(Instant.now().getEpochSecond()%10==0){//每十秒检查一次
            var y=getAllChests();
            for(HashMap<class_5321<class_1937>, class_2338> x: CheckChestData.keySet()){
                class_5321<class_1937> wd=client.field_1724.method_73183().method_27983();
                if (x.containsKey(wd)){ //如果维度正确
                    if(x.get(wd)==null || x.get(wd).equals(new class_2338(0,0,0))){
                        continue;
                    }
                    if (player.method_73189().method_1022(class_243.method_24954(x.get(wd)))<64 && !y.contains(x.get(wd)) && client.field_1687.method_8320(x.get(wd)).method_26204() != class_2246.field_10243){//如果不存在
                        tempR.add(x);

                    }
                }
            }
            for(HashMap<class_5321<class_1937>, class_2338> x:tempR){
                CheckChestData.remove(x);

            }
            saveFile();
        }
        if(isPlayerOpeningChest()) {
            if (getCurrentChestPos() == null) {
                if (TarItem!=getChestItems()) {
                    save(client, TarPos);
                }
            }else{
                TarPos = getCurrentChestPos();
                save(client, TarPos);
                setCurrentChestPos(null);
            }
        }
    }
    private static void save(class_310 client,class_2338 pos){
        HashMap<class_5321<class_1937>, class_2338> temp =new HashMap<>();
        temp.put(client.field_1724.method_73183().method_27983(),pos);
        TarItem=getChestItems();
        CheckChestData.put(temp,TarItem);
        saveFile();

    }
    private static void saveFile(){
        try {
            saveData(CheckChestData, getUniqueWorldOrServerId()+".txt");
        } catch (IOException e) {
            error(e);
        }
    }


}
