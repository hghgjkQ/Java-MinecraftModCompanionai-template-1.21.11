package com.companion.skills.ChestManage;

import net.minecraft.block.*;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_2802;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_4076;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_642;
import net.minecraft.util.math.*;
import java.util.*;

import static com.companion.global.*;

public class cheak {



    public static List<class_2338> getAllChests() {
        class_310 mc = class_310.method_1551();
        class_638 world = mc.field_1687;
        if (world == null) return Collections.emptyList();

        Set<class_2338> result = new HashSet<>();
        class_2802 cm = world.method_2935();

        // 获取已加载区块数量，估算范围（视距通常是 8-32）
        int viewDistance = mc.field_1690.method_42503().method_41753();
        int maxChunk = viewDistance + 2; // 加2个区块缓冲

        class_2338 playerPos = mc.field_1724 != null ? mc.field_1724.method_24515() : class_2338.field_10980;
        int playerChunkX = class_4076.method_18675(playerPos.method_10263());
        int playerChunkZ = class_4076.method_18675(playerPos.method_10260());

        // 只遍历玩家周围的已加载区块
        for (int dx = -maxChunk; dx <= maxChunk; dx++) {
            for (int dz = -maxChunk; dz <= maxChunk; dz++) {
                int x = playerChunkX + dx;
                int z = playerChunkZ + dz;

                class_2818 wc = cm.method_21730(x, z);
                if (wc == null) continue;

                for (class_2586 be : wc.method_12214().values()) {
                    if (!(be instanceof class_2595)) continue;

                    class_2338 pos = be.method_11016();
                    class_2680 state = world.method_8320(pos);
                    class_2338 keep = pos;

                    if (state.method_26204() instanceof class_2281) {
                        class_2745 chestType = state.method_11654(class_2281.field_10770);
                        if (chestType != class_2745.field_12569) {
                            class_2350 facing = state.method_11654(class_2281.field_10768);
                            class_2350 otherDir = chestType == class_2745.field_12574
                                    ? facing.method_10170()
                                    : facing.method_10160();
                            class_2338 paired = pos.method_10093(otherDir);

                            if (class_1937.method_25953(paired)) {
                                keep = sum(pos) <= sum(paired) ? pos : paired;
                            }
                        }
                    }
                    result.add(keep);
                }
            }
        }

        return new ArrayList<>(result);
    }

    private static int sum(class_2382 pos) {
        return pos.method_10263() + pos.method_10264() + pos.method_10260();
    }

    public static boolean open(class_2338 TARGET_CHEST_POS){

        if (all_client.field_1687 != null) {
            player.method_17355(
                    all_client.field_1687.method_8320(TARGET_CHEST_POS).method_26196(all_client.field_1687, TARGET_CHEST_POS));
            return true;
        }
        return false;
    }
    public static HashMap<class_1792, Integer> getChestItems() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return new HashMap<>();

        class_1703 handler = mc.field_1724.field_7512;
        if (!(handler instanceof class_1707 containerHandler)) {
            return new HashMap<>();
        }

        HashMap<class_1792, Integer> itemMap = new HashMap<>();

        // 获取箱子部分的槽位数量（54 for 双箱，27 for 单箱）
        int chestSlotCount = containerHandler.field_7761.size() - 36; // 减去玩家背包36格

        for (int i = 0; i < chestSlotCount; i++) {
            class_1799 stack = containerHandler.method_7611(i).method_7677();
            if (stack.method_7960()) continue;

            itemMap.merge(stack.method_7909(), stack.method_7947(), Integer::sum);
        }

        return itemMap;
    }

    // 辅助方法：合并两个物品统计Map（使用Item作为key）
    private static void mergeItemMaps(HashMap<class_1792, Integer> target, HashMap<class_1792, Integer> source) {
        for (Map.Entry<class_1792, Integer> entry : source.entrySet()) {
            class_1792 item = entry.getKey();
            int count = entry.getValue();

            target.merge(item, count, Integer::sum);
        }
    }




    public static boolean isPlayerOpeningChest() {
        class_310 client = class_310.method_1551();
        class_1657 player = client.field_1724;

        if (player == null) return false;

        class_1703 screenHandler = player.field_7512;

        // 排除自身背包
        if (screenHandler == player.field_7498) return false;
        if (screenHandler instanceof class_1707) {
            return true;
        }

        return false;
    }
    public static void forceCloseOpenedChest() {
        // 直接调用玩家的「关闭容器界面」核心API
        class_310.method_1551().field_1724.method_7346();
    }

    /**
     * 获取 当前服务器/单人存档 的唯一标识名
     * 用途：作为文件名、Map key、存储目录名，永不重复
     */
    /**
     * 获取当前服务器/单人存档的唯一标识（完全匹配1.21.11原生源码逻辑）
     * @return 唯一字符串，永不重复
     */
    public static String getUniqueWorldOrServerId() {
        class_310 client = class_310.method_1551();

        // ========== 1. 多人服务器判断（匹配原生isConnectedToServer()逻辑） ==========
        // 核心：有网络处理器 + 不是本地集成服务器，或本地服务器是远程的（局域网联机）
        class_634 networkHandler = client.method_1562();
        boolean isRemoteServer = networkHandler != null &&
                (!client.method_1496() || (client.method_1576() != null && client.method_1576().method_3860()));

        if (isRemoteServer) {
            // 获取服务器信息（IP+端口）
            class_642 serverInfo = client.method_1558();
            if (serverInfo != null && serverInfo.field_3761 != null) {
                // 替换特殊字符，兼容文件名/MapKey
                String safeAddress = serverInfo.field_3761.replace(":", "_").replace("/", "_").replace("\\", "_");
                return "Server_" + safeAddress;
            }
            // 兜底：用网络连接的真实地址
            if (networkHandler.method_48296() != null) {
                String connAddress = networkHandler.method_48296().method_10755().toString()
                        .replace(":", "_").replace("/", "_");
                return "Server_" + connAddress;
            }
        }

        // ========== 2. 单人游戏/本地局域网服务器 ==========
        if (client.method_1542() && client.field_1687 != null && client.method_1586() != null) {

            return "Single_" + Objects.requireNonNull(client.method_1576()).method_27728().method_150();


        }

        // ========== 3. 极端情况兜底（无世界/无服务器） ==========
        return "Unknown_" + UUID.randomUUID();
    }

}
