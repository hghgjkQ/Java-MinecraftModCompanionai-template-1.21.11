package com.companion.skills;

import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_638;

public class findpathcut {
    private static final class_2350[] DIRECTIONS = {
            class_2350.field_11036, class_2350.field_11033,
            class_2350.field_11043, class_2350.field_11035,
            class_2350.field_11034, class_2350.field_11039
    };
    private static final int MAX_SEARCH_RADIUS = 200;
    private static final int ADJUSTMENT_RADIUS = 5;

    public static List<class_2338> findPath(class_638 world, class_2338 start, class_2338 target) {
        if (start.equals(target)) return Collections.singletonList(start);
        if (world == null || start == null || target == null) return Collections.emptyList();

        class_2338 adjustedStart = adjustBlockPosition(world, start);
        class_2338 adjustedTarget = adjustBlockPosition(world, target);
        if (adjustedStart == null || adjustedTarget == null) return Collections.emptyList();

        if (!isPassable(world, adjustedStart) || !isPassable(world, adjustedTarget))
            return Collections.emptyList();

        return aStarSearch(world, adjustedStart, adjustedTarget);
    }

    private static class_2338 adjustBlockPosition(class_638 world, class_2338 original) {
        if (isPassable(world, original)) return original;

        class_2338 best = null;
        int bestDist = Integer.MAX_VALUE;
        for (int dx = -ADJUSTMENT_RADIUS; dx <= ADJUSTMENT_RADIUS; dx++) {
            for (int dy = -ADJUSTMENT_RADIUS; dy <= ADJUSTMENT_RADIUS; dy++) {
                for (int dz = -ADJUSTMENT_RADIUS; dz <= ADJUSTMENT_RADIUS; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    class_2338 candidate = original.method_10069(dx, dy, dz);
                    if (isPassable(world, candidate)) {
                        int dist = Math.abs(dx) + Math.abs(dy) + Math.abs(dz);
                        if (dist < bestDist) {
                            bestDist = dist;
                            best = candidate;
                        }
                    }
                }
            }
        }
        return best;
    }

    /**
     * 核心修改：判定方块可通行时，要求当前方块和其正上方一格都为空
     */
    private static boolean isPassable(class_638 world, class_2338 pos) {
        if (world == null || pos == null) return false;

        // 检查当前方块是否为空
        class_2680 currentState = world.method_8320(pos);
        class_265 currentShape = currentState.method_26220(world, pos);
        if (!currentShape.method_1110()) return false;

        // 检查当前方块正上方一格是否为空（适配2格高的玩家）
        class_2338 upPos = pos.method_10084(); // 等价于 pos.offset(Direction.UP)
        class_2680 upState = world.method_8320(upPos);
        class_265 upShape = upState.method_26220(world, upPos);

        return upShape.method_1110();
    }

    private static List<class_2338> aStarSearch(class_638 world, class_2338 start, class_2338 target) {
        PriorityQueue<Node> openSet = new PriorityQueue<>(Comparator.comparingInt(n -> n.f));
        Map<class_2338, Node> allNodes = new HashMap<>();

        Node startNode = new Node(start, null, 0, heuristic(start, target));
        openSet.add(startNode);
        allNodes.put(start, startNode);

        int targetX = target.method_10263(), targetY = target.method_10264(), targetZ = target.method_10260();
        int processed = 0, maxNodes = 50000;

        while (!openSet.isEmpty() && processed++ < maxNodes) {
            Node current = openSet.poll();

            if (current.pos.method_10263() == targetX && current.pos.method_10264() == targetY && current.pos.method_10260() == targetZ) {
                return reconstructPath(current);
            }

            if (manhattanDistance(current.pos, target) > MAX_SEARCH_RADIUS) continue;

            for (class_2350 dir : DIRECTIONS) {
                class_2338 neighborPos = current.pos.method_10093(dir);
                if (!isPassable(world, neighborPos)) continue;

                int tentativeG = current.g + 1;
                Node neighbor = allNodes.get(neighborPos);
                if (neighbor == null) {
                    neighbor = new Node(neighborPos, current, tentativeG, heuristic(neighborPos, target));
                    allNodes.put(neighborPos, neighbor);
                    openSet.add(neighbor);
                } else if (tentativeG < neighbor.g) {
                    neighbor.parent = current;
                    neighbor.g = tentativeG;
                    neighbor.f = neighbor.g + neighbor.h;
                    openSet.remove(neighbor);
                    openSet.add(neighbor);
                }
            }
        }
        return Collections.emptyList();
    }

    private static int manhattanDistance(class_2338 a, class_2338 b) {
        return Math.abs(a.method_10263() - b.method_10263()) + Math.abs(a.method_10264() - b.method_10264()) + Math.abs(a.method_10260() - b.method_10260());
    }

    // 修改启发函数为曼哈顿距离，确保找到最短路径（节点最少）
    private static int heuristic(class_2338 a, class_2338 b) {
        return manhattanDistance(a, b);
    }

    private static List<class_2338> reconstructPath(Node end) {
        LinkedList<class_2338> path = new LinkedList<>();
        for (Node n = end; n != null; n = n.parent) path.addFirst(n.pos);
        return path;
    }

    private static class Node {
        class_2338 pos;
        Node parent;
        int g, h, f;

        Node(class_2338 pos, Node parent, int g, int h) {
            this.pos = pos;
            this.parent = parent;
            this.g = g;
            this.h = h;
            this.f = g + h;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Node)) return false;
            return pos.equals(((Node) o).pos);
        }

        @Override
        public int hashCode() {
            return pos.hashCode();
        }
    }
}