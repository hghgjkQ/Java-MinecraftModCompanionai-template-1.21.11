package com.companion.skills.bat;

import com.companion.mixin.client.BossBarHudAccessor;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_337;
import net.minecraft.class_345;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import net.minecraft.class_746;

import static com.companion.Key.config.setV;
import static com.companion.Key.configTool.cfg;
import static com.companion.effect.tool.error;
import static com.companion.effect.tool.tipGame;
import static com.companion.global.*;

public class AutoRaid {

    private static int drink=0;
    private static class_1792 tar=null;

    /**
     * 是否有不祥之兆 (Bad Omen)
     * 1.21 中通过饮用 Ominous Bottle 获得，进入村庄会转化为 Raid Omen
     */
    public static boolean hasBadOmen(class_746 player) {
        return player.method_6059(class_1294.field_16595);
    }

    /**
     * 是否有袭击之兆 (Raid Omen) - 1.21 新增
     * Bad Omen 进入村庄后转化而来，持续 30 秒，之后触发袭击
     */
    public static boolean hasRaidOmen(class_746 player) {
        return player.method_6059(class_1294.field_50117);
    }
    /**
     * 检测客户端是否显示袭击进度条（BossBar）
     * 说明袭击波次正在进行中（Raid Omen 30 秒倒计时已结束）
     */
    public static boolean hasRaidBossBar(class_310 client) {
        if (client.method_1562() == null) return false;
        if( hasRaidOmen(player) || hasBadOmen(player)) return true;

        class_329 hud = client.field_1705;
        class_337 bossBarHud = hud.method_1740();

        // 通过 Accessor 获取 bossBars Map
        Map<UUID, class_345> bossBars = ((BossBarHudAccessor) bossBarHud).getBossBars();

        for (class_345 bossBar : bossBars.values()) {
            // 袭击 BossBar 的名称包含特定翻译键
            String name = bossBar.method_5414().getString();
            // 或者检查 bossBar 的 ID/UUID 特征（袭击有固定的命名空间）
            // 注意：具体判断逻辑可能需要根据实际环境调整
            if ((name.contains("袭击")) && (!name.contains("胜利"))) {
                return true;
            }
        }
        return false;
    }


    private static boolean sup(class_1661 inventory ) {
        class_1792 targetItem=class_1802.field_50140;
        // 已经在主手就不用动了（用 isOf 比 == 更规范）
        if (player.method_6047().method_31574(targetItem)) return true;
        if (all_client.field_1761 == null) return false;

        int hotbarSlot = inventory.method_67532(); // 0-8，主手在快捷栏中的索引

        // 遍历 0-35（背包 + 快捷栏）
        for (int invSlot = 0; invSlot < 36; invSlot++) {
            class_1799 stack = inventory.method_5438(invSlot);
            if (!stack.method_31574(targetItem)) continue;

            // ===== 核心修复：将 Inventory 索引转换为 ScreenHandler 槽位 ID =====
            // PlayerScreenHandler 里的 Slot 对象持有它对应的 Inventory 实例和在其中的索引
            int screenSlot = -1;
            for (class_1735 slot : player.field_7498.field_7761) {
                if (slot.field_7871 == inventory && slot.method_34266() == invSlot) {
                    screenSlot = slot.field_7874; // slot.id 才是 clickSlot 需要的 ScreenHandler 槽位 ID
                    break;
                }
            }
            if (screenSlot == -1) continue; // 兜底

            // 使用 SWAP 一次性把物品换到主手（原子操作，无需模拟两次 PICKUP）
            // 参数说明：button 在 SWAP 模式下代表快捷栏索引 0-8
            all_client.field_1761.method_2906(
                    player.field_7498.field_7763,  // 正确的 syncId
                    screenSlot,                          // 正确的源槽位 ID
                    hotbarSlot,                          // 目标：当前选中的快捷栏
                    class_1713.field_7791,
                    player
            );
            return true; // 只搬第一组
        }
        return false;
    }

    private static void sup(class_1661 inventory, class_1792 targetItem) {
        // 已经在主手就不用动了（用 isOf 比 == 更规范）
        if (player.method_6047().method_31574(targetItem)) return;
        if (all_client.field_1761 == null) return;

        int hotbarSlot = inventory.method_67532(); // 0-8，主手在快捷栏中的索引

        // 遍历 0-35（背包 + 快捷栏）
        for (int invSlot = 0; invSlot < 36; invSlot++) {
            class_1799 stack = inventory.method_5438(invSlot);
            if (!stack.method_31574(targetItem)) continue;

            // ===== 核心修复：将 Inventory 索引转换为 ScreenHandler 槽位 ID =====
            // PlayerScreenHandler 里的 Slot 对象持有它对应的 Inventory 实例和在其中的索引
            int screenSlot = -1;
            for (class_1735 slot : player.field_7498.field_7761) {
                if (slot.field_7871 == inventory && slot.method_34266() == invSlot) {
                    screenSlot = slot.field_7874; // slot.id 才是 clickSlot 需要的 ScreenHandler 槽位 ID
                    break;
                }
            }
            if (screenSlot == -1) continue; // 兜底

            // 使用 SWAP 一次性把物品换到主手（原子操作，无需模拟两次 PICKUP）
            // 参数说明：button 在 SWAP 模式下代表快捷栏索引 0-8
            all_client.field_1761.method_2906(
                    player.field_7498.field_7763,  // 正确的 syncId
                    screenSlot,                          // 正确的源槽位 ID
                    hotbarSlot,                          // 目标：当前选中的快捷栏
                    class_1713.field_7791,
                    player
            );
            return; // 只搬第一组
        }
    }
    public static void update(class_310 client,boolean planTime){
        if(cfg.enableAutoRaid.get()){
            client.field_1690.field_1904.method_23481(drink > 0);
            if(hasRaidBossBar(client)) { //如果处于袭击
                drink = 0;
                sup(player.method_31548(), tar);
                /*
                if(planTime){
                    // 2. 遍历所有有效容器，逐个拿取
                    RaidStep=0;
                }
                if(RaidStep>-1){
                    BlockPos pos=RaidIn.get(RaidStep);
                    if (player.getInventory().getEmptySlot() <= 0) {
                        // 背包满了，停止掠夺（尽可能多拿的核心）
                        RaidStep=-1;
                    }
                    interactContainer(client, player, pos);
                    if (player.getInventory().getEmptySlot() > 0) {
                        // 背包满了，停止掠夺（尽可能多拿的核心）
                        RaidStep++;
                        if(RaidStep>=RaidIn.size()){
                            RaidStep=-1;
                        }
                    }

                 */

            }else{
                if (tar==null) {
                    tar=player.method_6047().method_7909();
                }
                if (sup(player.method_31548())){
                    drink=1;
                }else{
                    tipGame("自动袭击","无不详之瓶，自动停止");
                    sup(player.method_31548(),tar);
                    tar=null;
                    setV(cfg,cfg.enableAutoRaid,false);
                    client.field_1690.field_1904.method_23481(false);

                }

            }
        }else{
            if (tar!=null) {
                tar = null;
            }
        }
    }

    /**
     * 自动使用主手物品（相当于长按右键）
     * 调用后客户端会发送交互包到服务端，触发饮用动作
     */
    public static void useMainHandItem() {
        class_310 client = class_310.method_1551();

        if (client.field_1724 == null || client.field_1761 == null) return;
        // 确保安全使用（不在冷却中、不是创造模式等）
        if (client.field_1724.method_6014() > 0) return; // 已经在使用物品中

        // 发送使用物品包，触发饮用
        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
    }




    // 打开容器 + 快速拿走所有物品（Shift+左键核心逻辑）
    private static void interactContainer(class_310 client, class_746 player, class_2338 pos) {
        // 模拟准星指向方块
        class_3965 hit = new class_3965(class_243.method_24953(pos), net.minecraft.class_2350.field_11036, pos, false);
        client.field_1765 = hit;

        // 右键打开容器
        client.field_1761.method_2896(player, class_1268.field_5808, hit);

        // 等待容器界面打开（极短延迟，不卡顿游戏）
        client.execute(() -> {
            try {

                Thread.sleep(100);

                // 检查是否已打开箱子界面
                if (client.field_1755 instanceof class_465<?> screen) {
                    if (screen.method_17577() instanceof class_1707 containerHandler) {
                        // 执行拿取
                        int rows = containerHandler.method_17388();

                        for (int i = 0; i < rows * 9; i++) {

                            class_1735 slot = containerHandler.method_7611(i);
                            if (slot.method_7681() && !slot.method_7677().method_7960()) {
                                if (countEmptySlots(player.method_31548())<=0) break;
                                client.field_1761.method_2906(
                                        screen.method_17577().field_7763,
                                        i,
                                        0,
                                        class_1713.field_7794,
                                        client.field_1724
                                );
                            }
                        }
                    }
                }
                class_310.method_1551().field_1724.method_7346();
            } catch (InterruptedException e) {
                error(e);
            }

        });
    }

    /**
     * 计算玩家背包中的空槽位数量
     */
    public static int countEmptySlots(class_1661 inventory) {
        int emptySlots = 0;
        // inventory.size() 返回背包总槽位数（包括盔甲、副手等），通常为 41
        // 但主物品栏是索引 0-35，盔甲和副手不用于自动存放，可以限制只检查主物品栏
        for (int i = 0; i < 36; i++) {
            if (inventory.method_5438(i).method_7960()) {
                emptySlots++;
            }
        }
        return emptySlots;
    }
}
