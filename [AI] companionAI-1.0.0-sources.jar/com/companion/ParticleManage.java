package com.companion;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

import static com.companion.CompanionAI.MOD_ID;

public class ParticleManage {
    // 原有粒子常量
    public static final class_2400 SPARKLE_PARTICLE =
            FabricParticleTypes.simple();
    public static final class_2400 STAR_PARTICLE =
            FabricParticleTypes.simple();
    public static final class_2400 RED_POINT_PARTICLE =
            FabricParticleTypes.simple();
    public static final class_2400 GREEN_POINT_PARTICLE =
            FabricParticleTypes.simple();

    // 新增颜色粒子常量（对应blue/brown/orange/pink/purple/white/yellow）
    public static final class_2400 BLUE_POINT_PARTICLE =
            FabricParticleTypes.simple();
    public static final class_2400 BROWN_POINT_PARTICLE =
            FabricParticleTypes.simple();
    public static final class_2400 ORANGE_POINT_PARTICLE =
            FabricParticleTypes.simple();
    public static final class_2400 PINK_POINT_PARTICLE =
            FabricParticleTypes.simple();
    public static final class_2400 PURPLE_POINT_PARTICLE =
            FabricParticleTypes.simple();
    public static final class_2400 WHITE_POINT_PARTICLE =
            FabricParticleTypes.simple();
    public static final class_2400 YELLOW_POINT_PARTICLE =
            FabricParticleTypes.simple();



    public static void MAINparticleReg() {
        // 原有粒子注册
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "sparkle_particle"),
                SPARKLE_PARTICLE);
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "star"),
                STAR_PARTICLE);
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "red_point"),
                RED_POINT_PARTICLE);
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "green_point"),
                GREEN_POINT_PARTICLE);

        // 新增颜色粒子注册（与常量一一对应）
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "blue_point"),
                BLUE_POINT_PARTICLE);
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "brown_point"),
                BROWN_POINT_PARTICLE);
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "orange_point"),
                ORANGE_POINT_PARTICLE);
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "pink_point"),
                PINK_POINT_PARTICLE);
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "purple_point"),
                PURPLE_POINT_PARTICLE);
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "white_point"),
                WHITE_POINT_PARTICLE);
        class_2378.method_10230(class_7923.field_41180,
                class_2960.method_60655(MOD_ID, "yellow_point"),
                YELLOW_POINT_PARTICLE);
    }
}