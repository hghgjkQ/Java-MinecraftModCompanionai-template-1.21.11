package com.companion.draw;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import java.util.Map;
import java.util.Optional;
import com.mojang.blaze3d.pipeline.RenderPipeline;



@Environment(EnvType.CLIENT)
public class v3d     {

    private static final int RED_COLOR = 0xFFFF0000; // ARGB 纯红色

    public static void init() {
        WorldRenderEvents.END_MAIN.register(context -> {
            renderRedCube(context.matrices(), context.consumers(), class_310.method_1551().method_1561().field_4686, context);
        });
    }

    private static void renderRedCube(class_4587 matrices, class_4597 vertexConsumers, class_4184 camera ,WorldRenderContext context) {
        if (matrices == null || vertexConsumers == null) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        double x = 0;
        double y = 0;
        double z = 0;

        // 相机偏移
        class_243 cameraPos = camera.method_71156();
        x =-cameraPos.field_1352;
        y = -cameraPos.field_1351;
        z = -cameraPos.field_1350;

        matrices.method_22903();
        matrices.method_22904(x, y, z);
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_60827(VertexFormat.class_5596.field_27377, class_290.field_1576);


        Matrix4f matrix = matrices.method_23760().method_23761();

        // 绘制立方体六个面
        float size = 1.5f;

        // 前面 (Z+)
        drawQuad(buffer, matrix,
                -size, -size, size,
                size, -size, size,
                size,  size, size,
                -size,  size, size,
                RED_COLOR
        );

        matrices.method_22909();
    }

    private static void drawQuad(class_4588 buffer, Matrix4f matrix,
                                 float x1, float y1, float z1,
                                 float x2, float y2, float z2,
                                 float x3, float y3, float z3,
                                 float x4, float y4, float z4,
                                 int color) {

        // 顶点1
        buffer.method_22918(matrix, x1, y1, z1)
                .method_39415(color)
                .method_22913(0, 0);


        // 顶点2
        buffer.method_22918(matrix, x2, y2, z2)
                .method_39415(color)
                .method_22913(0, 0);


        // 顶点3
        buffer.method_22918(matrix, x3, y3, z3)
                .method_39415(color)
                .method_22913(0, 0);


        // 顶点4
        buffer.method_22918(matrix, x4, y4, z4)
                .method_39415(color)
                .method_22913(0, 0);
    }
}