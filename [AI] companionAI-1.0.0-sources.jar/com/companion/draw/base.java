package com.companion.draw;

import static com.companion.global.*;

import net.minecraft.class_2394;
import net.minecraft.class_243;

public class base {
    // 角度转弧度核心常量（1° = π/180 弧度），全局复用
    public static final double DEG_TO_RAD = Math.PI / 180D;


    // ===================== 核心：MC专属双轴旋转（仅X/Y轴，贴合游戏视角） =====================
    /**
     * 三维点绕指定中心进行X/Y双轴旋转（适配MC，绕X=俯仰，绕Y=左右）
     * @param originalPoint 原始三维点坐标
     * @param center 旋转中心（图形中心，与绘制pos一致）
     * @param rx 绕X轴旋转角度（角度值，如30=30°，俯仰旋转）
     * @param ry 绕Y轴旋转角度（角度值，左右旋转，适配MC右手坐标系）
     * @return 旋转后的新三维点坐标
     */
    public static class_243 rotatePoint(class_243 originalPoint, class_243 center, double rx, double ry) {
        // 1. 平移点到旋转中心为原点（避免绕世界原点旋转，保证绕图形中心旋转）
        double x = originalPoint.field_1352 - center.field_1352;
        double y = originalPoint.field_1351 - center.field_1351;
        double z = originalPoint.field_1350 - center.field_1350;

        // 角度转弧度，复用全局常量
        double rxRad = rx * DEG_TO_RAD;
        double ryRad = ry * DEG_TO_RAD;

        double newX, newY, newZ;

        // 2. 绕X轴旋转（俯仰，仅改变Y/Z坐标，X不变，MC中抬头/低头对应此轴）
        // 旋转矩阵：[1,0,0; 0,cosθ,-sinθ; 0,sinθ,cosθ]
        newY = y * Math.cos(rxRad) - z * Math.sin(rxRad);
        newZ = y * Math.sin(rxRad) + z * Math.cos(rxRad);
        y = newY;
        z = newZ;

        // 3. 绕Y轴旋转（左右，仅改变X/Z坐标，Y不变，MC中左右转对应此轴，适配游戏右手坐标系）
        // 旋转矩阵：[cosθ,0,sinθ; 0,1,0; -sinθ,0,cosθ]（MC空间专属，保证旋转方向贴合游戏操作）
        newX = x * Math.cos(ryRad) + z * Math.sin(ryRad);
        newZ = -x * Math.sin(ryRad) + z * Math.cos(ryRad);
        x = newX;
        z = newZ;

        // 4. 平移点回原中心坐标系，返回旋转结果
        return new class_243(x + center.field_1352, y + center.field_1351, z + center.field_1350);
    }

    // ===================== 重载1：带X/Y双轴旋转的三角形 =====================
    public static void triangle(class_243 pos, double r, double angle, int particleDensity, class_2394 c,
                                double rx, double ry) {
        for (int theta = 0; theta < 3; theta++) {
            // 原始2D点计算（与原有逻辑完全一致，不改动）
            double x = pos.field_1352 + r * Math.cos((theta * 120 + angle) * DEG_TO_RAD);
            double z = pos.field_1350 + r * Math.sin((theta * 120 + angle) * DEG_TO_RAD);
            class_243 p1 = new class_243(x, pos.field_1351, z);

            double x1 = pos.field_1352 + r * Math.cos(((theta + 1) * 120 + angle) * DEG_TO_RAD);
            double z1 = pos.field_1350 + r * Math.sin(((theta + 1) * 120 + angle) * DEG_TO_RAD);
            class_243 p2 = new class_243(x1, pos.field_1351, z1);

            // 核心：双轴旋转后绘制线段
            class_243 p1Rotated = rotatePoint(p1, pos, rx, ry);
            class_243 p2Rotated = rotatePoint(p2, pos, rx, ry);
            line(p1Rotated, p2Rotated, particleDensity, c);
        }
    }

    // 原有2D三角形方法（保持不变，兼容旧代码）
    public static void triangle(class_243 pos, double r, double angle, int particleDensity, class_2394 c) {
        triangle(pos, r, angle, particleDensity, c, 0, 0);
    }

    // ===================== 重载2：带X/Y双轴旋转的花朵 =====================
    public static void flower(class_243 pos, double r, double r2, double angle, int particleDensity, int particleDensity2, class_2394 c,
                              double rx, double ry) {
        double a = 0;
        double stepAngle = 360.0 / particleDensity2;
        for (int theta = 0; theta < particleDensity2; theta++) {
            // 原始2D点计算（与原有逻辑完全一致）
            double x = pos.field_1352 + r * Math.cos((a + angle) * DEG_TO_RAD);
            double z = pos.field_1350 + r * Math.sin((a + angle) * DEG_TO_RAD);
            class_243 p1 = new class_243(x, pos.field_1351, z);

            double x1 = pos.field_1352 + r2 * Math.cos((a + angle) * DEG_TO_RAD);
            double z1 = pos.field_1350 + r2 * Math.sin((a + angle) * DEG_TO_RAD);
            class_243 p2 = new class_243(x1, pos.field_1351, z1);

            // 核心：双轴旋转后绘制线段
            class_243 p1Rotated = rotatePoint(p1, pos, rx, ry);
            class_243 p2Rotated = rotatePoint(p2, pos, rx, ry);
            line(p1Rotated, p2Rotated, particleDensity, c);
            a += stepAngle;
        }
    }

    // 原有2D花朵方法（保持不变，兼容旧代码）
    public static void flower(class_243 pos, double r, double r2, double angle, int particleDensity, int particleDensity2, class_2394 c) {
        flower(pos, r, r2, angle, particleDensity, particleDensity2, c, 0, 0);
    }

    // ===================== 重载3：带X/Y双轴旋转的角度线段 =====================
    public static void line(class_243 pos, double r, double angle, int particleDensity, class_2394 c,
                            double rx, double ry) {
        // 原始2D点计算（与原有逻辑完全一致）
        double x = pos.field_1352 + r * Math.cos(angle * DEG_TO_RAD);
        double z = pos.field_1350 + r * Math.sin(angle * DEG_TO_RAD);
        class_243 p1 = new class_243(x, pos.field_1351, z);

        double x1 = pos.field_1352 - r * Math.cos(angle * DEG_TO_RAD);
        double z1 = pos.field_1350 - r * Math.sin(angle * DEG_TO_RAD);
        class_243 p2 = new class_243(x1, pos.field_1351, z1);

        // 核心：双轴旋转后绘制线段
        class_243 p1Rotated = rotatePoint(p1, pos, rx, ry);
        class_243 p2Rotated = rotatePoint(p2, pos, rx, ry);
        line(p1Rotated, p2Rotated, particleDensity, c);
    }

    // 原有2D角度线段方法（保持不变，兼容旧代码）
    public static void line(class_243 pos, double r, double angle, int particleDensity, class_2394 c) {
        line(pos, r, angle, particleDensity, c, 0, 0);
    }

    // ===================== 重载4：带X/Y双轴旋转的圆形 =====================
    public static void drawCircle(class_2394 s, class_243 center, double radius, double step,
                                  double rx, double ry) {
        // 原始圆形点计算（与原有逻辑一致，0到2π弧度）
        for (double theta = 0; theta < 2 * Math.PI; theta += step) {
            double x = center.field_1352 + radius * Math.cos(theta);
            double z = center.field_1350 + radius * Math.sin(theta);
            class_243 originalPoint = new class_243(x, center.field_1351, z);
            // 核心：双轴旋转后绘制粒子点
            class_243 rotatedPoint = rotatePoint(originalPoint, center, rx, ry);
            point(s, rotatedPoint);
        }
    }

    // 原有2D圆形方法（保持不变，兼容旧代码）
    public static void drawCircle(class_2394 s, class_243 center, double radius, double step) {
        drawCircle(s, center, radius, step, 0, 0);
    }

    // ===================== 原有底层方法（完全未改动，复用所有粒子绘制逻辑） =====================
    public static void line(class_243 a, class_243 b, int particleDensity, class_2394 c) {
        if (all_client == null) return;
        double distance = a.method_1022(b);
        if (distance < 1e-6) {
            point(c, a);
            return;
        }
        class_243 direction = b.method_1020(a).method_1029();
        int totalParticles = (int) (distance * particleDensity);
        double stepDistance = distance / totalParticles;
        for (int i = 0; i <= totalParticles; i++) {
            class_243 pos = a.method_1019(direction.method_1021(stepDistance * i));
            point(c, pos);
        }
    }

    public static void point(class_2394 s, class_243 P) {
        if (all_client.field_1687 != null) {
            all_client.field_1687.method_8466(
                    s,
                    true,
                    true,
                    P.field_1352,
                    P.field_1351,
                    P.field_1350,
                    0,
                    0,
                    0
            );

        }
    }
}