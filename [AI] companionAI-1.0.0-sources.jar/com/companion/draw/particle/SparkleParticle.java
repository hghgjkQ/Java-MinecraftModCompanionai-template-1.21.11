package com.companion.draw.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

public class SparkleParticle extends class_3940 {
    private final class_4002 spriteProvider;

    protected SparkleParticle(class_638 world, double x, double y, double z,
                              double velocityX, double velocityY, double velocityZ,
                              class_4002 spriteProvider) {
        super(world, x, y, z, velocityX, velocityY, velocityZ, spriteProvider.method_18138(0, 1));
        this.spriteProvider = spriteProvider;
        this.field_17867 = 0.2f;
        this.field_3847 = 40 + this.field_3840.method_43048(20);
        this.method_74305(1.0f, 1.0f, 1.0f);
        this.field_62636 = 0.8f;
    }

    @Override
    public void method_3070() {
        super.method_3070();
        this.method_74307(spriteProvider.method_18138(this.field_3866, this.field_3847));

        if (this.field_3866 < this.field_3847 / 2) {
            this.field_17867 += 0.01f;
        } else {
            this.field_17867 -= 0.01f;
            this.field_62636 -= 0.02f;
        }

        this.field_3852 += (field_3840.method_43058() - 0.5) * 0.01;
        this.field_3869 += (field_3840.method_43058() - 0.5) * 0.01;
        this.field_3850 += (field_3840.method_43058() - 0.5) * 0.01;

        // 如果寿命结束，标记为死亡（移除粒子）
        if (this.field_3866 >= this.field_3847) {
            this.method_3085();
        }
    }

    @Override
    protected class_11941 method_74255() {
        // 使用粒子图集的半透明渲染类型
        return class_11941.field_62641;
    }

    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteProvider;

        public Factory(class_4002 spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Override
        public class_703 createParticle(class_2400 type, class_638 world,
                                       double x, double y, double z,
                                       double velocityX, double velocityY, double velocityZ,
                                       class_5819 random) {
            return new star(world, x, y, z, velocityX, velocityY, velocityZ, spriteProvider);
        }
    }
}