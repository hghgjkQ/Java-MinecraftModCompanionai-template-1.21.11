package com.companion.draw.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

public class star extends class_3940 {
    private final class_4002 spriteProvider;
    private final int halfPeriod;  // 半周期长度（正向或反向一次的时间）

    protected star(class_638 world, double x, double y, double z,
                   double velocityX, double velocityY, double velocityZ,
                   class_4002 spriteProvider) {
        super(world, x, y, z, velocityX, velocityY, velocityZ, spriteProvider.method_18138(0, 1));
        this.spriteProvider = spriteProvider;
        this.field_17867 = 0.1f;
        this.field_3847 = 40 + this.field_3840.method_43048(20);
        this.method_74305(1.0f, 1.0f, 1.0f);
        this.field_62636 = 0.8f;

        // 设置半周期长度（这里设为 maxAge，即一次正向或反向与粒子寿命相同）
        this.halfPeriod = this.field_3847;
    }

    @Override
    public void method_3070() {
        super.method_3070();

        // --- 实现来回切换动画 ---
        // 计算在当前周期内的位置（0 ~ 2*halfPeriod）
        int t = this.field_3866 % (2 * halfPeriod);
        // 映射虚拟年龄：前半段正向，后半段反向
        // 使用虚拟年龄获取精灵，实现来回切换
        this.method_74307(spriteProvider.method_18138((int)(Math.random()*2), this.field_3847));
        // -----------------------

        if (this.field_3866 < this.field_3847 / 2) {
        } else {
            this.field_62636 -= 0.02f;
        }

        this.field_3852 += (field_3840.method_43058() - 0.5) * 0.01;
        this.field_3869 += (field_3840.method_43058() - 0.5) * 0.01;
        this.field_3850 += (field_3840.method_43058() - 0.5) * 0.01;

        if (this.field_3866 >= this.field_3847) {
            this.method_3085();
        }
    }

    @Override
    protected class_11941 method_74255() {
        // 保持原样，不修改
        return class_11941.field_62641;
    }

    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteProvider;

        public Factory(class_4002 spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Override
        public class_703 createParticle(class_2400 type, class_638 world,
                                       double x, double y, double z,
                                       double velocityX, double velocityY, double velocityZ,
                                       class_5819 random) {
            // 修正：返回正确的类名 star
            return new star(world, x, y, z, velocityX, velocityY, velocityZ, spriteProvider);
        }
    }
}