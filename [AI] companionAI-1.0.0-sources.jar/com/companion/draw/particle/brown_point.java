package com.companion.draw.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

public class brown_point extends class_3940 {
    private final class_4002 spriteProvider;

    protected brown_point(class_638 world, double x, double y, double z,
                        double velocityX, double velocityY, double velocityZ,
                        class_4002 spriteProvider) {
        super(world, x, y, z, velocityX, velocityY, velocityZ, spriteProvider.method_18138(0, 1));
        this.spriteProvider = spriteProvider;
        this.field_17867 = 0.2f;
        this.field_3847 = 1;
        this.method_74305(1.0f, 1.0f, 1.0f);
        this.field_62636 = 0.8f;
    }

    @Override
    public void method_3070() {
        super.method_3070();
        this.method_74307(spriteProvider.method_18138(this.field_3866, this.field_3847));
        // 保留死亡检测
        if (this.field_3866 >= this.field_3847) {
            this.method_3085();
        }
    }

    @Override
    protected class_11941 method_74255() {
        // 使用粒子图集的半透明渲染类型
        return class_11941.field_62641;
    }

    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteProvider;

        public Factory(class_4002 spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Override
        public class_703 createParticle(class_2400 type, class_638 world,
                                       double x, double y, double z,
                                       double velocityX, double velocityY, double velocityZ,
                                       class_5819 random) {
            return new brown_point(world, x, y, z, velocityX, velocityY, velocityZ, spriteProvider);
        }
    }
}