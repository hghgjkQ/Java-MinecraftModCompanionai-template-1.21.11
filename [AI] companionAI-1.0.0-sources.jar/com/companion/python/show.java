package com.companion.python;

import java.util.Objects;
import net.minecraft.class_2398;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

import static com.companion.CompanionAIClient.*;
import static com.companion.effect.show.line;
import static com.companion.effect.weapon.Spear.*;
import static com.companion.global.*;

public class show   {



    public static void renderSquare(class_332 context, class_9779 c) {
        if (!Objects.equals(MidText, "")) {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null) return;

            // 获取屏幕尺寸
            int screenWidth = client.method_22683().method_4486();
            int screenHeight = client.method_22683().method_4502();

            // 正方形大小和位置
            int x = (screenWidth) / 2;
            int y = (screenHeight) / 2;


            context.method_51433(client.field_1772, MidText, x, y, 0x80FF0000, true);
        }

    }



    public static void path(){
        if (Path!=null) {
            for (int i = 0; i < Path.size() - 1; i++) {
                line(Path.get(i), Path.get(i + 1), 5, class_2398.field_11240);
            }
        }
    }

}