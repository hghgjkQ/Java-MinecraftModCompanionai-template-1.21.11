package com.companion.python;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

import static com.companion.global.*;
import static com.companion.effect.tool.error;


public class main {

    public static void reg(){
        ClientTickEvents.END_CLIENT_TICK.register(main::manage); // 每帧执行代码
    }

    public static void manage(class_310 client){
        if(Objects.equals(state, "follow")){
            follow();
        }
    }

    public static void follow(){
        try {
            // 极简异步调用findPath（无任何多余代码）
            CompletableFuture.supplyAsync(() ->
                    find.findPath(class_310.method_1551().field_1687, class_310.method_1551().field_1724.method_24515(), getPlayerPosByName(FollowPlayer))
            ).whenComplete((path, ex) -> class_310.method_1551().execute(() -> {
                // 此处仅保留结果接收，如需处理结果/异常可在此补充
                Path = path;

            }));
        } catch (Exception e) {
            state=null;
            error(e);
        }
    }
    // 根据玩家名称获取其坐标（返回BlockPos，如需精确坐标可改用Vec3d）
    private static class_2338 getPlayerPosByName(String targetPlayerName) {
        class_310 client = class_310.method_1551();
        // 空值校验：确保游戏世界/玩家列表不为空
        if (client.field_1687 == null) return null;
        // 遍历所有在线玩家，匹配名称（忽略大小写，符合MC实际交互习惯）
        for (class_1657 player : client.field_1687.method_18456()) {
            String playerName = player.method_74861();
            // 精准匹配（如需模糊匹配可改用contains()）
            if (playerName.equalsIgnoreCase(targetPlayerName)) {
                return player.method_24515(); // 方块坐标（整数）
                // 如需精确三维坐标，替换为：return player.getPos(); // 返回Vec3d（带小数）
            }
        }
        return null; // 未找到该玩家
    }
}
