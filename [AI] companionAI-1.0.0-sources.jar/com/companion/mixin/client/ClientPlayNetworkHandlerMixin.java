package com.companion.mixin.client;


import com.companion.ChestPosStorage;
import com.companion.render3D.screen;
import com.companion.skills.ChestControl;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static com.companion.ChestPosStorage.*;
import static com.companion.effect.tool.tip;
import static com.companion.effect.tool.tipGame;
import static com.companion.render3D.screen.blocks;
import static com.companion.skills.ChestManage.cheak.*;

@Mixin(class_636.class)
public class ClientPlayNetworkHandlerMixin {
    private int a=0;
    @Inject(method = "interactBlock", at = @At("HEAD"))
    private void onInteractBlock(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        class_2338 pos = hitResult.method_17777();
        // 检查点击的是不是箱子
        if (player.method_73183().method_8320(pos).method_26204() instanceof net.minecraft.class_2281) {
            setCurrentChestPos(getMinChestPos(pos, (class_638) player.method_73183()));
            if(a==0) {
                //ChestControl.putItemIntoChest(Items.STONE, -1);
                a=1;
                tipGame("ok");
            }
        }
    }

    // 方法3：移除并重新添加（如果坐标不存在则添加，存在则更新颜色）
    @Unique
    private static void updateBlock(class_2338 pos, String colorName) {
        blocks.removeIf(bwc -> bwc.pos.equals(pos));
        blocks.add(new screen.BlockWithColor(pos, colorName));
    }

}